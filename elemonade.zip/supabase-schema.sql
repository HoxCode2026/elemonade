-- Elemonade Database Schema for Supabase

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT DEFAULT 'student',
  avatar_url TEXT,
  grade TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Study rooms table
CREATE TABLE IF NOT EXISTS study_rooms (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT DEFAULT 'group',
  host_id UUID REFERENCES users(id),
  host_name TEXT,
  max_users INTEGER DEFAULT 10,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  closed_at TIMESTAMP WITH TIME ZONE
);

-- Room participants table
CREATE TABLE IF NOT EXISTS room_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id UUID REFERENCES study_rooms(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'studying',
  focus_score INTEGER DEFAULT 50,
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  left_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(room_id, user_id)
);

-- Room messages table
CREATE TABLE IF NOT EXISTS room_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id UUID REFERENCES study_rooms(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  text TEXT,
  type TEXT DEFAULT 'message',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE room_participants;
ALTER PUBLICATION supabase_realtime ADD TABLE room_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE study_rooms;

-- Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE room_messages ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "Anyone can read users" ON users FOR SELECT USING (true);
CREATE POLICY "Anyone can read rooms" ON study_rooms FOR SELECT USING (true);
CREATE POLICY "Anyone can read participants" ON room_participants FOR SELECT USING (true);
CREATE POLICY "Anyone can read messages" ON room_messages FOR SELECT USING (true);

-- Authenticated insert/update
CREATE POLICY "Users can insert themselves" ON users FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update themselves" ON users FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Auth users can insert rooms" ON study_rooms FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Host can update their room" ON study_rooms FOR UPDATE USING (auth.uid() = host_id);

CREATE POLICY "Auth users can join rooms" ON room_participants FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Auth users can update participation" ON room_participants FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Auth users can send messages" ON room_messages FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Indexes
CREATE INDEX idx_participants_room ON room_participants(room_id);
CREATE INDEX idx_messages_room ON room_messages(room_id);
CREATE INDEX idx_rooms_status ON study_rooms(status);
