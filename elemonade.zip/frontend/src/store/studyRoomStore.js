import { create } from 'zustand';
import { api } from '../lib/apiClient';

export const useStudyRoomStore = create((set) => ({
  rooms: [],
  loading: false,
  error: null,

  fetchRooms: async () => {
    set({ loading: true, error: null });
    try {
      const data = await api.get('/rooms');
      set({ rooms: data.rooms, loading: false });
    } catch (err) {
      set({ error: err.message, loading: false });
    }
  },

  createRoom: async (name, type, maxUsers) => {
    const data = await api.post('/rooms', { name, type, max_users: maxUsers });
    return data.room;
  },
}));
