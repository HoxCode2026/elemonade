import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { api } from '../lib/apiClient';
import { Calendar, Flame, Target, ArrowLeft, BookOpen, Clock, TrendingUp } from 'lucide-react';

export default function HomePage() {
  const { user } = useAuthStore();
  const [schedule, setSchedule] = useState(null);
  const [streak, setStreak] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.get('/schedule/active').catch(() => null),
      api.get('/checkin/streak').catch(() => null),
    ]).then(([s, st]) => {
      if (s) setSchedule({ ...s.schedule, blocks: s.blocks });
      if (st) setStreak(st.streak);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => <div key={i} className="skeleton h-32 w-full" />)}
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];
  const dayNumber = schedule?.start_date
    ? Math.ceil((new Date(today) - new Date(schedule.start_date)) / 86400000) + 1
    : 0;

  const currentBlock = schedule?.blocks?.find(
    b => dayNumber >= b.start_day && dayNumber <= b.end_day
  );

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="card bg-gradient-to-l from-primary-500/10 to-primary-600/5 border-primary-500/20">
        <h1 className="text-2xl font-bold mb-2">
          أهلاً {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          {schedule
            ? `أنت في اليوم ${dayNumber} من أصل ${schedule.total_days} يوم`
            : 'ابدأ بإنشاء جدولك الآن لتنظيم مذاكرتك'}
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card text-center">
          <Flame className="w-8 h-8 text-orange-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">{streak?.current_streak || 0}</div>
          <div className="text-xs text-gray-500">أيام متتالية</div>
        </div>
        <div className="card text-center">
          <Target className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">{streak?.longest_streak || 0}</div>
          <div className="text-xs text-gray-500">أطول سلسلة</div>
        </div>
        <div className="card text-center">
          <Calendar className="w-8 h-8 text-primary-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">{dayNumber || '-'}</div>
          <div className="text-xs text-gray-500">اليوم الحالي</div>
        </div>
        <div className="card text-center">
          <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">
            {currentBlock ? `${currentBlock.progress_percent}%` : '-'}
          </div>
          <div className="text-xs text-gray-500">تقدم المادة</div>
        </div>
      </div>

      {/* Current Focus */}
      {currentBlock ? (
        <div className="card border-primary-500/30">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary-500/20 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-primary-500" />
              </div>
              <div>
                <h2 className="font-bold text-lg">{currentBlock.subject_name}</h2>
                <p className="text-sm text-gray-500">
                  المرحلة {currentBlock.phase} | يوم {dayNumber - currentBlock.start_day + 1} من {currentBlock.allocated_days}
                </p>
              </div>
            </div>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 mb-3">
            <div
              className="bg-primary-500 h-3 rounded-full transition-all duration-500"
              style={{ width: `${currentBlock.progress_percent}%` }}
            />
          </div>
          <div className="flex gap-3">
            <Link to="/today" className="btn-primary flex-1 text-center text-sm">
              ابدأ مذاكرة اليوم
            </Link>
            <Link to="/my-schedule" className="btn-secondary flex-1 text-center text-sm">
              عرض الجدول
            </Link>
          </div>
        </div>
      ) : !schedule ? (
        <div className="card text-center py-12">
          <Clock className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <h2 className="text-xl font-bold mb-2">لم تنشئ جدولك بعد</h2>
          <p className="text-gray-500 mb-6">أنشئ جدول مذاكرتك الآن للبدء في تنظيم وقتك</p>
          <Link to="/my-schedule" className="btn-primary inline-flex items-center gap-2">
            إنشاء جدولي الآن
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="card text-center py-8">
          <h2 className="text-lg font-bold mb-2">لا توجد مادة مجدولة لهذا اليوم</h2>
          <Link to="/my-schedule" className="text-primary-500 hover:underline">عرض الجدول الكامل</Link>
        </div>
      )}

      {/* Quick Links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Link to="/curriculum" className="card hover:border-primary-500/50 transition-all group">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="font-bold">تصفح المناهج</h3>
              <p className="text-xs text-gray-500">استعرض المواد والدروس</p>
            </div>
            <ArrowLeft className="w-5 h-5 mr-auto text-gray-400 group-hover:text-primary-500 transition-all" />
          </div>
        </Link>
        <Link to="/study-room" className="card hover:border-primary-500/50 transition-all group">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-xl flex items-center justify-center">
              <Target className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <h3 className="font-bold">غرفة المذاكرة</h3>
              <p className="text-xs text-gray-500">ذاكر مع زملائك</p>
            </div>
            <ArrowLeft className="w-5 h-5 mr-auto text-gray-400 group-hover:text-primary-500 transition-all" />
          </div>
        </Link>
      </div>
    </div>
  );
}
