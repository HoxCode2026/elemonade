import { useState, useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import { api } from '../lib/apiClient';
import { User, Mail, Calendar, Flame, Trophy, Shield, Edit3, Save, X, Camera } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ProfilePage() {
  const { user, init } = useAuthStore();
  const [streak, setStreak] = useState(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: '', bio: '', avatar_url: '' });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get('/checkin/streak').then(d => setStreak(d.streak)).catch(() => {});
  }, []);

  useEffect(() => {
    if (user) {
      setForm({ name: user.name || '', bio: user.bio || '', avatar_url: user.avatar_url || '' });
    }
  }, [user]);

  const saveProfile = async () => {
    setSaving(true);
    try {
      await api.put('/auth/me', form);
      await init();
      setEditing(false);
      toast.success('تم تحديث الملف الشخصي');
    } catch (err) {
      toast.error(err.message || 'فشل التحديث');
    }
    setSaving(false);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">

      {/* Hero: Glowing Photo + About Me Side by Side */}
      <div className="card p-0 overflow-hidden">
        {/* Gradient Header */}
        <div className="h-32 bg-gradient-to-l from-primary-600 via-primary-500 to-blue-500 relative">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMCAwaDQwdjQwSDB6IiBmaWxsPSJub25lIi8+PHBhdGggZD0iTTIwIDBMMjAgNDBNMCA0MGw0MC00ME0wIDBMNDAgNDAiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9IjAuMDUiIHN0cm9rZS13aWR0aD0iMSIvPjwvc3ZnPg==')] opacity-50" />
        </div>

        <div className="px-6 pb-8 -mt-16 relative">
          <div className="flex flex-col sm:flex-row gap-6 items-start">

            {/* Animated Glowing Photo Box */}
            <div className="relative flex-shrink-0 self-center sm:self-start">
              {/* Outer glow ring - spinning */}
              <div className="absolute -inset-3 rounded-full bg-gradient-conic from-primary-500 via-blue-400 via-purple-500 to-primary-500 animate-glow-spin opacity-70 blur-md" />
              {/* Inner glow pulse */}
              <div className="absolute -inset-2 rounded-full bg-gradient-to-tr from-primary-400 via-blue-500 to-purple-400 animate-pulse opacity-50" />
              {/* Photo container */}
              <div className="relative w-32 h-32 rounded-full bg-gradient-to-br from-primary-500 via-primary-600 to-blue-700 flex items-center justify-center ring-4 ring-surface-light dark:ring-surface-dark shadow-2xl shadow-primary-500/40 overflow-hidden">
                {user?.avatar_url ? (
                  <img src={user.avatar_url} alt={user.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-5xl font-bold text-white select-none">
                    {user?.name?.charAt(0) || 'H'}
                  </span>
                )}
              </div>
              {/* Camera overlay on hover */}
              {editing && (
                <div className="absolute bottom-0 left-0 w-8 h-8 bg-primary-500 rounded-full flex items-center justify-center shadow-lg cursor-pointer">
                  <Camera className="w-4 h-4 text-white" />
                </div>
              )}
            </div>

            {/* About Me Section (التعريف بيا) */}
            <div className="flex-1 pt-4 sm:pt-8 min-w-0">
              <div className="flex items-start justify-between gap-4">
                <div>
                  {editing ? (
                    <input
                      type="text"
                      value={form.name}
                      onChange={e => setForm({ ...form, name: e.target.value })}
                      className="input-field text-xl font-bold mb-1 p-2"
                    />
                  ) : (
                    <h2 className="text-2xl font-bold">{user?.name}</h2>
                  )}
                  <p className="text-gray-500 text-sm" dir="ltr">{user?.email}</p>
                  {user?.role === 'admin' && (
                    <span className="mt-2 inline-flex items-center gap-1 px-3 py-1 bg-primary-500/10 text-primary-500 rounded-full text-xs font-medium">
                      <Shield className="w-3 h-3" />
                      مشرف
                    </span>
                  )}
                </div>
                <button
                  onClick={() => editing ? saveProfile() : setEditing(true)}
                  disabled={saving}
                  className={`flex-shrink-0 p-2 rounded-xl transition-all ${
                    editing
                      ? 'bg-green-500 text-white hover:bg-green-600'
                      : 'bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700'
                  }`}
                >
                  {saving ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : editing ? (
                    <Save className="w-5 h-5" />
                  ) : (
                    <Edit3 className="w-5 h-5" />
                  )}
                </button>
              </div>

              {/* Bio / التعريف */}
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-500 mb-2">التعريف</h4>
                {editing ? (
                  <div className="space-y-3">
                    <textarea
                      value={form.bio}
                      onChange={e => setForm({ ...form, bio: e.target.value })}
                      placeholder="اكتب نبذة عنك... من أنت؟ ما هي أهدافك؟"
                      className="input-field text-sm h-24 resize-none"
                    />
                    <input
                      type="url"
                      value={form.avatar_url}
                      onChange={e => setForm({ ...form, avatar_url: e.target.value })}
                      placeholder="رابط صورتك الشخصية (URL)"
                      className="input-field text-sm"
                      dir="ltr"
                    />
                    <button
                      onClick={() => { setEditing(false); setForm({ name: user?.name || '', bio: user?.bio || '', avatar_url: user?.avatar_url || '' }); }}
                      className="text-sm text-gray-500 hover:text-red-500 flex items-center gap-1"
                    >
                      <X className="w-4 h-4" />
                      إلغاء
                    </button>
                  </div>
                ) : (
                  <p className="text-sm leading-relaxed text-gray-700 dark:text-gray-300">
                    {user?.bio || 'لم تضف نبذة عنك بعد. اضغط على زر التعديل لإضافة نبذة.'}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="card text-center">
          <Flame className="w-8 h-8 text-orange-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">{streak?.current_streak || 0}</div>
          <div className="text-xs text-gray-500">أيام متتالية</div>
        </div>
        <div className="card text-center">
          <Trophy className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
          <div className="text-2xl font-bold">{streak?.longest_streak || 0}</div>
          <div className="text-xs text-gray-500">أطول سلسلة</div>
        </div>
      </div>

      {/* Account Info */}
      <div className="card space-y-4">
        <h3 className="font-bold text-lg mb-4">معلومات الحساب</h3>

        <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-xl">
          <User className="w-5 h-5 text-gray-400" />
          <div>
            <p className="text-xs text-gray-500">الاسم</p>
            <p className="font-medium">{user?.name}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-xl">
          <Mail className="w-5 h-5 text-gray-400" />
          <div>
            <p className="text-xs text-gray-500">البريد الإلكتروني</p>
            <p className="font-medium" dir="ltr">{user?.email}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-900/50 rounded-xl">
          <Calendar className="w-5 h-5 text-gray-400" />
          <div>
            <p className="text-xs text-gray-500">تاريخ التسجيل</p>
            <p className="font-medium">{user?.created_at ? new Date(user.created_at).toLocaleDateString('ar-EG') : '-'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
