import { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { BookOpen, CheckCircle, Loader2, ThumbsDown, ThumbsUp, Minus } from 'lucide-react';
import toast from 'react-hot-toast';

export default function ReviewPage() {
  const [items, setItems] = useState({ sessions: [], tasks: [] });
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchDue();
    fetchStats();
  }, []);

  const fetchDue = async () => {
    try {
      const data = await api.get('/review/due');
      setItems(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const data = await api.get('/review/stats');
      setStats(data);
    } catch (err) {
      console.error(err);
    }
  };

  const markReviewed = async (id, difficulty) => {
    try {
      await api.post(`/review/${id}/complete`, { difficulty });
      toast.success(difficulty === 'easy' ? 'سهل! +20 XP' : difficulty === 'medium' ? 'متوسط +15 XP' : 'صعب +10 XP');
      fetchDue();
      fetchStats();
    } catch (err) {
      toast.error(err.message);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  const allItems = [...items.sessions, ...items.tasks];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
          <BookOpen className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">المراجعة الذكية</h1>
          <p className="text-sm text-gray-500">راجع ما تعلمته بانتظام</p>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="card">
            <div className="text-2xl font-bold text-green-500">{stats.reviewed_today}</div>
            <div className="text-xs text-gray-500">مراجع اليوم</div>
          </div>
          <div className="card">
            <div className="text-2xl font-bold text-orange-500">{stats.due_now}</div>
            <div className="text-xs text-gray-500">معلق للمراجعة</div>
          </div>
          <div className="card">
            <div className="text-2xl font-bold text-purple-500">{stats.current_streak}</div>
            <div className="text-xs text-gray-500">أيام متتالية</div>
          </div>
          <div className="card">
            <div className="text-2xl font-bold text-blue-500">{stats.longest_streak}</div>
            <div className="text-xs text-gray-500">أطول سلسلة</div>
          </div>
        </div>
      )}

      {/* Due Items */}
      {allItems.length === 0 ? (
        <div className="card text-center py-12">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">ممتاز! كل شيء مراجع</h3>
          <p className="text-gray-500">لا توجد عناصر للمراجعة الآن</p>
        </div>
      ) : (
        <div className="space-y-4">
          <h2 className="font-bold text-lg">للمراجعة ({allItems.length})</h2>
          {allItems.map((item, idx) => (
            <div key={item.id || idx} className="card">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-bold">{item.subject_name_ar || item.title}</h3>
                  <p className="text-sm text-gray-500">
                    {item.task_type === 'practice' ? 'حل أسئلة' : 
                     item.task_type === 'review' ? 'مراجعة' : 'دراسة'}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => markReviewed(item.id, 'hard')}
                    className="p-2 bg-red-500/20 text-red-500 rounded-lg hover:bg-red-500/30"
                    title="صعب - مراجعة غداً"
                  >
                    <ThumbsDown className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => markReviewed(item.id, 'medium')}
                    className="p-2 bg-yellow-500/20 text-yellow-500 rounded-lg hover:bg-yellow-500/30"
                    title="متوسط - مراجعة بعد 3 أيام"
                  >
                    <Minus className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => markReviewed(item.id, 'easy')}
                    className="p-2 bg-green-500/20 text-green-500 rounded-lg hover:bg-green-500/30"
                    title="سهل - مراجعة بعد أسبوع"
                  >
                    <ThumbsUp className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}