import { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { Calendar, ChevronDown, ChevronUp, BookOpen, Plus, RefreshCw, Check, AlertCircle, Flame, Target, TrendingUp, Clock, Settings, Layers, Zap, BatteryCharging } from 'lucide-react';
import toast from 'react-hot-toast';
import Modal from '../components/shared/Modal';

const phaseColors = {
  1: { bg: 'bg-blue-500/20', text: 'text-blue-600', border: 'border-blue-500/30', name: 'التأسيس' },
  2: { bg: 'bg-purple-500/20', text: 'text-purple-600', border: 'border-purple-500/30', name: 'الفهم' },
  3: { bg: 'bg-green-500/20', text: 'text-green-600', border: 'border-green-500/30', name: 'المراجعة' },
};

const DIFFICULTY_LEVELS = [
  { value: 'weak', label: 'ضعيف', color: 'text-red-500', bg: 'bg-red-500/10', factor: 1.35 },
  { value: 'medium', label: 'متوسط', color: 'text-yellow-500', bg: 'bg-yellow-500/10', factor: 1.0 },
  { value: 'strong', label: 'قوي', color: 'text-green-500', bg: 'bg-green-500/10', factor: 0.75 },
];

const DISTRIBUTION_MODES = [
  { value: 'balanced', label: 'متوازن', icon: Layers, desc: 'توزيع عادي على الأيام' },
  { value: 'intensive', label: 'مكثف', icon: Zap, desc: 'تركيز أكبر في وقت أقل' },
  { value: 'relaxed', label: 'مريح', icon: BatteryCharging, desc: 'توزيع سهل وميسور' },
];

const REVIEW_MODES = [
  { value: 'smart', label: 'ذكي', desc: 'مراجعة متباعدة (1-3-7-14-30 يوم)' },
  { value: 'fixed', label: 'ثابت', desc: 'نسبة ثابتة من المراجعة' },
  { value: 'none', label: 'بدون', desc: 'بدون مراجعة مخططة' },
];

const taskTypeColors = {
  study: { bg: 'bg-blue-500/10', text: 'text-blue-600', label: 'شرح' },
  practice: { bg: 'bg-orange-500/10', text: 'text-orange-600', label: 'حل' },
  review: { bg: 'bg-green-500/10', text: 'text-green-600', label: 'مراجعة' },
};

export default function SchedulePage() {
  const [schedule, setSchedule] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showWizard, setShowWizard] = useState(false);
  const [expandedBlock, setExpandedBlock] = useState(null);
  const [blockDetails, setBlockDetails] = useState({});
  const [selectedDay, setSelectedDay] = useState(null);

  const [systems, setSystems] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    system_id: '',
    track_id: '',
    total_days: 70,
    phases_count: 3,
    daily_hours: 8,
    distribution_mode: 'balanced',
    max_subjects_per_day: 2,
    review_mode: 'smart',
    weekly_rest_days: 1
  });
  const [selectedSubjects, setSelectedSubjects] = useState({});
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    loadSchedule();
  }, []);

  const loadSchedule = async () => {
    try {
      const data = await api.get('/schedule/active');
      setSchedule({ ...data.schedule, blocks: data.blocks });
      setTasks(data.tasks || []);
      const statsData = await api.get(`/schedule/stats?day=${getDayNumber(data.schedule)}`);
      setStats(statsData.stats);
    } catch {
      setSchedule(null);
    } finally {
      setLoading(false);
    }
  };

  const getDayNumber = (sched) => {
    if (!sched?.start_date) return 1;
    const today = new Date();
    const start = new Date(sched.start_date);
    return Math.max(1, Math.ceil((today - start) / 86400000) + 1);
  };

  const startWizard = async () => {
    try {
      const s = await api.get('/curriculum/systems');
      setSystems(Array.isArray(s) ? s : s.systems || []);
      setShowWizard(true);
      setStep(1);
    } catch { toast.error('خطأ'); }
  };

  const selectSystem = async (id) => {
    setForm({ ...form, system_id: id, track_id: '' });
    const t = await api.get(`/curriculum/systems/${id}/tracks`);
    setTracks(Array.isArray(t) ? t : t.tracks || []);
    setStep(2);
  };

  const selectTrack = async (id) => {
    setForm({ ...form, track_id: id });
    const s = await api.get(`/schedule/subjects?track_id=${id}`);
    const subjList = s.subjects || [];
    setSubjects(subjList);
    
    const selected = {};
    subjList.forEach(s => {
      selected[s.id] = {
        is_selected: s.is_selected === 1 || s.is_selected === true,
        difficulty_level: s.difficulty_level || 'medium'
      };
    });
    setSelectedSubjects(selected);
    setStep(3);
  };

  const toggleSubject = (id) => {
    setSelectedSubjects(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        is_selected: !prev[id]?.is_selected
      }
    }));
  };

  const setDifficulty = (id, level) => {
    setSelectedSubjects(prev => ({
      ...prev,
      [id]: {
        ...prev[id],
        difficulty_level: level,
        is_selected: true
      }
    }));
  };

  const generate = async () => {
    const selected = Object.entries(selectedSubjects)
      .filter(([_, v]) => v.is_selected)
      .map(([id, v]) => ({
        subject_id: parseInt(id),
        is_selected: true,
        difficulty_level: v.difficulty_level
      }));

    if (selected.length === 0) {
      toast.error('اختر مادة واحدة على الأقل');
      return;
    }

    setGenerating(true);
    try {
      await api.post('/schedule/subjects', { subjects: selected });
      const data = await api.post('/schedule/generate', {
        system_id: form.system_id,
        track_id: form.track_id,
        total_days: form.total_days,
        start_date: new Date().toISOString().split('T')[0],
        phases_count: form.phases_count,
        daily_hours: form.daily_hours,
        distribution_mode: form.distribution_mode,
        max_subjects_per_day: form.max_subjects_per_day,
        review_mode: form.review_mode,
        weekly_rest_days: form.weekly_rest_days
      });
      setSchedule({ ...data.schedule, blocks: data.blocks });
      setShowWizard(false);
      toast.success('تم إنشاء الجدول بنجاح! 🎉');
      loadSchedule();
    } catch (err) {
      toast.error(err.message || 'خطأ');
    } finally {
      setGenerating(false);
    }
  };

  const toggleBlock = async (block) => {
    if (expandedBlock === block.id) {
      setExpandedBlock(null);
      return;
    }
    setExpandedBlock(block.id);
    if (!blockDetails[block.id]) {
      try {
        const data = await api.get(`/curriculum/subjects/${block.subject_id}/units`);
        setBlockDetails(prev => ({ ...prev, [block.id]: data.units || data }));
      } catch {}
    }
  };

  const updateProgress = async (blockId, value) => {
    try {
      await api.put(`/schedule/blocks/${blockId}/progress`, { progress_percent: value });
      setSchedule(prev => ({
        ...prev,
        blocks: prev.blocks.map(b => b.id === blockId ? { ...b, progress_percent: value } : b),
      }));
    } catch { toast.error('خطأ'); }
  };

  const completeTask = async (taskId, completed) => {
    try {
      await api.put(`/schedule/tasks/${taskId}/complete`, { completed });
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, is_completed: completed ? 1 : 0 } : t));
      loadSchedule();
    } catch { toast.error('خطأ'); }
  };

  const dayNumber = schedule ? getDayNumber(schedule) : 0;
  const todayTasks = tasks.filter(t => t.day_number === dayNumber);
  const groupedByPhase = schedule?.blocks?.reduce((acc, b) => {
    (acc[b.phase] = acc[b.phase] || []).push(b);
    return acc;
  }, {}) || {};

  if (loading) return <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="skeleton h-24" />)}</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Calendar className="w-7 h-7 text-primary-500" />
          جدولي الذكي
        </h1>
        <button onClick={startWizard} className="btn-secondary text-sm flex items-center gap-2">
          <RefreshCw className="w-4 h-4" />
          {schedule ? 'إعادة إنشاء' : 'إنشاء جديد'}
        </button>
      </div>

      {!schedule ? (
        <div className="card text-center py-16">
          <Target className="w-20 h-20 text-gray-300 dark:text-gray-600 mx-auto mb-6" />
          <h2 className="text-2xl font-bold mb-3">أنشئ جدول مذاكرتك الذكي</h2>
          <p className="text-gray-500 mb-8 max-w-md mx-auto">
            سيوزع المواد حسب مستواك - ضعيف/متوسط/قوي - مع مراعاة الصعوبة والفترات الزمنية
          </p>
          <button onClick={startWizard} className="btn-primary inline-flex items-center gap-2">
            <Plus className="w-5 h-5" />
            ابدأ الآن
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="card text-center">
              <Flame className="w-6 h-6 text-orange-500 mx-auto mb-1" />
              <div className="text-2xl font-bold text-orange-500">{dayNumber}</div>
              <div className="text-xs text-gray-500">اليوم الحالي</div>
            </div>
            <div className="card text-center">
              <Calendar className="w-6 h-6 text-primary-500 mx-auto mb-1" />
              <div className="text-2xl font-bold">{schedule.total_days - dayNumber}</div>
              <div className="text-xs text-gray-500">يوم متبقي</div>
            </div>
            <div className="card text-center">
              <Check className="w-6 h-6 text-green-500 mx-auto mb-1" />
              <div className="text-2xl font-bold text-green-500">{stats?.completion_percent || 0}%</div>
              <div className="text-xs text-gray-500">نسبة الإنجاز</div>
            </div>
            <div className="card text-center">
              <TrendingUp className="w-6 h-6 text-purple-500 mx-auto mb-1" />
              <div className="text-2xl font-bold">{schedule.blocks?.length || 0}</div>
              <div className="text-xs text-gray-500">المادة</div>
            </div>
          </div>

          {todayTasks.length > 0 && (
            <div className="card">
              <h2 className="font-bold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-primary-500" />
                مهام اليوم ({dayNumber})
              </h2>
              <div className="space-y-2">
                {todayTasks.map(task => {
                  const taskInfo = taskTypeColors[task.task_type] || taskTypeColors.study;
                  return (
                    <div key={task.id} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800/50">
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => completeTask(task.id, !task.is_completed)}
                          className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${
                            task.is_completed ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300 hover:border-primary-500'
                          }`}
                        >
                          {task.is_completed && <Check className="w-4 h-4" />}
                        </button>
                        <div>
                          <p className={`font-medium ${task.is_completed ? 'line-through text-gray-400' : ''}`}>{task.subject_name}</p>
                          <span className={`text-xs px-2 py-0.5 rounded ${taskInfo.bg} ${taskInfo.text}`}>{taskInfo.label}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {Object.entries(groupedByPhase).map(([phase, blocks]) => (
            <div key={phase} className="space-y-3">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <span className={`px-3 py-1 rounded-lg text-xs font-bold ${phaseColors[phase]?.bg} ${phaseColors[phase]?.text}`}>
                  المرحلة {phase}
                </span>
                <span className="text-sm font-normal text-gray-500">{phaseColors[phase]?.name}</span>
              </h2>

              {blocks.map((block) => {
                const isActive = dayNumber >= block.start_day && dayNumber <= block.end_day;
                const isPast = dayNumber > block.end_day;
                const difficulty = DIFFICULTY_LEVELS.find(d => d.value === block.difficulty_level) || DIFFICULTY_LEVELS[1];

                return (
                  <div key={block.id} className={`card transition-all ${isActive ? 'border-primary-500 ring-2 ring-primary-500/20' : isPast ? 'opacity-60' : ''}`}>
                    <div className="flex items-center justify-between cursor-pointer" onClick={() => toggleBlock(block)}>
                      <div className="flex items-center gap-3">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isActive ? 'bg-primary-500 text-white' : difficulty.bg}`}>
                          <BookOpen className={`w-6 h-6 ${isActive ? 'text-white' : difficulty.color}`} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold">{block.subject_name}</h3>
                            <span className={`text-xs px-2 py-0.5 rounded ${difficulty.bg} ${difficulty.color}`}>{difficulty.label}</span>
                          </div>
                          <p className="text-xs text-gray-500">
                            يوم {block.start_day} → {block.end_day} ({block.allocated_days} يوم)
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-bold text-primary-500">{block.progress_percent}%</span>
                        {expandedBlock === block.id ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </div>

                    <div className="mt-3">
                      <input type="range" min="0" max="100" value={block.progress_percent}
                        onChange={(e) => updateProgress(block.id, parseInt(e.target.value))}
                        className="w-full accent-primary-500" onClick={e => e.stopPropagation()} />
                    </div>

                    {expandedBlock === block.id && blockDetails[block.id] && (
                      <div className="mt-4 pt-4 border-t space-y-3">
                        {(Array.isArray(blockDetails[block.id]) ? blockDetails[block.id] : []).map((unit) => (
                          <div key={unit.id}>
                            <h4 className="font-medium text-sm mb-2 flex items-center gap-2">
                              <BookOpen className="w-4 h-4 text-primary-500" />
                              {unit.name}
                            </h4>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1 mr-6">
                              {unit.lessons?.map((lesson) => (
                                <div key={lesson.id} className="text-xs text-gray-500 flex items-center gap-1.5 py-1">
                                  <div className="w-1.5 h-1.5 rounded-full bg-primary-500/50" />
                                  {lesson.name}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </>
      )}

      <Modal open={showWizard} onClose={() => setShowWizard(false)} title="إنشاء جدول جديد">
        <div className="min-h-[400px]">
          {step === 1 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">1</div>
                <div className="flex-1 h-1 bg-gray-200 rounded"><div className="w-0 h-full bg-primary-500 rounded" /></div>
                <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center font-bold">2</div>
                <div className="flex-1 h-1 bg-gray-200 rounded" />
                <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center font-bold">3</div>
              </div>
              <p className="text-sm text-gray-500 mb-4">اختر النظام التعليمي</p>
              {systems.map((s) => (
                <button key={s.id} onClick={() => selectSystem(s.id)}
                  className="w-full p-4 rounded-xl border-2 border-gray-200 dark:border-gray-700 hover:border-primary-500 text-right transition-all">
                  <div className="font-bold">{s.name}</div>
                  <div className="text-xs text-gray-500">{s.code === 'gen' ? 'الثانوية العامة' : 'الأزهر الشريف'}</div>
                </button>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">2</div>
                <div className="flex-1 h-1 bg-gray-200 rounded" />
                <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center font-bold">3</div>
              </div>
              <p className="text-sm text-gray-500 mb-4">اختر الشعبة</p>
              {tracks.map((t) => (
                <button key={t.id} onClick={() => selectTrack(t.id)}
                  className="w-full p-4 rounded-xl border-2 border-gray-200 dark:border-gray-700 hover:border-primary-500 text-right transition-all">
                  <div className="font-bold">{t.name}</div>
                  <div className="text-xs text-gray-500">{t.code}</div>
                </button>
              ))}
              <button onClick={() => setStep(1)} className="text-sm text-gray-500 hover:text-primary-500">← رجوع</button>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">3</div>
                <div className="flex-1 h-1 bg-gray-200 rounded" />
                <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-500 flex items-center justify-center font-bold">4</div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">عدد الأيام المتبقية على الامتحان</label>
                <input type="number" value={form.total_days}
                  onChange={(e) => setForm({ ...form, total_days: parseInt(e.target.value) || 0 })}
                  className="input-field" min="7" max="365" />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  <Clock className="w-4 h-4 inline ml-1" />
                  ساعات المذاكرة اليومية: <span className="text-primary-500 font-bold">{form.daily_hours}</span> ساعة
                </label>
                <input type="range" min="4" max="12" value={form.daily_hours}
                  onChange={(e) => setForm({ ...form, daily_hours: parseInt(e.target.value) })}
                  className="w-full accent-primary-500" />
                <div className="flex justify-between text-xs text-gray-400">
                  <span>4 ساعات</span>
                  <span>12 ساعة</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">اختر المواد ومستواك في كل مادة</label>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {subjects.map(subject => {
                    const selected = selectedSubjects[subject.id];
                    const isSelected = selected?.is_selected;
                    const level = selected?.difficulty_level || 'medium';

                    return (
                      <div key={subject.id} className={`p-3 rounded-xl border transition-all ${isSelected ? 'border-primary-500 bg-primary-500/5' : 'border-gray-200 dark:border-gray-700'}`}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <button onClick={() => toggleSubject(subject.id)}
                              className={`w-5 h-5 rounded border-2 flex items-center justify-center ${isSelected ? 'bg-primary-500 border-primary-500' : 'border-gray-300'}`}>
                              {isSelected && <Check className="w-3 h-3 text-white" />}
                            </button>
                            <span className="font-medium">{subject.name}</span>
                          </div>
                          {isSelected && (
                            <select value={level}
                              onChange={(e) => setDifficulty(subject.id, e.target.value)}
                              className="text-sm bg-transparent border rounded px-2 py-1">
                              {DIFFICULTY_LEVELS.map(d => (
                                <option key={d.value} value={d.value}>{d.label} ({d.factor}x)</option>
                              ))}
                            </select>
                          )}
                        </div>
                        {isSelected && (
                          <div className="flex gap-2">
                            {DIFFICULTY_LEVELS.map(d => (
                              <button key={d.value} onClick={() => setDifficulty(subject.id, d.value)}
                                className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition-all ${level === d.value ? `${d.bg} ${d.color} border-2 border-current` : 'bg-gray-100 dark:bg-gray-800'}`}>
                                {d.label}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-xl text-xs text-blue-600 dark:text-blue-400">
                <div className="flex items-center gap-2 mb-1">
                  <AlertCircle className="w-4 h-4" />
                  <span className="font-medium">كيف يؤثر مستواك؟</span>
                </div>
                <p>ضعيف = +35% وقت | متوسط = الوقت العادي | قوي = -25% وقت</p>
              </div>

              <button onClick={() => setStep(4)} disabled={Object.values(selectedSubjects).filter(s => s.is_selected).length === 0}
                className="btn-primary w-full flex items-center justify-center gap-2">
                التالي: تفضيلات متقدمة
                <ChevronDown className="w-4 h-4" />
              </button>
              <button onClick={() => setStep(2)} className="text-sm text-gray-500 hover:text-primary-500 w-full text-center">← رجوع</button>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">✓</div>
                <div className="flex-1 h-1 bg-primary-500 rounded" />
                <div className="w-8 h-8 rounded-full bg-primary-500 text-white flex items-center justify-center font-bold">4</div>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5 text-primary-500" />
                <h3 className="font-bold">التفضيلات المتقدمة</h3>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">نمط التوزيع</label>
                <div className="grid grid-cols-3 gap-2">
                  {DISTRIBUTION_MODES.map(mode => {
                    const Icon = mode.icon;
                    return (
                      <button key={mode.value} onClick={() => setForm({ ...form, distribution_mode: mode.value })}
                        className={`p-3 rounded-xl border text-center transition-all ${form.distribution_mode === mode.value ? 'border-primary-500 bg-primary-500/10' : 'border-gray-200 dark:border-gray-700'}`}>
                        <Icon className={`w-5 h-5 mx-auto mb-1 ${form.distribution_mode === mode.value ? 'text-primary-500' : 'text-gray-400'}`} />
                        <div className="text-xs font-medium">{mode.label}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">عدد المواد في اليوم</label>
                <div className="flex gap-2">
                  {[1, 2, 3].map(num => (
                    <button key={num} onClick={() => setForm({ ...form, max_subjects_per_day: num })}
                      className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${form.max_subjects_per_day === num ? 'bg-primary-500 text-white' : 'bg-gray-100 dark:bg-gray-800'}`}>
                      {num} {num === 1 ? 'مادة' : num === 2 ? 'مادتان' : '3 مواد'}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">نظام المراجعة</label>
                <div className="space-y-2">
                  {REVIEW_MODES.map(mode => (
                    <button key={mode.value} onClick={() => setForm({ ...form, review_mode: mode.value })}
                      className={`w-full p-3 rounded-xl border text-right transition-all ${form.review_mode === mode.value ? 'border-primary-500 bg-primary-500/5' : 'border-gray-200 dark:border-gray-700'}`}>
                      <div className="font-medium">{mode.label}</div>
                      <div className="text-xs text-gray-500">{mode.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">أيام الراحة الأسبوعية</label>
                <div className="flex gap-2">
                  {[0, 1, 2].map(num => (
                    <button key={num} onClick={() => setForm({ ...form, weekly_rest_days: num })}
                      className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${form.weekly_rest_days === num ? 'bg-primary-500 text-white' : 'bg-gray-100 dark:bg-gray-800'}`}>
                      {num === 0 ? 'أيام كلها' : num === 1 ? 'يوم واحد' : 'يومان'}
                    </button>
                  ))}
                </div>
              </div>

              <button onClick={generate} disabled={generating}
                className="btn-primary w-full flex items-center justify-center gap-2">
                {generating ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <Zap className="w-5 h-5" />
                    توليد الجدول الذكي 🧠
                  </>
                )}
              </button>
              <button onClick={() => setStep(3)} className="text-sm text-gray-500 hover:text-primary-500 w-full text-center">← رجوع</button>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}
