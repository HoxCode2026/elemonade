import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play, Pause, RotateCcw, Coffee, BookOpen, Users, Plus, X, LogOut,
  Mic, MicOff, PhoneOff, Video, MessageSquare, Music, Grid, Layout,
  User, UsersRound, MessageCircle, Pin, PinOff, Circle, Send,
  Monitor, MonitorOff, Loader2
} from 'lucide-react';
import { getSocket, disconnectSocket } from '../lib/socket';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

const ROOM_TYPES = {
  focus: { label: 'تركيز', color: 'text-green-500', bg: 'bg-green-500/10', icon: BookOpen },
  group: { label: 'مجموعة', color: 'text-blue-500', bg: 'bg-blue-500/10', icon: Users },
  silent: { label: 'صامت', color: 'text-purple-500', bg: 'bg-purple-500/10', icon: Coffee },
};

const REACTIONS = ['👍', '🔥', '👏', '❤️', '😂', '🎉'];

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ]
};

const MAX_RECONNECT_ATTEMPTS = 3;

function VideoTile({ stream, participant, isSelf, isPinned, onPin }) {
  const videoRef = useRef(null);
  const [hasVideo, setHasVideo] = useState(false);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      setHasVideo(true);
    } else {
      setHasVideo(false);
    }
  }, [stream]);

  return (
    <div className={`relative rounded-2xl overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900 aspect-video transition-all ${isPinned ? 'col-span-2 row-span-2' : ''} ${isSelf ? 'ring-2 ring-green-500' : ''}`}>
      {stream && hasVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={isSelf}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center">
            <span className="text-4xl font-bold text-white">
              {(participant.user_name || participant.name || '?').charAt(0).toUpperCase()}
            </span>
          </div>
        </div>
      )}

      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-white font-medium text-sm">
              {isSelf ? 'أنت' : participant.user_name || participant.name || 'مجهول'}
            </span>
            {participant.hasAudio === false && <MicOff className="w-3 h-3 text-red-400" />}
          </div>
          {!isSelf && (
            <button onClick={onPin} className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20">
              {isPinned ? <PinOff className="w-4 h-4 text-white" /> : <Pin className="w-4 h-4 text-white" />}
            </button>
          )}
        </div>
      </div>

      <div className="absolute top-3 left-3">
        <div className={`w-3 h-3 rounded-full ${participant.status === 'studying' ? 'bg-green-500' : participant.status === 'break' ? 'bg-yellow-500' : 'bg-gray-400'} ${participant.status === 'studying' ? 'animate-pulse' : ''}`} />
      </div>
    </div>
  );
}

function ParticipantItem({ participant, isSelf }) {
  return (
    <div className={`flex items-center gap-3 p-3 rounded-xl ${isSelf ? 'bg-green-500/10 border border-green-500/30' : 'bg-gray-50 dark:bg-gray-800/50'}`}>
      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
        participant.status === 'studying' ? 'bg-green-500 text-white' :
        participant.status === 'break' ? 'bg-yellow-500 text-white' :
        'bg-gray-400 text-white'
      }`}>
        {(participant.user_name || participant.name || '?').charAt(0).toUpperCase()}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">
          {isSelf ? 'أنت' : participant.user_name || participant.name || 'مجهول'}
        </p>
        <div className="flex items-center gap-1">
          {participant.status === 'studying' && <Circle className="w-2 h-2 text-green-500 fill-green-500" />}
          <span className="text-xs text-gray-500">
            {participant.status === 'studying' ? 'يذاكر' : participant.status === 'break' ? 'راحة' : 'غير نشط'}
          </span>
        </div>
      </div>
    </div>
  );
}

export default function StudyRoomPage() {
  const { user } = useAuthStore();
  const [view, setView] = useState('list');
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentRoom, setCurrentRoom] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);
  const [newMsg, setNewMsg] = useState('');

  const [pomodoro, setPomodoro] = useState({
    remainingSeconds: 25 * 60,
    isBreak: false,
    isPaused: true,
    sessions: 0,
    focusTime: 25,
    breakTime: 5
  });

  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createForm, setCreateForm] = useState({ name: '', type: 'focus', maxUsers: 10 });
  const [creating, setCreating] = useState(false);
  const socketRef = useRef(null);
  const messagesEndRef = useRef(null);

  const [userStatus, setUserStatus] = useState('studying');
  const [sessionStats, setSessionStats] = useState({ sessions: 0, totalMinutes: 0, streak: 0 });
  const [showParticipants, setShowParticipants] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [layout, setLayout] = useState('speaker');
  const [pinnedParticipant, setPinnedParticipant] = useState(null);
  const [reactions, setReactions] = useState([]);

  const [cameraOn, setCameraOn] = useState(false);
  const [micOn, setMicOn] = useState(false);
  const [localStream, setLocalStream] = useState(null);
  const [peers, setPeers] = useState({});
  const peersRef = useRef({});
  const pendingCandidatesRef = useRef({});
  const reconnectAttemptsRef = useRef({});
  const currentRoomRef = useRef(null);

  const getLocalStream = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setLocalStream(stream);
      setCameraOn(true);
      setMicOn(true);
      toast.success('تم تشغيل الكاميرا والميكروفون');
      return stream;
    } catch (err) {
      console.error('Camera error:', err);
      toast.error('لا يمكن الوصول للكاميرا');
      return null;
    }
  };

  const stopLocalStream = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    setCameraOn(false);
    setMicOn(false);
  };

  const flushPendingCandidates = async (peerId) => {
    const pending = pendingCandidatesRef.current[peerId];
    if (!pending || pending.length === 0) return;
    const peer = peersRef.current[peerId];
    if (!peer?.pc) return;
    for (const candidate of pending) {
      try {
        await peer.pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (err) {
        console.warn('Failed to add queued ICE candidate:', err);
      }
    }
    pendingCandidatesRef.current[peerId] = [];
  };

  const createPeerConnection = (peerId, initiator, stream = null) => {
    try {
      if (peersRef.current[peerId]?.pc) {
        peersRef.current[peerId].pc.close();
      }

      const pc = new RTCPeerConnection(ICE_SERVERS);
      const activeStream = stream || localStream;

      if (activeStream) {
        activeStream.getTracks().forEach(track => {
          pc.addTrack(track, activeStream);
        });
      }

      pc.onicecandidate = (event) => {
        if (event.candidate && socketRef.current) {
          socketRef.current.emit('webrtc_ice_candidate', {
            targetUserId: peerId,
            candidate: event.candidate,
            roomId: currentRoomRef.current
          });
        }
      };

      pc.ontrack = (event) => {
        peersRef.current[peerId] = { ...peersRef.current[peerId], stream: event.streams[0] };
        setPeers({ ...peersRef.current });
      };

      pc.onconnectionstatechange = () => {
        const state = pc.connectionState;
        if (state === 'failed' || state === 'disconnected') {
          const attempts = reconnectAttemptsRef.current[peerId] || 0;
          if (attempts < MAX_RECONNECT_ATTEMPTS) {
            reconnectAttemptsRef.current[peerId] = attempts + 1;
            console.log(`Reconnecting to peer ${peerId}, attempt ${attempts + 1}`);
            setTimeout(() => {
              createPeerConnection(peerId, true, activeStream);
            }, 1000 * (attempts + 1));
          } else {
            console.warn(`Max reconnect attempts reached for peer ${peerId}`);
            toast.error('فشل الاتصال بأحد المشاركين');
          }
        } else if (state === 'connected') {
          reconnectAttemptsRef.current[peerId] = 0;
        }
      };

      if (initiator) {
        pc.createOffer().then(offer => {
          pc.setLocalDescription(offer);
          socketRef.current.emit('webrtc_offer', {
            targetUserId: peerId,
            sdp: offer,
            roomId: currentRoomRef.current
          });
        }).catch(err => console.error('Create offer error:', err));
      }

      pendingCandidatesRef.current[peerId] = pendingCandidatesRef.current[peerId] || [];
      peersRef.current[peerId] = { ...peersRef.current[peerId], pc };
      return pc;
    } catch (err) {
      console.error('Peer connection error:', err);
      return null;
    }
  };

  useEffect(() => {
    fetchRooms();
    loadSessionStats();
    return () => {
      stopLocalStream();
      leaveRoom();
    };
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    if (pomodoro.remainingSeconds === 0 && !pomodoro.isPaused) {
      if (!pomodoro.isBreak) {
        setPomodoro(prev => ({ ...prev, sessions: prev.sessions + 1, isBreak: true, remainingSeconds: prev.breakTime * 60 }));
      } else {
        setPomodoro(prev => ({ ...prev, isBreak: false, remainingSeconds: prev.focusTime * 60 }));
      }
    }
  }, [pomodoro.remainingSeconds, pomodoro.isPaused]);

  useEffect(() => {
    if (pomodoro.isPaused || currentRoom === null) return;
    const interval = setInterval(() => setPomodoro(prev => (prev.isPaused || prev.remainingSeconds <= 0) ? prev : { ...prev, remainingSeconds: prev.remainingSeconds - 1 }), 1000);
    return () => clearInterval(interval);
  }, [pomodoro.isPaused, currentRoom]);

  const loadSessionStats = () => {
    const saved = localStorage.getItem('studyRoomStats');
    if (saved) setSessionStats(JSON.parse(saved));
  };

  const fetchRooms = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/rooms`, { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error('خطأ');
      const data = await res.json();
      setRooms(data.rooms || []);
    } catch (err) {
      console.error(err);
    } finally { setLoading(false); }
  };

  const createRoom = async () => {
    if (!createForm.name.trim()) { toast.error('أدخل اسم الغرفة'); return; }
    setCreating(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/rooms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(createForm),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      await joinRoom(data.room.id);
      setShowCreateModal(false);
      toast.success('تم إنشاء الغرفة');
    } catch (err) { toast.error(err.message); } finally { setCreating(false); }
  };

  const joinRoom = async (roomId) => {
    const stream = await getLocalStream();

    const socket = getSocket();
    socketRef.current = socket;
    currentRoomRef.current = roomId;

    if (socket.connected) socket.emit('join_room', { roomId });
    else { socket.connect(); socket.once('connect', () => socket.emit('join_room', { roomId })); }

    socket.off('room_state').off('user_joined').off('user_left').off('new_message').off('new_reaction')
      .off('pomodoro_started').off('pomodoro_paused').off('pomodoro_resumed').off('pomodoro_reset').off('error')
      .off('user_status_changed').off('focus_scores_updated')
      .off('webrtc_offer').off('webrtc_answer').off('webrtc_ice_candidate');

    socket.on('room_state', ({ participants: p, messages: m, pomodoroState }) => {
      setParticipants(p || []);
      setChatMessages(m || []);
      if (pomodoroState) setPomodoro(prev => ({ ...prev, ...pomodoroState }));

      (p || []).forEach(participant => {
        if (participant.user_id !== user?.id && !peersRef.current[participant.user_id]?.pc) {
          createPeerConnection(participant.user_id, false, stream);
        }
      });
    });

    socket.on('user_joined', async ({ userId, userName }) => {
      toast.success(`${userName} انضم`);
      createPeerConnection(userId, true, stream);
    });

    socket.on('user_left', ({ userId, userName }) => {
      toast(`${userName} غادر`);
      if (peersRef.current[userId]) {
        peersRef.current[userId].pc?.close();
        delete peersRef.current[userId];
        delete pendingCandidatesRef.current[userId];
        delete reconnectAttemptsRef.current[userId];
        setPeers({ ...peersRef.current });
      }
    });

    socket.on('new_message', (msg) => {
      setChatMessages(prev => [...prev, { ...msg, id: msg.id || Date.now() }]);
    });

    socket.on('new_reaction', ({ userName, reaction }) => {
      const id = Date.now() + Math.random();
      setReactions(prev => [...prev, { userName, reaction, id }]);
      setTimeout(() => setReactions(prev => prev.filter(r => r.id !== id)), 3000);
    });

    socket.on('pomodoro_started', (state) => setPomodoro({ ...state }));
    socket.on('pomodoro_paused', ({ remainingSeconds }) => setPomodoro(prev => ({ ...prev, remainingSeconds, isPaused: true })));
    socket.on('pomodoro_resumed', ({ remainingSeconds }) => setPomodoro(prev => ({ ...prev, remainingSeconds, isPaused: false })));
    socket.on('pomodoro_reset', () => setPomodoro({ remainingSeconds: 25 * 60, isBreak: false, isPaused: true, sessions: 0, focusTime: 25, breakTime: 5 }));
    socket.on('error', ({ message }) => toast.error(message));

    socket.on('user_status_changed', ({ userId, status }) => {
      setParticipants(prev => prev.map(p => p.user_id === userId ? { ...p, status } : p));
    });

    socket.on('webrtc_offer', async ({ fromUserId, sdp }) => {
      try {
        let peer = peersRef.current[fromUserId];
        if (!peer?.pc) {
          createPeerConnection(fromUserId, false, stream);
          peer = peersRef.current[fromUserId];
        }
        if (peer?.pc) {
          await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
          await flushPendingCandidates(fromUserId);
          const answer = await peer.pc.createAnswer();
          await peer.pc.setLocalDescription(answer);
          socketRef.current.emit('webrtc_answer', { targetUserId: fromUserId, sdp: answer, roomId: currentRoomRef.current });
        }
      } catch (err) {
        console.error('Handle offer error:', err);
      }
    });

    socket.on('webrtc_answer', async ({ fromUserId, sdp }) => {
      try {
        const peer = peersRef.current[fromUserId];
        if (peer?.pc) {
          await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
          await flushPendingCandidates(fromUserId);
        }
      } catch (err) {
        console.error('Handle answer error:', err);
      }
    });

    socket.on('webrtc_ice_candidate', async ({ fromUserId, candidate }) => {
      try {
        const peer = peersRef.current[fromUserId];
        if (peer?.pc && peer.pc.remoteDescription) {
          await peer.pc.addIceCandidate(new RTCIceCandidate(candidate));
        } else {
          if (!pendingCandidatesRef.current[fromUserId]) {
            pendingCandidatesRef.current[fromUserId] = [];
          }
          pendingCandidatesRef.current[fromUserId].push(candidate);
        }
      } catch (err) {
        console.error('Handle ICE candidate error:', err);
      }
    });

    setCurrentRoom(roomId);
    setView('room');
  };

  const leaveRoom = () => {
    stopLocalStream();
    Object.values(peersRef.current).forEach(peer => {
      peer.pc?.close();
    });
    peersRef.current = {};
    pendingCandidatesRef.current = {};
    reconnectAttemptsRef.current = {};
    setPeers({});

    if (socketRef.current && currentRoom) {
      socketRef.current.emit('leave_room', { roomId: currentRoom });
      disconnectSocket();
      socketRef.current = null;
    }
    currentRoomRef.current = null;
    setCurrentRoom(null);
    setParticipants([]);
    setChatMessages([]);
    setPomodoro({ remainingSeconds: 25 * 60, isBreak: false, isPaused: true, sessions: 0, focusTime: 25, breakTime: 5 });
    setView('list');
    fetchRooms();
  };

  const sendMessage = (e) => {
    e.preventDefault();
    if (!newMsg.trim() || !socketRef.current) return;
    socketRef.current.emit('chat_message', { roomId: currentRoom, text: newMsg.trim() });
    setNewMsg('');
  };

  const sendReaction = (reaction) => {
    if (!socketRef.current) return;
    socketRef.current.emit('send_reaction', { roomId: currentRoom, reaction });
  };

  const updateStatus = (status) => {
    setUserStatus(status);
    if (socketRef.current) {
      socketRef.current.emit('update_status', { roomId: currentRoom, status });
    }
  };

  const pomodoroAction = (action) => {
    if (!socketRef.current) return;
    socketRef.current.emit(action, { roomId: currentRoom });
  };

  const formatTime = (secs) => `${Math.floor(secs / 60).toString().padStart(2, '0')}:${(secs % 60).toString().padStart(2, '0')}`;

  const roomInfo = rooms.find(r => r.id === currentRoom);
  const isHost = currentRoom && user && roomInfo?.host_id === user.id;
  const circumference = 2 * Math.PI * 120;
  const progress = pomodoro.isBreak ? ((5 * 60 - pomodoro.remainingSeconds) / (5 * 60)) * 100 : ((25 * 60 - pomodoro.remainingSeconds) / (25 * 60)) * 100;
  const dashOffset = circumference - (progress / 100) * circumference;

  const allParticipants = [
    { user_id: user?.id, user_name: user?.name || user?.email?.split('@')[0], name: user?.name, status: userStatus, focus_score: 50, hasAudio: micOn, isSelf: true },
    ...participants.filter(p => p.user_id !== user?.id)
  ];

  const pinnedParticipantData = pinnedParticipant ? allParticipants.find(p => p.user_id === pinnedParticipant) : null;
  const displayParticipants = pinnedParticipantData
    ? [pinnedParticipantData, ...allParticipants.filter(p => p.user_id !== pinnedParticipant)]
    : allParticipants;

  const getGridClass = () => {
    const count = allParticipants.length;
    if (count <= 1) return 'grid-cols-1';
    if (count === 2) return 'grid-cols-2';
    if (count <= 4) return 'grid-cols-2';
    if (count <= 6) return 'grid-cols-3';
    if (count <= 9) return 'grid-cols-3';
    return 'grid-cols-4';
  };

  const getParticipantStream = (userId) => {
    return peers[userId]?.stream || null;
  };

  if (view === 'list') {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Video className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">غرف الفيديو</h1>
              <p className="text-sm text-gray-500">ادرس مع أصدقائك face-to-face</p>
            </div>
          </div>
          <button onClick={() => setShowCreateModal(true)} className="btn-primary flex items-center gap-2 px-6 py-3">
            <Plus className="w-5 h-5" /> غرفة جديدة
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="card text-center bg-gradient-to-br from-orange-500/10 to-orange-500/5">
            <div className="text-2xl font-bold">{sessionStats.sessions}</div>
            <div className="text-xs text-gray-500">الجلسات</div>
          </div>
          <div className="card text-center bg-gradient-to-br from-blue-500/10 to-blue-500/5">
            <div className="text-2xl font-bold">{sessionStats.totalMinutes}</div>
            <div className="text-xs text-gray-500">دقيقة تركيز</div>
          </div>
          <div className="card text-center bg-gradient-to-br from-yellow-500/10 to-yellow-500/5">
            <div className="text-2xl font-bold">{sessionStats.streak}</div>
            <div className="text-xs text-gray-500">أيام متتالية</div>
          </div>
          <div className="card text-center bg-gradient-to-br from-purple-500/10 to-purple-500/5">
            <div className="text-2xl font-bold">{rooms.reduce((sum, r) => sum + (r.user_count || 0), 0)}</div>
            <div className="text-xs text-gray-500">متصل الآن</div>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-green-500" />
          </div>
        ) : rooms.length === 0 ? (
          <div className="card text-center py-16">
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Video className="w-12 h-12 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-2">لا توجد غرف نشطة</h3>
            <button onClick={() => setShowCreateModal(true)} className="btn-primary px-8 py-3">إنشاء غرفة</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rooms.map(room => {
              const t = ROOM_TYPES[room.type] || ROOM_TYPES.focus;
              const Icon = t.icon;
              return (
                <div key={room.id} className="card hover:border-green-500/50 cursor-pointer group" onClick={() => joinRoom(room.id)}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-14 h-14 rounded-2xl ${t.bg} flex items-center justify-center`}>
                        <Icon className={`w-7 h-7 ${t.color}`} />
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{room.name}</h3>
                        <span className="text-xs text-gray-500">{t.label}</span>
                      </div>
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full ${room.user_count >= room.max_users ? 'bg-red-500/10 text-red-500' : 'bg-green-500/10 text-green-500'}`}>
                      {room.user_count}/{room.max_users}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-gray-500">مضيف: {room.host_name}</p>
                    <button className="btn-primary text-sm">انضم</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {showCreateModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCreateModal(false)}>
            <div className="card max-w-md w-full space-y-6" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold">إنشاء غرفة جديدة</h2>
                <button onClick={() => setShowCreateModal(false)}><X className="w-5 h-5" /></button>
              </div>
              <input type="text" placeholder="اسم الغرفة" className="input-field text-lg" value={createForm.name} onChange={e => setCreateForm(f => ({ ...f, name: e.target.value }))} />
              <div className="grid grid-cols-3 gap-3">
                {Object.entries(ROOM_TYPES).map(([key, info]) => {
                  const Icon = info.icon;
                  return (
                    <button key={key} onClick={() => setCreateForm(f => ({ ...f, type: key }))} className={`p-4 rounded-xl border-2 text-center ${createForm.type === key ? 'border-green-500 bg-green-500/10' : 'border-gray-200 dark:border-gray-700'}`}>
                      <Icon className={`w-8 h-8 mx-auto mb-2 ${info.color}`} />
                      <span className="font-medium">{info.label}</span>
                    </button>
                  );
                })}
              </div>
              <button onClick={createRoom} disabled={creating || !createForm.name.trim()} className="btn-primary w-full py-3 disabled:opacity-50">
                {creating ? 'جاري...' : 'إنشاء'}
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="h-[calc(100vh-2rem)] flex flex-col bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-2xl overflow-hidden">
      <div className="flex items-center justify-between p-4 bg-black/20">
        <div>
          <h2 className="text-lg font-bold text-white">{roomInfo?.name}</h2>
          <p className="text-sm text-white/60">{allParticipants.length} مشارك</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setLayout(layout === 'speaker' ? 'grid' : 'speaker')} className="p-2 bg-white/10 rounded-lg hover:bg-white/20">
            {layout === 'speaker' ? <Grid className="w-5 h-5 text-white" /> : <Layout className="w-5 h-5 text-white" />}
          </button>
          <button onClick={() => setShowParticipants(!showParticipants)} className={`p-2 rounded-lg ${showParticipants ? 'bg-green-500' : 'bg-white/10 hover:bg-white/20'}`}>
            <Users className="w-5 h-5 text-white" />
          </button>
          <button onClick={() => setShowChat(!showChat)} className={`p-2 rounded-lg ${showChat ? 'bg-green-500' : 'bg-white/10 hover:bg-white/20'}`}>
            <MessageCircle className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      <div className="flex-1 flex gap-2 p-2 min-h-0">
        <div className="flex-1 relative">
          {reactions.map(r => (
            <div key={r.id} className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-6xl animate-bounce z-50">
              {r.reaction}
            </div>
          ))}

          <div className={`grid ${getGridClass()} gap-2 h-full auto-rows-fr`}>
            {displayParticipants.map(p => (
              <VideoTile
                key={p.user_id}
                stream={p.isSelf ? localStream : getParticipantStream(p.user_id)}
                participant={p}
                isSelf={p.isSelf}
                isPinned={pinnedParticipant === p.user_id}
                onPin={() => setPinnedParticipant(pinnedParticipant === p.user_id ? null : p.user_id)}
              />
            ))}
          </div>
        </div>

        {showParticipants && (
          <div className="w-64 bg-surface-light dark:bg-surface-dark rounded-xl p-3 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm">المشاركين ({allParticipants.length})</h3>
              <button onClick={() => setShowParticipants(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-2 flex-1 overflow-y-auto">
              {allParticipants.map(p => (
                <ParticipantItem key={p.user_id} participant={p} isSelf={p.isSelf} />
              ))}
            </div>
          </div>
        )}

        {showChat && (
          <div className="w-72 bg-surface-light dark:bg-surface-dark rounded-xl p-3 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm">الشات</h3>
              <button onClick={() => setShowChat(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 mb-3">
              {chatMessages.filter(m => m.type !== 'system').map(msg => (
                <div key={msg.id} className={`${msg.user_id === user?.id ? 'ml-auto' : ''}`}>
                  <div className={`max-w-[90%] px-3 py-2 rounded-xl ${msg.user_id === user?.id ? 'bg-green-500 text-white' : 'bg-gray-100 dark:bg-gray-800'}`}>
                    <p className="text-sm">{msg.text}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
            <form onSubmit={sendMessage} className="flex gap-2">
              <input type="text" placeholder="رسالة..." className="input-field text-sm flex-1" value={newMsg} onChange={e => setNewMsg(e.target.value)} />
              <button type="submit" className="p-2 bg-green-500 rounded-lg"><Send className="w-4 h-4 text-white" /></button>
            </form>
          </div>
        )}
      </div>

      <div className="p-4 bg-black/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="relative w-14 h-14">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="45" fill="none" className="stroke-white/10" strokeWidth="6" />
                  <circle cx="50" cy="50" r="45" fill="none" className="stroke-green-500" strokeWidth="6" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={dashOffset} style={{ transition: 'stroke-dashoffset 1s linear' }} />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold text-white" dir="ltr">{formatTime(pomodoro.remainingSeconds)}</span>
                </div>
              </div>
              <div>
                <p className="text-sm font-bold text-white">{pomodoro.isBreak ? 'راحة' : 'تركيز'}</p>
                <p className="text-xs text-white/60">الجلسة {pomodoro.sessions + 1}</p>
              </div>
            </div>

            {isHost && (
              <div className="flex items-center gap-1">
                <button onClick={() => pomodoroAction('reset_pomodoro')} className="p-2 bg-white/10 rounded-lg hover:bg-white/20">
                  <RotateCcw className="w-4 h-4 text-white" />
                </button>
                {pomodoro.isPaused ? (
                  <button onClick={() => pomodoroAction('start_pomodoro')} className="p-2 bg-green-500 rounded-lg">
                    <Play className="w-4 h-4 text-white" />
                  </button>
                ) : (
                  <button onClick={() => pomodoroAction('pause_pomodoro')} className="p-2 bg-yellow-500 rounded-lg">
                    <Pause className="w-4 h-4 text-white" />
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {REACTIONS.map(r => (
              <button key={r} onClick={() => sendReaction(r)} className="p-2 text-xl hover:bg-white/10 rounded-lg">
                {r}
              </button>
            ))}
            <div className="w-px h-8 bg-white/20" />
            <button
              onClick={() => {
                if (micOn && localStream) {
                  localStream.getAudioTracks().forEach(t => t.enabled = false);
                  setMicOn(false);
                } else if (localStream) {
                  localStream.getAudioTracks().forEach(t => t.enabled = true);
                  setMicOn(true);
                }
              }}
              className={`p-3 rounded-xl ${micOn ? 'bg-green-500' : 'bg-red-500'}`}
            >
              {micOn ? <Mic className="w-5 h-5 text-white" /> : <MicOff className="w-5 h-5 text-white" />}
            </button>
            <button
              onClick={() => {
                if (cameraOn) {
                  stopLocalStream();
                } else {
                  getLocalStream();
                }
              }}
              className={`p-3 rounded-xl ${cameraOn ? 'bg-red-500' : 'bg-white/10 hover:bg-white/20'}`}
            >
              {cameraOn ? <Video className="w-5 h-5 text-white" /> : <Video className="w-5 h-5 text-white" />}
            </button>
          </div>

          <button onClick={leaveRoom} className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl">
            <PhoneOff className="w-5 h-5" />
            مغادرة
          </button>
        </div>
      </div>
    </div>
  );
}
