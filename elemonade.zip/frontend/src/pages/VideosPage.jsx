import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../lib/apiClient';
import { Play, Clock, ChevronLeft, Loader2, Search, Filter } from 'lucide-react';

export default function VideosPage() {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');

  useEffect(() => {
    api.get('/admin/resources')
      .then(d => {
        const videoList = d.resources?.filter(r => r.type === 'video') || [];
        setVideos(videoList);
      })
      .catch(() => setVideos([]))
      .finally(() => setLoading(false));
  }, []);

  const getYouTubeId = (url) => {
    if (!url) return null;
    const match = url.match(/(?:youtube\.com.*v=|youtu\.be\/)([^&\n?#]+)/);
    return match ? match[1] : null;
  };

  // Filter videos
  const filteredVideos = videos.filter(v => {
    const matchesSearch = !search || 
      v.title?.toLowerCase().includes(search.toLowerCase()) ||
      v.description?.toLowerCase().includes(search.toLowerCase());
    const matchesSubject = !subjectFilter || v.subject === subjectFilter;
    return matchesSearch && matchesSubject;
  });

  // Get unique subjects for filter
  const subjects = [...new Set(videos.map(v => v.subject).filter(Boolean))];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/" className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold">فيديوهاتي</h1>
            <p className="text-gray-500">شاهد تجاربي ومحتواهي التعليمي</p>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث في الفيديوهات..."
              className="input-field w-full pr-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select
            className="input-field"
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
          >
            <option value="">كل المواد</option>
            {subjects.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
          </div>
        ) : filteredVideos.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-gray-800 rounded-2xl">
            <Play className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">لا توجد فيديوهات متطابقة</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {filteredVideos.map(video => {
              const ytId = getYouTubeId(video.content_url);
              return (
                <div key={video.id} className="bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                  {ytId ? (
                    <div className="aspect-video">
                      <iframe
                        className="w-full h-full"
                        src={`https://www.youtube.com/embed/${ytId}`}
                        title={video.title}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  ) : (
                    <div className="aspect-video bg-gradient-to-br from-indigo-900 to-purple-900 flex items-center justify-center">
                      <Play className="w-16 h-16 text-white/50" />
                    </div>
                  )}
                  <div className="p-4">
                    <h3 className="font-bold text-lg mb-2">{video.title}</h3>
                    <div className="flex items-center gap-2 text-gray-500 text-sm">
                      <Clock className="w-4 h-4" />
                      <span>{video.created_at ? new Date(video.created_at).toLocaleDateString('ar-EG') : '最近'}</span>
                    </div>
                    {video.lesson_name && (
                      <p className="text-xs text-gray-400 mt-2">
                        {video.subject_name} • {video.unit_name} • {video.lesson_name}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
