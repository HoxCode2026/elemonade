import { useEffect, useState } from 'react';
import { api } from '../../lib/apiClient';
import toast from 'react-hot-toast';
import { Video, Plus, Trash2, Edit3, Save, X, Sparkles, Send, Loader2 } from 'lucide-react';

export default function AdminVideos() {
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);

  // Curriculum selectors
  const [systems, setSystems] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [units, setUnits] = useState([]);
  const [selSystem, setSelSystem] = useState('');
  const [selTrack, setSelTrack] = useState('');
  const [selSubject, setSelSubject] = useState('');
  const [selUnit, setSelUnit] = useState('');
  const [selLesson, setSelLesson] = useState('');

  // Form
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: '', content_url: '' });

  // AI
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  const fetchVideos = async () => {
    const d = await api.get('/admin/resources');
    setResources(d.resources.filter(r => r.type === 'video'));
    setLoading(false);
  };

  useEffect(() => {
    Promise.all([
      fetchVideos(),
      api.get('/curriculum/systems').then(d => setSystems(d.systems)),
    ]);
  }, []);

  const onSystemChange = async (sysId) => {
    setSelSystem(sysId); setSelTrack(''); setSelSubject(''); setSelUnit(''); setSelLesson('');
    setTracks([]); setSubjects([]); setUnits([]);
    if (sysId) { const d = await api.get(`/curriculum/systems/${sysId}/tracks`); setTracks(d.tracks); }
  };
  const onTrackChange = async (trackId) => {
    setSelTrack(trackId); setSelSubject(''); setSelUnit(''); setSelLesson('');
    setSubjects([]); setUnits([]);
    if (trackId) { const d = await api.get(`/curriculum/tracks/${trackId}/subjects`); setSubjects(d.subjects); }
  };
  const onSubjectChange = async (subjId) => {
    setSelSubject(subjId); setSelUnit(''); setSelLesson('');
    setUnits([]);
    if (subjId) { const d = await api.get(`/curriculum/subjects/${subjId}/units`); setUnits(d.units); }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.post('/admin/resources', {
        lesson_id: parseInt(selLesson),
        type: 'video',
        title: form.title,
        content_url: form.content_url,
      });
      toast.success('تم إضافة الفيديو');
      setShowForm(false);
      setForm({ title: '', content_url: '' });
      fetchVideos();
    } catch (err) {
      toast.error(err.message || 'فشلت الإضافة');
    }
  };

  const deleteVideo = async (id) => {
    if (!confirm('هل أنت متأكد؟')) return;
    try {
      await api.delete(`/admin/resources/${id}`);
      toast.success('تم الحذف');
      fetchVideos();
    } catch {
      toast.error('فشل الحذف');
    }
  };

  const generateWithAI = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    try {
      const d = await api.post('/ai/chat', {
        message: `أنشئ وصف تعليمي ومحتوى نصي لفيديو تعليمي عن: ${aiPrompt}. اكتب عنوان مناسب ووصف مختصر ونقاط رئيسية.`,
      });
      setAiResult(d.response);
    } catch (err) {
      toast.error('فشل الاتصال بالذكاء الاصطناعي');
    }
    setAiLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold">إدارة الفيديوهات ({resources.length})</h3>
        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-primary text-sm flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة فيديو
        </button>
      </div>

      {/* Add Video Form */}
      {showForm && (
        <div className="card border-primary-500/30">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold">إضافة فيديو جديد</h4>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Curriculum Selection */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
            <select value={selSystem} onChange={e => onSystemChange(e.target.value)} className="input-field text-sm">
              <option value="">النظام</option>
              {systems.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select value={selTrack} onChange={e => onTrackChange(e.target.value)} className="input-field text-sm" disabled={!selSystem}>
              <option value="">الشعبة</option>
              {tracks.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <select value={selSubject} onChange={e => onSubjectChange(e.target.value)} className="input-field text-sm" disabled={!selTrack}>
              <option value="">المادة</option>
              {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <select value={selUnit} onChange={e => { setSelUnit(e.target.value); setSelLesson(''); }} className="input-field text-sm" disabled={!selSubject}>
              <option value="">الوحدة</option>
              {units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <select value={selLesson} onChange={e => setSelLesson(e.target.value)} className="input-field text-sm" disabled={!selUnit}>
              <option value="">الدرس</option>
              {units.find(u => u.id === parseInt(selUnit))?.lessons?.map(l => (
                <option key={l.id} value={l.id}>{l.name}</option>
              ))}
            </select>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <input
              type="text" placeholder="عنوان الفيديو" value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              className="input-field text-sm" required
            />
            <input
              type="url" placeholder="رابط YouTube" value={form.content_url}
              onChange={e => setForm({ ...form, content_url: e.target.value })}
              className="input-field text-sm" dir="ltr" required
            />
            <button type="submit" disabled={!selLesson} className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50">
              <Save className="w-4 h-4" />
              حفظ الفيديو
            </button>
          </form>
        </div>
      )}

      {/* AI Content Generator */}
      <div className="card border-purple-500/20">
        <h4 className="font-bold mb-3 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-500" />
          إنشاء محتوى بالذكاء الاصطناعي
        </h4>
        <p className="text-xs text-gray-500 mb-3">بديل إنشاء الفيديو - أنشئ محتوى نصي تعليمي بالـ AI</p>

        <div className="flex gap-2 mb-3">
          <input
            type="text"
            placeholder="مثال: شرح درس الحديد في الكيمياء للثانوية العامة"
            value={aiPrompt}
            onChange={e => setAiPrompt(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && generateWithAI()}
            className="input-field text-sm flex-1"
          />
          <button
            onClick={generateWithAI}
            disabled={aiLoading || !aiPrompt.trim()}
            className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50"
          >
            {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {aiLoading ? 'جاري...' : 'إنشاء'}
          </button>
        </div>

        {aiResult && (
          <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-4 text-sm whitespace-pre-wrap leading-relaxed">
            {aiResult}
          </div>
        )}
      </div>

      {/* Videos List */}
      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="skeleton h-16" />)}</div>
      ) : resources.length === 0 ? (
        <div className="card text-center py-10">
          <Video className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <p className="text-gray-500">لا توجد فيديوهات مضافة بعد</p>
        </div>
      ) : (
        <div className="space-y-2">
          {resources.map(res => (
            <div key={res.id} className="card py-3 px-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Video className="w-5 h-5 text-red-500" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{res.title}</p>
                <p className="text-xs text-gray-500 truncate">
                  {res.subject_name} &gt; {res.unit_name} &gt; {res.lesson_name}
                </p>
                {res.content_url && (
                  <a href={res.content_url} target="_blank" rel="noreferrer"
                    className="text-xs text-primary-500 hover:underline" dir="ltr">
                    {res.content_url.substring(0, 50)}...
                  </a>
                )}
              </div>
              <button onClick={() => deleteVideo(res.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
                <Trash2 className="w-4 h-4 text-red-400" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
