import { useEffect, useState } from 'react';
import { api } from '../../lib/apiClient';
import toast from 'react-hot-toast';
import { Plus, Trash2, Edit3, Eye, EyeOff, Save, X, Megaphone } from 'lucide-react';

const SLOTS = [
  { value: 'page_top', label: 'أعلى الصفحة' },
  { value: 'home_sidebar', label: 'الشريط الجانبي - الرئيسية' },
  { value: 'schedule_header', label: 'أعلى صفحة الجدول' },
  { value: 'study_room', label: 'غرفة المذاكرة' },
  { value: 'curriculum_top', label: 'أعلى صفحة المناهج' },
  { value: 'popup_global', label: 'نافذة منبثقة عامة' },
];

const emptyForm = {
  name: '', type: 'banner', slot: 'page_top', content_html: '',
  image_url: '', link_url: '', start_date: '', end_date: '',
};

export default function AdminAds() {
  const [ads, setAds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ ...emptyForm });

  const fetchAds = async () => {
    const d = await api.get('/admin/ads');
    setAds(d.ads);
    setLoading(false);
  };

  useEffect(() => { fetchAds(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await api.put(`/admin/ads/${editId}`, form);
        toast.success('تم تحديث الإعلان');
      } else {
        await api.post('/admin/ads', form);
        toast.success('تم إضافة الإعلان');
      }
      setShowForm(false);
      setEditId(null);
      setForm({ ...emptyForm });
      fetchAds();
    } catch (err) {
      toast.error(err.message || 'فشلت العملية');
    }
  };

  const startEdit = (ad) => {
    setEditId(ad.id);
    setForm({
      name: ad.name, type: ad.type, slot: ad.slot, content_html: ad.content_html,
      image_url: ad.image_url || '', link_url: ad.link_url || '',
      start_date: ad.start_date || '', end_date: ad.end_date || '',
    });
    setShowForm(true);
  };

  const toggleActive = async (ad) => {
    try {
      await api.put(`/admin/ads/${ad.id}`, { is_active: !ad.is_active });
      toast.success(ad.is_active ? 'تم إيقاف الإعلان' : 'تم تفعيل الإعلان');
      fetchAds();
    } catch {
      toast.error('فشل التحديث');
    }
  };

  const deleteAd = async (id) => {
    if (!confirm('هل أنت متأكد من حذف هذا الإعلان؟')) return;
    try {
      await api.delete(`/admin/ads/${id}`);
      toast.success('تم حذف الإعلان');
      fetchAds();
    } catch {
      toast.error('فشل الحذف');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold">الإعلانات ({ads.length})</h3>
        <button
          onClick={() => { setShowForm(!showForm); setEditId(null); setForm({ ...emptyForm }); }}
          className="btn-primary text-sm flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة إعلان
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card border-primary-500/30">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold">{editId ? 'تعديل إعلان' : 'إعلان جديد'}</h4>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
              <input
                type="text" placeholder="اسم الحملة" value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                className="input-field text-sm" required
              />
              <select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })} className="input-field text-sm">
                <option value="banner">بانر</option>
                <option value="popup">نافذة منبثقة</option>
              </select>
              <select value={form.slot} onChange={e => setForm({ ...form, slot: e.target.value })} className="input-field text-sm">
                {SLOTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </div>

            <textarea
              placeholder="كود HTML للإعلان" value={form.content_html}
              onChange={e => setForm({ ...form, content_html: e.target.value })}
              className="input-field text-sm h-24 resize-none font-mono" dir="ltr" required
            />

            <div className="grid grid-cols-2 gap-3">
              <input
                type="url" placeholder="رابط الصورة (اختياري)" value={form.image_url}
                onChange={e => setForm({ ...form, image_url: e.target.value })}
                className="input-field text-sm" dir="ltr"
              />
              <input
                type="url" placeholder="رابط الإعلان (اختياري)" value={form.link_url}
                onChange={e => setForm({ ...form, link_url: e.target.value })}
                className="input-field text-sm" dir="ltr"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <input
                type="date" placeholder="تاريخ البدء" value={form.start_date}
                onChange={e => setForm({ ...form, start_date: e.target.value })}
                className="input-field text-sm"
              />
              <input
                type="date" placeholder="تاريخ الانتهاء" value={form.end_date}
                onChange={e => setForm({ ...form, end_date: e.target.value })}
                className="input-field text-sm"
              />
            </div>

            <button type="submit" className="btn-primary text-sm flex items-center gap-2">
              <Save className="w-4 h-4" />
              {editId ? 'تحديث' : 'حفظ'}
            </button>
          </form>
        </div>
      )}

      {/* Ads List */}
      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="skeleton h-16" />)}</div>
      ) : ads.length === 0 ? (
        <div className="card text-center py-10">
          <Megaphone className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <p className="text-gray-500">لا توجد إعلانات بعد</p>
        </div>
      ) : (
        <div className="space-y-2">
          {ads.map(ad => (
            <div key={ad.id} className="card py-3 px-4 flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full flex-shrink-0 ${ad.is_active ? 'bg-green-500' : 'bg-gray-400'}`} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm">{ad.name}</p>
                <p className="text-xs text-gray-500">
                  {ad.type === 'banner' ? 'بانر' : 'منبثقة'} | {SLOTS.find(s => s.value === ad.slot)?.label || ad.slot}
                </p>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => toggleActive(ad)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
                  {ad.is_active ? <Eye className="w-4 h-4 text-green-500" /> : <EyeOff className="w-4 h-4 text-gray-400" />}
                </button>
                <button onClick={() => startEdit(ad)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
                  <Edit3 className="w-4 h-4 text-gray-400" />
                </button>
                <button onClick={() => deleteAd(ad.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
