import { useEffect, useState } from 'react';
import { api } from '../../lib/apiClient';
import { Users, Calendar, CheckSquare, Flame, TrendingUp } from 'lucide-react';

export default function AdminOverview() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/admin/stats').then(d => {
      setStats(d.stats);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[1,2,3,4].map(i => <div key={i} className="skeleton h-28" />)}
      </div>
    );
  }

  const cards = [
    { icon: Users, label: 'إجمالي المستخدمين', value: stats?.users || 0, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { icon: Calendar, label: 'الجداول النشطة', value: stats?.active_schedules || 0, color: 'text-green-500', bg: 'bg-green-500/10' },
    { icon: CheckSquare, label: 'إجمالي تسجيلات الحضور', value: stats?.total_checkins || 0, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { icon: Flame, label: 'متوسط التتابع', value: stats?.average_streak || 0, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card, i) => (
          <div key={i} className="card text-center">
            <div className={`w-12 h-12 ${card.bg} rounded-xl flex items-center justify-center mx-auto mb-3`}>
              <card.icon className={`w-6 h-6 ${card.color}`} />
            </div>
            <div className="text-2xl font-bold">{card.value}</div>
            <div className="text-xs text-gray-500 mt-1">{card.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-primary-500" />
          ملخص سريع
        </h3>
        <div className="space-y-3 text-sm text-gray-600 dark:text-gray-400">
          <p>المنصة تعمل بشكل طبيعي. يمكنك إدارة المستخدمين والمصادر التعليمية والإعلانات من التبويبات أعلاه.</p>
          <p>حساب المشرف: admin@hossamfathy.com</p>
        </div>
      </div>
    </div>
  );
}
