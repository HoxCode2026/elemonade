import { NavLink, Outlet } from 'react-router-dom';
import { BarChart3, Users, BookOpen, Megaphone, Video } from 'lucide-react';

const adminNav = [
  { to: '/admin', icon: BarChart3, label: 'نظرة عامة', end: true },
  { to: '/admin/users', icon: Users, label: 'المستخدمين' },
  { to: '/admin/resources', icon: BookOpen, label: 'المصادر التعليمية' },
  { to: '/admin/ads', icon: Megaphone, label: 'الإعلانات' },
  { to: '/admin/videos', icon: Video, label: 'الفيديوهات' },
];

export default function AdminLayout() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">لوحة التحكم</h1>
        <p className="text-sm text-gray-500">إدارة المنصة والمحتوى</p>
      </div>

      {/* Admin Nav Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {adminNav.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/20'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`
            }
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </NavLink>
        ))}
      </div>

      <Outlet />
    </div>
  );
}
