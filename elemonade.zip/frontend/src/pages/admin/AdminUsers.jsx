import { useEffect, useState } from 'react';
import { api } from '../../lib/apiClient';
import toast from 'react-hot-toast';
import { Shield, User, ChevronRight, ChevronLeft } from 'lucide-react';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, total_pages: 1 });
  const [loading, setLoading] = useState(true);

  const fetchUsers = async (page = 1) => {
    setLoading(true);
    try {
      const d = await api.get(`/admin/users?page=${page}&limit=20`);
      setUsers(d.users);
      setPagination(d.pagination);
    } catch (err) {
      toast.error('فشل تحميل المستخدمين');
    }
    setLoading(false);
  };

  useEffect(() => { fetchUsers(); }, []);

  const toggleRole = async (userId, currentRole) => {
    const newRole = currentRole === 'admin' ? 'student' : 'admin';
    try {
      await api.put(`/admin/users/${userId}/role`, { role: newRole });
      toast.success(`تم تغيير الصلاحية إلى ${newRole === 'admin' ? 'مشرف' : 'طالب'}`);
      fetchUsers(pagination.page);
    } catch {
      toast.error('فشل تحديث الصلاحية');
    }
  };

  if (loading) {
    return <div className="space-y-3">{[1,2,3,4,5].map(i => <div key={i} className="skeleton h-16" />)}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-200 dark:border-gray-800">
                <th className="text-right p-4 font-medium text-gray-500">المستخدم</th>
                <th className="text-right p-4 font-medium text-gray-500">البريد</th>
                <th className="text-right p-4 font-medium text-gray-500">الصلاحية</th>
                <th className="text-right p-4 font-medium text-gray-500">YouTube</th>
                <th className="text-right p-4 font-medium text-gray-500">تاريخ التسجيل</th>
                <th className="text-right p-4 font-medium text-gray-500">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-b border-gray-100 dark:border-gray-800/50 hover:bg-gray-50 dark:hover:bg-gray-800/30">
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-primary-500/20 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-primary-500">{u.name?.charAt(0)}</span>
                      </div>
                      {u.name}
                    </div>
                  </td>
                  <td className="p-4 text-gray-500" dir="ltr">{u.email}</td>
                  <td className="p-4">
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                      u.role === 'admin' ? 'bg-primary-500/10 text-primary-500' : 'bg-gray-100 dark:bg-gray-800 text-gray-500'
                    }`}>
                      {u.role === 'admin' ? <Shield className="w-3 h-3" /> : <User className="w-3 h-3" />}
                      {u.role === 'admin' ? 'مشرف' : 'طالب'}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className={`text-xs ${u.youtube_subscribed ? 'text-green-500' : 'text-gray-400'}`}>
                      {u.youtube_subscribed ? 'مشترك' : 'غير مشترك'}
                    </span>
                  </td>
                  <td className="p-4 text-gray-500 text-xs">
                    {u.created_at ? new Date(u.created_at).toLocaleDateString('ar-EG') : '-'}
                  </td>
                  <td className="p-4">
                    <button
                      onClick={() => toggleRole(u.id, u.role)}
                      className="text-xs text-primary-500 hover:underline"
                    >
                      {u.role === 'admin' ? 'تحويل لطالب' : 'ترقية لمشرف'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {pagination.total_pages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => fetchUsers(pagination.page - 1)}
            disabled={pagination.page <= 1}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-30"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-sm text-gray-500">
            صفحة {pagination.page} من {pagination.total_pages}
          </span>
          <button
            onClick={() => fetchUsers(pagination.page + 1)}
            disabled={pagination.page >= pagination.total_pages}
            className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
