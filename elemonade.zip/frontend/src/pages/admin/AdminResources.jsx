import { useEffect, useState } from 'react';
import { api } from '../../lib/apiClient';
import toast from 'react-hot-toast';
import { Plus, Trash2, Edit3, Play, FileText, Save, X, Search } from 'lucide-react';

export default function AdminResources() {
  const [resources, setResources] = useState([]);
  const [systems, setSystems] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [units, setUnits] = useState([]);
  const [loading, setLoading] = useState(true);

  // Selection state for adding resources
  const [selSystem, setSelSystem] = useState('');
  const [selTrack, setSelTrack] = useState('');
  const [selSubject, setSelSubject] = useState('');
  const [selUnit, setSelUnit] = useState('');
  const [selLesson, setSelLesson] = useState('');

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState({ lesson_id: '', type: 'video', title: '', content_url: '', content_text: '' });

  const fetchResources = async () => {
    const d = await api.get('/admin/resources');
    setResources(d.resources);
    setLoading(false);
  };

  useEffect(() => {
    Promise.all([
      fetchResources(),
      api.get('/curriculum/systems').then(d => setSystems(d.systems)),
    ]);
  }, []);

  const onSystemChange = async (sysId) => {
    setSelSystem(sysId);
    setSelTrack(''); setSelSubject(''); setSelUnit(''); setSelLesson('');
    setTracks([]); setSubjects([]); setUnits([]);
    if (sysId) {
      const d = await api.get(`/curriculum/systems/${sysId}/tracks`);
      setTracks(d.tracks);
    }
  };

  const onTrackChange = async (trackId) => {
    setSelTrack(trackId);
    setSelSubject(''); setSelUnit(''); setSelLesson('');
    setSubjects([]); setUnits([]);
    if (trackId) {
      const d = await api.get(`/curriculum/tracks/${trackId}/subjects`);
      setSubjects(d.subjects);
    }
  };

  const onSubjectChange = async (subjId) => {
    setSelSubject(subjId);
    setSelUnit(''); setSelLesson('');
    setUnits([]);
    if (subjId) {
      const d = await api.get(`/curriculum/subjects/${subjId}/units`);
      setUnits(d.units);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editId) {
        await api.put(`/admin/resources/${editId}`, form);
        toast.success('تم تحديث المصدر');
      } else {
        await api.post('/admin/resources', { ...form, lesson_id: parseInt(selLesson) });
        toast.success('تم إضافة المصدر');
      }
      setShowForm(false);
      setEditId(null);
      setForm({ lesson_id: '', type: 'video', title: '', content_url: '', content_text: '' });
      fetchResources();
    } catch (err) {
      toast.error(err.message || 'فشلت العملية');
    }
  };

  const startEdit = (res) => {
    setEditId(res.id);
    setForm({ lesson_id: res.lesson_id, type: res.type, title: res.title, content_url: res.content_url || '', content_text: res.content_text || '' });
    setShowForm(true);
  };

  const deleteResource = async (id) => {
    if (!confirm('هل أنت متأكد من حذف هذا المصدر؟')) return;
    try {
      await api.delete(`/admin/resources/${id}`);
      toast.success('تم حذف المصدر');
      fetchResources();
    } catch {
      toast.error('فشل الحذف');
    }
  };

  return (
    <div className="space-y-6">
      {/* Add New Button */}
      <div className="flex justify-between items-center">
        <h3 className="font-bold">المصادر التعليمية ({resources.length})</h3>
        <button
          onClick={() => { setShowForm(!showForm); setEditId(null); setForm({ lesson_id: '', type: 'video', title: '', content_url: '', content_text: '' }); }}
          className="btn-primary text-sm flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          إضافة مصدر
        </button>
      </div>

      {/* Add/Edit Form */}
      {showForm && (
        <div className="card border-primary-500/30">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold">{editId ? 'تعديل مصدر' : 'إضافة مصدر جديد'}</h4>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded">
              <X className="w-4 h-4" />
            </button>
          </div>

          {!editId && (
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
              <select value={selSystem} onChange={e => onSystemChange(e.target.value)} className="input-field text-sm">
                <option value="">النظام</option>
                {systems.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <select value={selTrack} onChange={e => onTrackChange(e.target.value)} className="input-field text-sm" disabled={!selSystem}>
                <option value="">الشعبة</option>
                {tracks.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <select value={selSubject} onChange={e => onSubjectChange(e.target.value)} className="input-field text-sm" disabled={!selTrack}>
                <option value="">المادة</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <select value={selUnit} onChange={e => { setSelUnit(e.target.value); setSelLesson(''); }} className="input-field text-sm" disabled={!selSubject}>
                <option value="">الوحدة</option>
                {units.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
              <select value={selLesson} onChange={e => setSelLesson(e.target.value)} className="input-field text-sm" disabled={!selUnit}>
                <option value="">الدرس</option>
                {units.find(u => u.id === parseInt(selUnit))?.lessons?.map(l => (
                  <option key={l.id} value={l.id}>{l.name}</option>
                ))}
              </select>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="عنوان المصدر"
                value={form.title}
                onChange={e => setForm({ ...form, title: e.target.value })}
                className="input-field text-sm"
                required
              />
              <select
                value={form.type}
                onChange={e => setForm({ ...form, type: e.target.value })}
                className="input-field text-sm"
              >
                <option value="video">فيديو</option>
                <option value="text">نص</option>
              </select>
            </div>

            {form.type === 'video' ? (
              <input
                type="url"
                placeholder="رابط الفيديو (YouTube)"
                value={form.content_url}
                onChange={e => setForm({ ...form, content_url: e.target.value })}
                className="input-field text-sm"
                dir="ltr"
              />
            ) : (
              <textarea
                placeholder="محتوى النص"
                value={form.content_text}
                onChange={e => setForm({ ...form, content_text: e.target.value })}
                className="input-field text-sm h-32 resize-none"
              />
            )}

            <button
              type="submit"
              disabled={!editId && !selLesson}
              className="btn-primary text-sm flex items-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {editId ? 'تحديث' : 'حفظ'}
            </button>
          </form>
        </div>
      )}

      {/* Resources List */}
      {loading ? (
        <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="skeleton h-16" />)}</div>
      ) : resources.length === 0 ? (
        <div className="card text-center py-10">
          <p className="text-gray-500">لا توجد مصادر مضافة بعد</p>
        </div>
      ) : (
        <div className="space-y-2">
          {resources.map(res => (
            <div key={res.id} className="card py-3 px-4 flex items-center gap-3">
              {res.type === 'video' ? (
                <Play className="w-5 h-5 text-red-500 flex-shrink-0" />
              ) : (
                <FileText className="w-5 h-5 text-blue-500 flex-shrink-0" />
              )}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">{res.title}</p>
                <p className="text-xs text-gray-500 truncate">
                  {res.subject_name} &gt; {res.unit_name} &gt; {res.lesson_name}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => startEdit(res)} className="p-1.5 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
                  <Edit3 className="w-4 h-4 text-gray-400" />
                </button>
                <button onClick={() => deleteResource(res.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
