import { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { CheckCircle2, Circle, Plus, Trash2, Flame, SmilePlus, Frown, Meh } from 'lucide-react';
import toast from 'react-hot-toast';

const today = () => new Date().toISOString().split('T')[0];

export default function TodayPage() {
  const [schedule, setSchedule] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [checkin, setCheckin] = useState(null);
  const [streak, setStreak] = useState(null);
  const [newTask, setNewTask] = useState('');
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [s, t, c, st] = await Promise.all([
        api.get('/schedule/active').catch(() => null),
        api.get(`/tasks?date=${today()}`).catch(() => []),
        api.get('/checkin/today').catch(() => null),
        api.get('/checkin/streak').catch(() => null),
      ]);
      if (s) setSchedule({ ...s.schedule, blocks: s.blocks });
      setTasks(Array.isArray(t) ? t : t?.tasks || []);
      setCheckin(c?.checkin || null);
      if (st) setStreak(st.streak);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const dayNumber = schedule?.start_date
    ? Math.ceil((new Date(today()) - new Date(schedule.start_date)) / 86400000) + 1
    : 0;

  const currentBlock = schedule?.blocks?.find(
    b => dayNumber >= b.start_day && dayNumber <= b.end_day
  );

  const addTask = async (e) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    try {
      const data = await api.post('/tasks', { date: today(), title: newTask.trim() });
      setTasks([...tasks, data.task || data]);
      setNewTask('');
    } catch { toast.error('خطأ في إضافة المهمة'); }
  };

  const toggleTask = async (task) => {
    try {
      await api.put(`/tasks/${task.id}`, { is_completed: task.is_completed ? 0 : 1 });
      setTasks(tasks.map(t => t.id === task.id ? { ...t, is_completed: !t.is_completed } : t));
    } catch { toast.error('خطأ'); }
  };

  const deleteTask = async (id) => {
    try {
      await api.delete(`/tasks/${id}`);
      setTasks(tasks.filter(t => t.id !== id));
    } catch { toast.error('خطأ'); }
  };

  const doCheckin = async (status, mood) => {
    if (!schedule) { toast.error('أنشئ جدولك أولاً'); return; }
    try {
      await api.post('/checkin', {
        schedule_id: schedule.id,
        date: today(),
        status,
        mood_rating: mood,
      });
      toast.success(status === 'done' ? 'أحسنت! استمر 💪' : 'لا بأس، غدًا أفضل بإذن الله');
      fetchData();
    } catch (err) { toast.error(err.message || 'خطأ'); }
  };

  if (loading) return <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="skeleton h-24" />)}</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">يوم {dayNumber || '--'}</h1>
          <p className="text-sm text-gray-500">{new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
        {streak && (
          <div className="flex items-center gap-2 bg-orange-500/10 text-orange-500 px-4 py-2 rounded-xl">
            <Flame className="w-5 h-5" />
            <span className="font-bold">{streak.current_streak}</span>
          </div>
        )}
      </div>

      {/* Current Subject */}
      {currentBlock && (
        <div className="card border-primary-500/30">
          <div className="text-xs text-primary-500 font-medium mb-1">التركيز الحالي</div>
          <h2 className="text-xl font-bold mb-3">{currentBlock.subject_name}</h2>
          <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
            <span>المرحلة {currentBlock.phase}</span>
            <span>يوم {dayNumber - currentBlock.start_day + 1} / {currentBlock.allocated_days}</span>
          </div>
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
            <div
              className="bg-primary-500 h-2.5 rounded-full transition-all"
              style={{ width: `${currentBlock.progress_percent}%` }}
            />
          </div>
        </div>
      )}

      {/* Tasks */}
      <div className="card">
        <h3 className="font-bold mb-4">مهام اليوم</h3>
        <form onSubmit={addTask} className="flex gap-2 mb-4">
          <input
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            className="input-field flex-1"
            placeholder="أضف مهمة جديدة..."
          />
          <button type="submit" className="btn-primary px-4">
            <Plus className="w-5 h-5" />
          </button>
        </form>

        {tasks.length === 0 ? (
          <p className="text-center text-gray-400 py-4">لا توجد مهام لهذا اليوم</p>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => (
              <div
                key={task.id}
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all group"
              >
                <button onClick={() => toggleTask(task)} className="shrink-0">
                  {task.is_completed ? (
                    <CheckCircle2 className="w-6 h-6 text-green-500" />
                  ) : (
                    <Circle className="w-6 h-6 text-gray-300 dark:text-gray-600" />
                  )}
                </button>
                <span className={`flex-1 ${task.is_completed ? 'line-through text-gray-400' : ''}`}>
                  {task.title}
                </span>
                <button
                  onClick={() => deleteTask(task.id)}
                  className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-500 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Check-in */}
      {checkin ? (
        <div className="card bg-green-500/5 border-green-500/20 text-center">
          <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-2" />
          <p className="font-bold text-green-600 dark:text-green-400">تم تسجيل يومك بنجاح!</p>
          <p className="text-sm text-gray-500 mt-1">الحالة: {checkin.status === 'done' ? 'مكتمل' : checkin.status === 'partial' ? 'جزئي' : 'فائت'}</p>
        </div>
      ) : (
        <div className="card">
          <h3 className="font-bold mb-4 text-center">كيف كان يومك؟</h3>
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => doCheckin('done', 5)}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-green-500/30 hover:bg-green-500/10 transition-all"
            >
              <SmilePlus className="w-8 h-8 text-green-500" />
              <span className="text-sm font-medium">أنهيت مهامي</span>
            </button>
            <button
              onClick={() => doCheckin('partial', 3)}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-yellow-500/30 hover:bg-yellow-500/10 transition-all"
            >
              <Meh className="w-8 h-8 text-yellow-500" />
              <span className="text-sm font-medium">جزئيًا</span>
            </button>
            <button
              onClick={() => doCheckin('missed', 1)}
              className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 border-red-500/30 hover:bg-red-500/10 transition-all"
            >
              <Frown className="w-8 h-8 text-red-500" />
              <span className="text-sm font-medium">لم أذاكر</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
