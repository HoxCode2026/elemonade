import { useState, useEffect, useRef } from 'react';
import { 
  Video, VideoOff, Users, Plus, X, PhoneOff, Grid, Layout, 
  Loader2, MessageCircle, Send
} from 'lucide-react';
import { getSocket, disconnectSocket } from '../lib/socket';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ]
};

function VideoTile({ stream, participant, isSelf, onToggleVideo }) {
  const videoRef = useRef(null);
  const [hasVideo, setHasVideo] = useState(false);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      setHasVideo(true);
    } else {
      setHasVideo(false);
    }
  }, [stream]);

  return (
    <div className={`relative rounded-2xl overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900 aspect-video ${isSelf ? 'ring-2 ring-green-500' : ''}`}>
      {stream && hasVideo ? (
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted={isSelf}
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
            <span className="text-4xl font-bold text-white">
              {(participant?.name || '?').charAt(0).toUpperCase()}
            </span>
          </div>
        </div>
      )}
      
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
        <div className="flex items-center justify-between">
          <span className="text-white font-medium text-sm">
            {isSelf ? 'أنت' : participant?.name || 'مشارك'}
          </span>
          {!hasVideo && <VideoOff className="w-4 h-4 text-red-400" />}
        </div>
      </div>
    </div>
  );
}

export default function VideoCallPage() {
  const { user } = useAuthStore();
  const [view, setView] = useState('list');
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentRoom, setCurrentRoom] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createForm, setCreateForm] = useState({ name: '' });
  const [creating, setCreating] = useState(false);

  const [cameraOn, setCameraOn] = useState(false);
  const [localStream, setLocalStream] = useState(null);
  const [participants, setParticipants] = useState([]);
  const [peers, setPeers] = useState({});
  const [showParticipants, setShowParticipants] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [newMsg, setNewMsg] = useState('');
  
  const socketRef = useRef(null);
  const peersRef = useRef({});
  const messagesEndRef = useRef(null);

  useEffect(() => {
    fetchRooms();
    return () => {
      leaveRoom();
    };
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const fetchRooms = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/rooms`, { 
        headers: { Authorization: `Bearer ${token}` } 
      });
      const data = await res.json();
      setRooms(data.rooms || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getLocalStream = async () => {
    if (localStream) return localStream;
    
    try {
      console.log('Requesting camera access...');
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: false 
      });
      
      console.log('Camera access granted:', stream);
      setLocalStream(stream);
      setCameraOn(true);
      toast.success('تم تشغيل الكاميرا');
      return stream;
    } catch (err) {
      console.error('Camera error:', err);
      console.error('Error name:', err.name);
      console.error('Error message:', err.message);
      
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        toast.error('تم رفض الإذن - تحقق من إعدادات المتصفح', { duration: 5000 });
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        toast.error('لم يتم العثور على كاميرا - تحقق من توصيل الكاميرا', { duration: 5000 });
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        toast.error('الكاميرا مستخدمة من تطبيق آخر', { duration: 5000 });
      } else if (err.name === 'OverconstrainedError') {
        toast.error('إعدادات الكاميرا غير مدعومة - جاري المحاولة بإعدادات أخرى', { duration: 5000 });
        return getLocalStreamFallback();
      } else {
        toast.error('لا يمكن الوصول للكاميرا: ' + err.name, { duration: 5000 });
      }
      return null;
    }
  };

  const getLocalStreamFallback = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true,
        audio: false 
      });
      setLocalStream(stream);
      setCameraOn(true);
      toast.success('تم تشغيل الكاميرا');
      return stream;
    } catch (err) {
      console.error('Fallback camera error:', err);
      toast.error('لا يمكن تشغيل الكاميرا');
      return null;
    }
  };

  const stopLocalStream = () => {
    if (localStream) {
      localStream.getTracks().forEach(t => t.stop());
      setLocalStream(null);
    }
    setCameraOn(false);
  };

  const createPeerConnection = (peerId, initiator) => {
    try {
      const pc = new RTCPeerConnection(ICE_SERVERS);
      
      if (localStream) {
        localStream.getTracks().forEach(track => {
          pc.addTrack(track, localStream);
        });
      }

      pc.onicecandidate = (event) => {
        if (event.candidate && socketRef.current) {
          socketRef.current.emit('webrtc_ice_candidate', {
            roomId: currentRoom,
            targetUserId: peerId,
            candidate: event.candidate,
          });
        }
      };

      pc.ontrack = (event) => {
        peersRef.current[peerId] = { ...peersRef.current[peerId], stream: event.streams[0] };
        setPeers({ ...peersRef.current });
      };

      if (initiator) {
        pc.createOffer().then(offer => {
          pc.setLocalDescription(offer);
          socketRef.current.emit('webrtc_offer', {
            roomId: currentRoom,
            targetUserId: peerId,
            sdp: offer,
          });
        });
      }

      peersRef.current[peerId] = { ...peersRef.current[peerId], pc };
      return pc;
    } catch (err) {
      console.error('Peer error:', err);
      return null;
    }
  };

  const createRoom = async () => {
    if (!createForm.name.trim()) { toast.error('أدخل اسم الغرفة'); return; }
    setCreating(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/rooms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ name: createForm.name, type: 'group', maxUsers: 10 }),
      });
      const data = await res.json();
      await joinRoom(data.room.id);
      setShowCreateModal(false);
      toast.success('تم إنشاء الغرفة');
    } catch (err) {
      toast.error(err.message);
    } finally {
      setCreating(false);
    }
  };

  const joinRoom = async (roomId) => {
    setCurrentRoom(roomId);
    setView('room');
    
    await getLocalStream();
    
    const socket = getSocket();
    socketRef.current = socket;
    
    if (socket.connected) socket.emit('join_room', { roomId });
    else { socket.connect(); socket.once('connect', () => socket.emit('join_room', { roomId })); }

    socket.off('room_state').off('user_joined').off('user_left').off('new_message')
      .off('webrtc_offer').off('webrtc_answer').off('webrtc_ice_candidate');

    socket.on('room_state', ({ participants: p, messages: m }) => {
      setParticipants(p || []);
      setChatMessages(m || []);
      
      p.forEach(participant => {
        if (participant.user_id !== user?.id && !peersRef.current[participant.user_id]) {
          createPeerConnection(participant.user_id, false);
        }
      });
    });

    socket.on('user_joined', ({ userId, userName }) => { 
      toast.success(`${userName} انضم`);
      createPeerConnection(userId, true);
    });
    
    socket.on('user_left', ({ userId }) => {
      if (peersRef.current[userId]) {
        peersRef.current[userId].pc?.close();
        delete peersRef.current[userId];
        setPeers({ ...peersRef.current });
      }
    });

    socket.on('new_message', (msg) => {
      setChatMessages(prev => [...prev, { ...msg, id: msg.id || Date.now() }]);
    });

    socket.on('webrtc_offer', async ({ fromUserId, fromUserName, sdp }) => {
      const peer = peersRef.current[fromUserId];
      if (!peer) {
        createPeerConnection(fromUserId, false);
      }
      const pc = peersRef.current[fromUserId]?.pc;
      if (pc) {
        await pc.setRemoteDescription(new RTCSessionDescription(sdp));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socketRef.current.emit('webrtc_answer', { 
          roomId, 
          targetUserId: fromUserId, 
          sdp: answer 
        });
      }
    });

    socket.on('webrtc_answer', async ({ fromUserId, sdp }) => {
      const peer = peersRef.current[fromUserId];
      if (peer && peer.pc) {
        await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
      }
    });

    socket.on('webrtc_ice_candidate', async ({ fromUserId, candidate }) => {
      const peer = peersRef.current[fromUserId];
      if (peer && peer.pc) {
        await peer.pc.addIceCandidate(new RTCIceCandidate(candidate));
      }
    });

    const isHttps = window.location.protocol === 'https:';
    const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    
    if (!isHttps && !isLocalhost) {
      toast.error('⚠️ الكاميرا تحتاج https أو localhost', { duration: 8000 });
    }

    setCurrentRoom(roomId);
    setView('room');
  };

  const leaveRoom = () => {
    stopLocalStream();
    Object.values(peersRef.current).forEach(peer => peer.pc?.close());
    peersRef.current = {};
    setPeers({});
    
    if (socketRef.current && currentRoom) { 
      socketRef.current.emit('leave_room', { roomId: currentRoom }); 
      disconnectSocket(); 
      socketRef.current = null; 
    }
    setCurrentRoom(null); 
    setParticipants([]);
    setChatMessages([]);
    setView('list');
    fetchRooms();
  };

  const sendMessage = (e) => { 
    e.preventDefault(); 
    if (!newMsg.trim() || !socketRef.current) return; 
    socketRef.current.emit('chat_message', { roomId: currentRoom, text: newMsg.trim() }); 
    setNewMsg(''); 
  };

  const getGridClass = () => {
    const count = participants.length + 1;
    if (count <= 1) return 'grid-cols-1';
    if (count <= 4) return 'grid-cols-2';
    if (count <= 6) return 'grid-cols-3';
    return 'grid-cols-4';
  };

  if (view === 'room') {
    const allParticipants = [
      { user_id: user?.id, name: user?.name || 'أنت' },
      ...participants.filter(p => p.user_id !== user?.id)
    ];

    return (
      <div className="h-[calc(100vh-2rem)] flex flex-col bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 rounded-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 bg-black/20">
          <div>
            <h2 className="text-lg font-bold text-white">مكالمة فيديو</h2>
            <p className="text-sm text-white/60">{allParticipants.length} مشارك</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowParticipants(!showParticipants)} className={`p-2 rounded-lg ${showParticipants ? 'bg-blue-500' : 'bg-white/10'}`}>
              <Users className="w-5 h-5 text-white" />
            </button>
            <button onClick={() => setShowChat(!showChat)} className={`p-2 rounded-lg ${showChat ? 'bg-blue-500' : 'bg-white/10'}`}>
              <MessageCircle className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        <div className="flex-1 flex gap-2 p-2 min-h-0">
          <div className="flex-1">
            <div className={`grid ${getGridClass()} gap-2 h-full auto-rows-fr`}>
              {allParticipants.map(p => (
                <VideoTile 
                  key={p.user_id}
                  stream={p.user_id === user?.id ? localStream : peers[p.user_id]?.stream}
                  participant={p}
                  isSelf={p.user_id === user?.id}
                />
              ))}
            </div>
          </div>

          {showParticipants && (
            <div className="w-64 bg-surface-light dark:bg-surface-dark rounded-xl p-3">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-sm">المشاركين</h3>
                <button onClick={() => setShowParticipants(false)}><X className="w-4 h-4" /></button>
              </div>
              <div className="space-y-2">
                {allParticipants.map(p => (
                  <div key={p.user_id} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50 dark:bg-gray-800/50">
                    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-sm">
                      {(p.name || '?').charAt(0)}
                    </div>
                    <span className="text-sm">{p.user_id === user?.id ? 'أنت' : p.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {showChat && (
            <div className="w-72 bg-surface-light dark:bg-surface-dark rounded-xl p-3 flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-sm">الشات</h3>
                <button onClick={() => setShowChat(false)}><X className="w-4 h-4" /></button>
              </div>
              <div className="flex-1 overflow-y-auto space-y-2 mb-3">
                {chatMessages.map(msg => (
                  <div key={msg.id} className={`${msg.user_id === user?.id ? 'ml-auto' : ''}`}>
                    <div className={`max-w-[90%] px-3 py-2 rounded-xl ${msg.user_id === user?.id ? 'bg-blue-500 text-white' : 'bg-gray-100 dark:bg-gray-800'}`}>
                      <p className="text-sm">{msg.text}</p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
              <form onSubmit={sendMessage} className="flex gap-2">
                <input type="text" placeholder="رسالة..." className="input-field text-sm flex-1" value={newMsg} onChange={e => setNewMsg(e.target.value)} />
                <button type="submit" className="p-2 bg-blue-500 rounded-lg"><Send className="w-4 h-4 text-white" /></button>
              </form>
            </div>
          )}
        </div>

        <div className="p-4 bg-black/30">
          <div className="flex items-center justify-center gap-4">
            <button 
              onClick={() => cameraOn ? stopLocalStream() : getLocalStream()} 
              className={`p-4 rounded-full ${cameraOn ? 'bg-red-500 hover:bg-red-600' : 'bg-white/10 hover:bg-white/20'}`}
            >
              {cameraOn ? <Video className="w-6 h-6 text-white" /> : <VideoOff className="w-6 h-6 text-white" />}
            </button>

            <button onClick={leaveRoom} className="flex items-center gap-2 px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-full">
              <PhoneOff className="w-5 h-5" />
              انتهاء
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Video className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">مكالمات الفيديو</h1>
            <p className="text-sm text-gray-500">تواصل وجهًا لوجه مع أصدقائك</p>
          </div>
        </div>
        <button onClick={() => setShowCreateModal(true)} className="btn-primary flex items-center gap-2 px-6 py-3">
          <Plus className="w-5 h-5" /> غرفة جديدة
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
        </div>
      ) : rooms.length === 0 ? (
        <div className="card text-center py-16">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Video className="w-12 h-12 text-white" />
          </div>
          <h3 className="text-xl font-bold mb-2">لا توجد غرف</h3>
          <button onClick={() => setShowCreateModal(true)} className="btn-primary px-8 py-3">إنشاء غرفة</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {rooms.map(room => (
            <div key={room.id} className="card hover:border-blue-500/50 cursor-pointer" onClick={() => joinRoom(room.id)}>
              <div className="flex items-center justify-between mb-4">
                <div className="w-14 h-14 bg-blue-500/10 rounded-xl flex items-center justify-center">
                  <Video className="w-7 h-7 text-blue-500" />
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-blue-500/10 text-blue-500">
                  {room.user_count}/{room.max_users}
                </span>
              </div>
              <h3 className="font-bold text-lg mb-1">{room.name}</h3>
              <p className="text-sm text-gray-500">مضيف: {room.host_name}</p>
            </div>
          ))}
        </div>
      )}

      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowCreateModal(false)}>
          <div className="card max-w-md w-full space-y-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">إنشاء غرفة فيديو</h2>
              <button onClick={() => setShowCreateModal(false)}><X className="w-5 h-5" /></button>
            </div>
            
            <input 
              type="text" 
              placeholder="اسم الغرفة" 
              className="input-field text-lg" 
              value={createForm.name} 
              onChange={e => setCreateForm(f => ({ ...f, name: e.target.value }))} 
            />

            <button 
              onClick={createRoom} 
              disabled={creating || !createForm.name.trim()} 
              className="btn-primary w-full py-3"
            >
              {creating ? 'جاري...' : 'إنشاء'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
