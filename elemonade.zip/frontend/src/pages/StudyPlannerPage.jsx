import { useState, useEffect } from 'react';
import { 
  Calendar, Clock, BookOpen, Target, Trophy, Flame, Zap,
  CheckCircle, Circle, Plus, ChevronLeft, ChevronRight,
  Settings, Star, Award, Play
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

const GRADES = [
  { value: '3sec', label: 'ثالثة ثانوي' },
  { value: '2sec', label: 'ثانية ثانوي' },
  { value: '1sec', label: 'أولى ثانوي' },
];

const TRACKS = [
  { value: 'science_bio', label: 'علمي علوم' },
  { value: 'science_math', label: 'علمي رياضة' },
  { value: 'literature', label: 'أدبي' },
];

const SUBJECT_LEVELS = [
  { value: 'weak', label: 'ضعيف', color: 'text-red-500' },
  { value: 'medium', label: 'متوسط', color: 'text-yellow-500' },
  { value: 'strong', label: 'قوي', color: 'text-green-500' },
];

export default function StudyPlannerPage() {
  const { user } = useAuthStore();
  const [view, setView] = useState('setup');
  const [loading, setLoading] = useState(true);
  
  const [subjects, setSubjects] = useState([]);
  const [settings, setSettings] = useState(null);
  const [plan, setPlan] = useState(null);
  const [schedules, setSchedules] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState(null);
  
  const [setupForm, setSetupForm] = useState({
    grade: '3sec',
    track: 'science_bio',
    daily_hours: 6,
    exam_date: '',
    subjects: []
  });
  const [selectedDate, setSelectedDate] = useState(0);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      
      const [configRes, settingsRes, planRes, tasksRes, statsRes] = await Promise.all([
        fetch(`${API_URL}/api/planner/config?grade=3sec&track=science_bio`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch(`${API_URL}/api/planner/settings`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch(`${API_URL}/api/planner/plan`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch(`${API_URL}/api/planner/tasks`, {
          headers: { Authorization: `Bearer ${token}` }
        }),
        fetch(`${API_URL}/api/planner/stats`, {
          headers: { Authorization: `Bearer ${token}` }
        })
      ]);

      const configData = await configRes.json();
      const settingsData = await settingsRes.json();
      const planData = await planRes.json();
      const tasksData = await tasksRes.json();
      const statsData = await statsRes.json();

      setSubjects(configData.subjects || []);
      setSettings(settingsData.settings);
      setPlan(planData.plan);
      setSchedules(planData.schedules || []);
      setSessions(planData.sessions || []);
      setTasks(tasksData.tasks || []);
      setStats(statsData);

      if (settingsData.settings) {
        setSetupForm({
          grade: settingsData.settings.grade || '3sec',
          track: settingsData.settings.track || 'science_bio',
          daily_hours: settingsData.settings.daily_hours || 6,
          exam_date: settingsData.settings.exam_date || '',
          subjects: []
        });
      }

      if (planData.plan) {
        setView('plan');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/planner/settings`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(setupForm)
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      setSettings(data.settings);
      toast.success('تم حفظ الإعدادات');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const generatePlan = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/planner/generate`, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: 'خطة مذاكرة ' + new Date().getFullYear(),
          start_date: new Date().toISOString().split('T')[0],
          end_date: setupForm.exam_date
        })
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      await fetchData();
      setView('plan');
      toast.success('تم إنشاء الخطة بنجاح');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const completeSession = async (sessionId) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`${API_URL}/api/planner/session/${sessionId}/complete`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      
      await fetchData();
      toast.success(`تم 完成 الجلسة! +${data.xp_earned} XP`);
    } catch (err) {
      toast.error(err.message);
    }
  };

  const getLevelXP = (level) => level * 500;
  const getCurrentLevelXP = (totalXP, level) => totalXP - (level - 1) * 500;
  const getProgressPercent = (totalXP, level) => 
    Math.min(100, (getCurrentLevelXP(totalXP, level) / 500) * 100);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-blue-500/30 border-t-blue-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (view === 'setup') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">مخطط المذاكرة الذكي</h1>
            <p className="text-sm text-gray-500">ساعدنا نخطيط مذاكرة مثالية لك</p>
          </div>
        </div>

        <div className="card space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">الصف الدراسي</label>
            <select 
              className="input-field"
              value={setupForm.grade}
              onChange={e => setSetupForm(f => ({ ...f, grade: e.target.value }))}
            >
              {GRADES.map(g => (
                <option key={g.value} value={g.value}>{g.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">الشعبة</label>
            <select 
              className="input-field"
              value={setupForm.track}
              onChange={async e => {
                const track = e.target.value;
                setSetupForm(f => ({ ...f, track }));
                
                const token = localStorage.getItem('token');
                const res = await fetch(`${API_URL}/api/planner/config?grade=${setupForm.grade}&track=${track}`, {
                  headers: { Authorization: `Bearer ${token}` }
                });
                const data = await res.json();
                setSubjects(data.subjects || []);
              }}
            >
              {TRACKS.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">ساعات المذاكرة اليومية</label>
            <input 
              type="number" 
              className="input-field"
              value={setupForm.daily_hours}
              onChange={e => setSetupForm(f => ({ ...f, daily_hours: Number(e.target.value) }))}
              min={1}
              max={12}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">موعد الامتحان</label>
            <input 
              type="date" 
              className="input-field"
              value={setupForm.exam_date}
              onChange={e => setSetupForm(f => ({ ...f, exam_date: e.target.value }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">المواد ومستواك</label>
            <div className="space-y-2">
              {subjects.map(sub => (
                <div key={sub.subject_key} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <span className="font-medium">{sub.subject_name_ar}</span>
                  <div className="flex gap-1">
                    {SUBJECT_LEVELS.map(level => (
                      <button
                        key={level.value}
                        onClick={() => {
                          const newSubjects = setupForm.subjects.filter(s => s.key !== sub.subject_key);
                          newSubjects.push({ 
                            key: sub.subject_key, 
                            name: sub.subject_name_ar, 
                            level: level.value 
                          });
                          setSetupForm(f => ({ ...f, subjects: newSubjects }));
                        }}
                        className={`px-3 py-1 rounded-full text-xs ${
                          setupForm.subjects.find(s => s.key === sub.subject_key)?.level === level.value
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-200 dark:bg-gray-700'
                        }`}
                      >
                        {level.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <button onClick={saveSettings} className="btn-secondary flex-1">
              حفظ الإعدادات
            </button>
            <button 
              onClick={generatePlan} 
              disabled={!setupForm.exam_date}
              className="btn-primary flex-1"
            >
              إنشاء الخطة
            </button>
          </div>
        </div>
      </div>
    );
  }

  const todaySchedule = schedules[selectedDate];
  const todaySessions = sessions.filter(s => s.schedule_id === todaySchedule?.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
            <Target className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">مخطط المذاكرة</h1>
            <p className="text-sm text-gray-500">خطة مذاكرة {plan?.name || ''}</p>
          </div>
        </div>
        <button onClick={() => setView('setup')} className="btn-secondary flex items-center gap-2">
          <Settings className="w-4 h-4" /> الإعدادات
        </button>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="card flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-yellow-500" />
            </div>
            <div>
              <p className="text-xs text-gray-500">النقاط</p>
              <p className="text-xl font-bold">{stats.xp?.total_xp || 0}</p>
            </div>
          </div>

          <div className="card flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <Flame className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <p className="text-xs text-gray-500">السلسلة</p>
              <p className="text-xl font-bold">{stats.streak?.current_streak || 0} أيام</p>
            </div>
          </div>

          <div className="card flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <Trophy className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-xs text-gray-500">الشارات</p>
              <p className="text-xl font-bold">{stats.badges?.length || 0}</p>
            </div>
          </div>

          <div className="card flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Star className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <p className="text-xs text-gray-500">المستوى</p>
              <div className="flex items-center gap-2">
                <p className="text-xl font-bold">{stats.xp?.level || 1}</p>
                <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-green-500 transition-all"
                    style={{ width: `${getProgressPercent(stats.xp?.total_xp || 0, stats.xp?.level || 1)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center gap-4 overflow-x-auto pb-2">
        {schedules.slice(0, 14).map((schedule, index) => (
          <button
            key={schedule.id}
            onClick={() => setSelectedDate(index)}
            className={`flex-shrink-0 p-3 rounded-xl text-center min-w-[80px] ${
              index === selectedDate 
                ? 'bg-blue-500 text-white' 
                : 'card hover:border-blue-500/50'
            }`}
          >
            <p className="text-xs">{new Date(schedule.date).toLocaleDateString('ar', { weekday: 'short' })}</p>
            <p className="text-lg font-bold">{new Date(schedule.date).getDate()}</p>
            <p className="text-xs opacity-70">{schedule.total_hours}h</p>
          </button>
        ))}
      </div>

      <div className="card">
        <h3 className="font-bold mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          جدول اليوم
        </h3>
        
        <div className="space-y-3">
          {todaySessions.length === 0 ? (
            <p className="text-center text-gray-500 py-8">لا توجد جلسات مجدولة</p>
          ) : (
            todaySessions.map(session => (
              <div 
                key={session.id}
                className={`flex items-center gap-4 p-4 rounded-xl ${
                  session.is_completed ? 'bg-green-500/10 border border-green-500/30' : 'bg-gray-50 dark:bg-gray-800'
                }`}
              >
                <div className="text-center">
                  <p className="text-sm text-gray-500">{session.start_time}</p>
                  <p className="text-xs text-gray-400">{session.duration} دقيقة</p>
                </div>
                
                <div className="flex-1">
                  <h4 className="font-medium">{session.subject_name_ar}</h4>
                  <p className="text-xs text-gray-500">
                    {session.task_type === 'study' && 'دراسة'}
                    {session.task_type === 'practice' && 'حل أسئلة'}
                    {session.task_type === 'review' && 'مراجعة'}
                  </p>
                </div>

                <button
                  onClick={() => !session.is_completed && completeSession(session.id)}
                  disabled={session.is_completed}
                  className={`p-2 rounded-full ${
                    session.is_completed 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 dark:bg-gray-700 hover:bg-blue-500 hover:text-white'
                  }`}
                >
                  {session.is_completed ? (
                    <CheckCircle className="w-5 h-5" />
                  ) : (
                    <Play className="w-5 h-5" />
                  )}
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            المهام
          </h3>
          <button className="btn-primary text-sm py-2">
            <Plus className="w-4 h-4 inline ml-1" /> إضافة مهمة
          </button>
        </div>
        
        <div className="space-y-2">
          {tasks.length === 0 ? (
            <p className="text-center text-gray-500 py-4">لا توجد مهام</p>
          ) : (
            tasks.slice(0, 5).map(task => (
              <div key={task.id} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <button className="text-gray-400 hover:text-green-500">
                  <Circle className="w-5 h-5" />
                </button>
                <div className="flex-1">
                  <p className="font-medium">{task.title}</p>
                  <p className="text-xs text-gray-500">{task.subject_key}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  task.priority === 'high' ? 'bg-red-500/20 text-red-500' :
                  task.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-500' :
                  'bg-gray-500/20 text-gray-500'
                }`}>
                  {task.priority === 'high' ? 'عالية' : task.priority === 'medium' ? 'متوسطة' : 'منخفضة'}
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {stats?.badges && stats.badges.length > 0 && (
        <div className="card">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Award className="w-5 h-5" />
            شاراتي
          </h3>
          <div className="flex flex-wrap gap-3">
            {stats.badges.map(b => (
              <div key={b.id} className="flex items-center gap-2 px-3 py-2 bg-yellow-500/10 rounded-lg">
                <span className="text-2xl">{b.badge?.icon || '🏅'}</span>
                <span className="text-sm font-medium">{b.badge?.name_ar}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
