import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Sparkles, Play, ArrowLeft, Users, Brain, Zap, Eye, EyeOff, LogIn, UserPlus, GraduationCap, Video, ChevronRight } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

export default function IntroPage() {
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const navigate = useNavigate();

  if (showAuth) {
    return (
      <div className="min-h-screen bg-[#0B1220] flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <button
            onClick={() => setShowAuth(false)}
            className="mb-8 text-gray-400 hover:text-white flex items-center gap-2 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            رجوع
          </button>
          {authMode === 'login' ? (
            <AuthCard
              title="مرحبًا بعودتك"
              subtitle="سجّل دخولك لمتابعة مذاكرتك"
              mode="login"
              onSwitch={() => setAuthMode('register')}
              onSuccess={() => navigate('/')}
            />
          ) : (
            <AuthCard
              title="أنشئ حسابك"
              subtitle="ابدأ رحلتك التعليمية معنا"
              mode="register"
              onSwitch={() => setAuthMode('login')}
              onSuccess={() => navigate('/')}
            />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B1220] text-white overflow-auto">
      <style>{introStyles}</style>
      
      <div className="max-w-6xl mx-auto px-4 py-12 md:py-20">
        {/* Hero Section */}
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20 mb-24">
          <div className="flex-1 text-center lg:text-right order-2 lg:order-1">
            <div className="hero-badge inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-400 px-4 py-2 rounded-full text-sm mb-6 animate-fade-in">
              <Sparkles className="w-4 h-4" />
              نظام مذاكرة ذكي
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight animate-fade-in-delay">
              أنا <span className="text-indigo-400">حسام فتحي</span>، وده النظام اللي 
              <br />
              عملته علشان <span className="text-green-400">أخلص من التشتت</span>
            </h1>
            
            <p className="text-gray-400 text-lg md:text-xl max-w-xl mx-auto lg:mx-0 animate-fade-in-delay-2">
              كنت زيك… تايه ومش عارف أبدأ منين، فعملت نظام بيبني لك خطة مذاكرة 
              كاملة بدل العشوائية
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mt-8 animate-fade-in-delay-3">
              <button
                onClick={() => setShowAuth(true)}
                className="hero-cta group inline-flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white font-bold text-lg px-8 py-4 rounded-2xl transition-all duration-300 shadow-xl shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:scale-105"
              >
                <Sparkles className="w-6 h-6" />
                ابدأ بالذكاء الاصطناعي
                <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              </button>
              
              <Link
                to="/videos"
                className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-8 py-4 rounded-2xl transition-all border border-white/10"
              >
                <Video className="w-5 h-5" />
                شاهد فيديوهاتي
              </Link>
            </div>
          </div>
          
          {/* Profile Card */}
          <div className="order-1 lg:order-2 animate-fade-in-delay-2">
            <div className="profile-card-wrapper">
              <div className="profile-card">
                <div className="profile-card-inner">
                  <div className="profile-image-container">
                    <img 
                      src="https://lh3.googleusercontent.com/a/ACg8ocKzg-xJ_LukLgXK6aR6aR6aR6aR6aR6aR6aR6aR6aR6aR6aR6aR6aR6a"
                      alt="حسام فتحي"
                      className="profile-image"
                      onError={(e) => {
                        e.target.src = 'https://via.placeholder.com/320x520/1a1a2e/6366f1?text=حسام+فتحي';
                      }}
                    />
                  </div>
                  <div className="profile-overlay">
                    <h3 className="font-bold text-xl">حسام فتحي</h3>
                    <p className="text-sm text-gray-300 mt-1">Hossam F. Khalaf</p>
                    <div className="mt-3 pt-3 border-t border-white/20">
                      <p className="text-xs text-gray-400">طالب ثانوي – بنيت النظام من معاناتي</p>
                    </div>
                  </div>
                </div>
                <div className="profile-glow" />
                <div className="profile-glow-secondary" />
              </div>
            </div>
          </div>
        </div>

        {/* Video Section */}
        <div className="mb-24 animate-fade-in-delay-3">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-2 text-indigo-400 mb-3">
              <Video className="w-5 h-5" />
              <span className="text-sm font-medium">فيديوهاتي</span>
            </div>
            <h2 className="text-2xl md:text-3xl font-bold">شوف تجاربي قبل ما تبدأ</h2>
            <p className="text-gray-400 mt-2">تجارب حقيقية مع نتائج</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: 'شرح النظام في دقيقة', desc: 'مقدمة عن المنصة' },
              { title: 'جدولي اليومي', desc: 'كيف أبنيت نظام المذاكرة' },
              { title: 'تجربة 30 يوم', desc: 'نتيجة الالتزام الحقيقي' }
            ].map((item, i) => (
              <Link key={i} to="/videos" className="video-card group cursor-pointer">
                <div className="video-card-inner">
                  <div className="aspect-video bg-gradient-to-br from-indigo-900/50 to-purple-900/50 rounded-xl flex items-center justify-center relative overflow-hidden">
                    <div className="play-icon opacity-0 group-hover:opacity-100 transition-opacity">
                      <Play className="w-12 h-12 text-white" fill="white" />
                    </div>
                    <div className="absolute bottom-3 right-3 bg-black/50 px-2 py-1 rounded text-xs">
                      {i === 0 ? '1:30' : i === 1 ? '5:00' : '8:45'}
                    </div>
                  </div>
                  <div className="mt-4">
                    <h4 className="font-bold group-hover:text-indigo-400 transition-colors">{item.title}</h4>
                    <p className="text-gray-500 text-sm mt-1">{item.desc}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="text-center mt-8">
            <Link to="/videos" className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 font-medium">
              عرض كل الفيديوهات <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-6 mb-20">
          <div className="feature-card bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center group hover:border-indigo-500/50 transition-all">
            <div className="w-14 h-14 bg-indigo-500/20 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
              <Brain className="w-7 h-7 text-indigo-400" />
            </div>
            <h3 className="font-bold text-lg mb-2">ذكاء اصطناعي</h3>
            <p className="text-gray-400 text-sm">الـ AI بيعمللك الجدول كامل تلقائياً</p>
          </div>
          
          <div className="feature-card bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center group hover:border-green-500/50 transition-all">
            <div className="w-14 h-14 bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
              <Zap className="w-7 h-7 text-green-400" />
            </div>
            <h3 className="font-bold text-lg mb-2">بدون تعقيد</h3>
            <p className="text-gray-400 text-sm">خطوة واحدة بس وخلاص الجدول جاهز</p>
          </div>
          
          <div className="feature-card bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 text-center group hover:border-purple-500/50 transition-all">
            <div className="w-14 h-14 bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
              <Users className="w-7 h-7 text-purple-400" />
            </div>
            <h3 className="font-bold text-lg mb-2">مع زملائك</h3>
            <p className="text-gray-400 text-sm">غرفة مذاكرة مع صحابك الحقيقيين</p>
          </div>
        </div>

        {/* About Section */}
        <div className="text-center py-10 border-t border-white/10">
          <h3 className="text-xl font-bold mb-3">مين اللي بنى النظام ده؟</h3>
          <p className="text-gray-400 max-w-2xl mx-auto">
            مش مدرس.. طالب زيك. عانيت من التشتت في المذاكرة وبنيت النظام ده عشان أقدر أخلص من الفوضى وأبدأ أذاكر بجد. لو إنت زيايا، تعال نبدأ سوا.
          </p>
        </div>

        <div className="mt-10 pt-10 border-t border-white/10 text-center">
          <p className="text-gray-500 text-sm">
            نظام مبني خصيصاً لطلبة الثانوية العامة (الصف الثالث الثانوي)
          </p>
          <p className="text-gray-600 text-xs mt-2">
            hossam-fathy.eu.cc
          </p>
        </div>
      </div>
    </div>
  );
}

function AuthCard({ title, subtitle, mode, onSwitch, onSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const { login, register } = useAuthStore();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (mode === 'register' && password !== confirmPassword) {
      toast.error('كلمتا المرور غير متطابقتين');
      return;
    }
    if (mode === 'register' && password.length < 6) {
      toast.error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }
    setLoading(true);
    try {
      if (mode === 'login') {
        await login(email, password);
        toast.success('تم تسجيل الدخول بنجاح');
      } else {
        await register(name, email, password);
        toast.success('تم إنشاء الحساب بنجاح');
      }
      setTimeout(() => {
        onSuccess?.();
      }, 100);
    } catch (err) {
      toast.error(err.message || `خطأ في ${mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL || ''}/api/auth/google`);
      const data = await res.json();
      if (data.authUrl) {
        window.location.href = data.authUrl;
      } else {
        toast.error('التسجيل عبر Google غير متاح حالياً');
      }
    } catch {
      toast.error('فشل الاتصال بالخادم');
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <div className="bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 p-8">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <GraduationCap className="w-9 h-9 text-white" />
        </div>
        <h1 className="text-3xl font-bold mb-2">{title}</h1>
        <p className="text-gray-400">{subtitle}</p>
      </div>

      <div className="space-y-5">
        <button
          type="button"
          onClick={handleGoogle}
          disabled={googleLoading}
          className="w-full flex items-center justify-center gap-3 px-4 py-3.5 bg-white text-gray-800 rounded-xl hover:bg-gray-100 transition-all font-medium"
        >
          {googleLoading ? (
            <div className="w-5 h-5 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
          ) : (
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
          )}
          المتابعة مع Google
        </button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/10" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-3 bg-transparent text-gray-500">أو</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'register' && (
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-300">الاسم</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="اسمك الكامل"
                dir="rtl"
                required
              />
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2 text-gray-300">البريد الإلكتروني</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              placeholder="example@email.com"
              dir="ltr"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-gray-300">كلمة المرور</label>
            <div className="relative">
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 pr-12 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder={mode === 'register' ? '6 أحرف على الأقل' : '••••••••'}
                dir="ltr"
                required
              />
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
              >
                {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-sm font-medium mb-2 text-gray-300">تأكيد كلمة المرور</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                placeholder="أعد كتابة كلمة المرور"
                dir="ltr"
                required
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white font-bold py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                {mode === 'login' ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                {mode === 'login' ? 'تسجيل الدخول' : 'إنشاء الحساب'}
              </>
            )}
          </button>
        </form>

        <p className="text-center text-sm text-gray-400">
          {mode === 'login' ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}{' '}
          <button
            type="button"
            onClick={onSwitch}
            className="text-indigo-400 hover:text-indigo-300 font-medium"
          >
            {mode === 'login' ? 'أنشئ حسابًا جديدًا' : 'سجّل دخولك'}
          </button>
        </p>
      </div>
    </div>
  );
}

const introStyles = `
  @keyframes fade-in {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fade-in {
    animation: fade-in 0.8s ease-out forwards;
  }
  .animate-fade-in-delay {
    animation: fade-in 0.8s ease-out 0.15s forwards;
    opacity: 0;
  }
  .animate-fade-in-delay-2 {
    animation: fade-in 0.8s ease-out 0.3s forwards;
    opacity: 0;
  }
  .animate-fade-in-delay-3 {
    animation: fade-in 0.8s ease-out 0.45s forwards;
    opacity: 0;
  }

  @keyframes float {
    0%, 100% { transform: translateY(-8px); }
    50% { transform: translateY(8px); }
  }

  @keyframes border-glow {
    0%, 100% { border-color: rgba(99, 102, 241, 0.3); }
    50% { border-color: rgba(99, 102, 241, 0.7); }
  }

  @keyframes pulse-glow {
    0%, 100% { opacity: 0.3; }
    50% { opacity: 0.7; }
  }

  .profile-card-wrapper {
    perspective: 1000px;
  }

  .profile-card {
    position: relative;
    width: 300px;
    height: 450px;
    border-radius: 28px;
    animation: float 6s ease-in-out infinite;
    transition: transform 0.4s ease;
  }

  .profile-card:hover {
    transform: scale(1.03) rotateY(2deg);
  }

  .profile-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    border-radius: 28px;
    overflow: hidden;
    background: linear-gradient(145deg, #1a1a2e 0%, #0f0f1a 100%);
    border: 2px solid rgba(99, 102, 241, 0.3);
    box-shadow: 0 0 50px rgba(99, 102, 241, 0.15), inset 0 0 30px rgba(99, 102, 241, 0.05);
  }

  .profile-card:hover .profile-card-inner {
    border-color: rgba(99, 102, 241, 0.6);
    box-shadow: 0 0 80px rgba(99, 102, 241, 0.3), inset 0 0 40px rgba(99, 102, 241, 0.08);
  }

  .profile-image-container {
    width: 100%;
    height: 100%;
  }

  .profile-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .profile-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 28px;
    background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.6) 50%, transparent 100%);
  }

  .profile-glow {
    position: absolute;
    inset: -3px;
    border-radius: 30px;
    background: linear-gradient(135deg, #6366f1, #8b5cf6, #a855f7, #6366f1);
    background-size: 300% 300%;
    animation: border-glow 4s ease-in-out infinite;
    z-index: -2;
    opacity: 0.4;
  }

  .profile-glow-secondary {
    position: absolute;
    inset: -6px;
    border-radius: 32px;
    background: linear-gradient(45deg, transparent 40%, rgba(99, 102, 241, 0.1), transparent 60%);
    z-index: -3;
    animation: pulse-glow 3s ease-in-out infinite;
  }

  .profile-card:hover .profile-glow {
    opacity: 0.7;
    animation: border-glow 1.5s ease-in-out infinite;
  }

  .video-card {
    background: rgba(255, 255, 255, 0.03);
    border-radius: 20px;
    padding: 6px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.4s ease;
  }

  .video-card:hover {
    background: rgba(255, 255, 255, 0.06);
    border-color: rgba(99, 102, 241, 0.4);
    transform: translateY(-6px);
  }

  .play-icon {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(4px);
    border-radius: 14px;
  }

  .hero-badge {
    animation: fade-in 0.8s ease-out forwards;
  }

  @media (max-width: 768px) {
    .profile-card {
      width: 240px;
      height: 360px;
    }
  }
`;
