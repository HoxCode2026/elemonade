import { useEffect, useState } from 'react';
import { api } from '../lib/apiClient';
import { BookOpen, ChevronDown, ChevronLeft, Play, FileText, Layers } from 'lucide-react';
import VideoPlayerModal, { VideoCard } from '../components/shared/VideoPlayer';

export default function CurriculumPage() {
  const [systems, setSystems] = useState([]);
  const [tracks, setTracks] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [units, setUnits] = useState([]);
  const [resources, setResources] = useState({});

  const [selectedSystem, setSelectedSystem] = useState(null);
  const [selectedTrack, setSelectedTrack] = useState(null);
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [expandedUnit, setExpandedUnit] = useState(null);
  const [expandedLesson, setExpandedLesson] = useState(null);
  const [loading, setLoading] = useState(true);
  const [playingVideo, setPlayingVideo] = useState(null);

  useEffect(() => {
    api.get('/curriculum/systems').then(d => {
      setSystems(d.systems);
      setLoading(false);
    });
  }, []);

  const selectSystem = async (sys) => {
    setSelectedSystem(sys);
    setSelectedTrack(null);
    setSelectedSubject(null);
    setUnits([]);
    const d = await api.get(`/curriculum/systems/${sys.id}/tracks`);
    setTracks(d.tracks);
  };

  const selectTrack = async (track) => {
    setSelectedTrack(track);
    setSelectedSubject(null);
    setUnits([]);
    const d = await api.get(`/curriculum/tracks/${track.id}/subjects`);
    setSubjects(d.subjects);
  };

  const selectSubject = async (subj) => {
    setSelectedSubject(subj);
    setExpandedUnit(null);
    const d = await api.get(`/curriculum/subjects/${subj.id}/units`);
    setUnits(d.units);
  };

  const loadResources = async (lessonId) => {
    if (resources[lessonId]) return;
    const d = await api.get(`/curriculum/lessons/${lessonId}/resources`);
    setResources(prev => ({ ...prev, [lessonId]: d.resources }));
  };

  const toggleLesson = (lessonId) => {
    if (expandedLesson === lessonId) {
      setExpandedLesson(null);
    } else {
      setExpandedLesson(lessonId);
      loadResources(lessonId);
    }
  };

  if (loading) {
    return <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="skeleton h-20 w-full" />)}</div>;
  }

  return (
    <div className="space-y-6">
      {playingVideo && <VideoPlayerModal video={playingVideo} onClose={() => setPlayingVideo(null)} />}

      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 bg-primary-500/20 rounded-xl flex items-center justify-center">
          <BookOpen className="w-6 h-6 text-primary-500" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">تصفح المناهج</h1>
          <p className="text-sm text-gray-500">استعرض المواد والأبواب والدروس</p>
        </div>
      </div>

      <div className="flex items-center gap-2 text-sm flex-wrap">
        <button onClick={() => { setSelectedSystem(null); setSelectedTrack(null); setSelectedSubject(null); }}
          className="text-primary-500 hover:underline">المناهج</button>
        {selectedSystem && (
          <>
            <ChevronLeft className="w-4 h-4 text-gray-400" />
            <button onClick={() => { setSelectedTrack(null); setSelectedSubject(null); }}
              className="text-primary-500 hover:underline">{selectedSystem.name}</button>
          </>
        )}
        {selectedTrack && (
          <>
            <ChevronLeft className="w-4 h-4 text-gray-400" />
            <button onClick={() => setSelectedSubject(null)}
              className="text-primary-500 hover:underline">{selectedTrack.name}</button>
          </>
        )}
        {selectedSubject && (
          <>
            <ChevronLeft className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600 dark:text-gray-400">{selectedSubject.name}</span>
          </>
        )}
      </div>

      {!selectedSystem && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {systems.map(sys => (
            <button key={sys.id} onClick={() => selectSystem(sys)}
              className="card hover:border-primary-500/50 text-right transition-all group">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                  <Layers className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">{sys.name}</h3>
                  <p className="text-xs text-gray-500">{sys.code === 'gen' ? 'الثانوية العامة' : 'الأزهر الشريف'}</p>
                </div>
                <ChevronLeft className="w-5 h-5 mr-auto text-gray-400 group-hover:text-primary-500" />
              </div>
            </button>
          ))}
        </div>
      )}

      {selectedSystem && !selectedTrack && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {tracks.map(track => (
            <button key={track.id} onClick={() => selectTrack(track)}
              className="card hover:border-primary-500/50 text-right transition-all">
              <h3 className="font-bold">{track.name}</h3>
              <p className="text-xs text-gray-500 mt-1">{track.code}</p>
            </button>
          ))}
        </div>
      )}

      {selectedTrack && !selectedSubject && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjects.map(subj => (
            <button key={subj.id} onClick={() => selectSubject(subj)}
              className="card hover:border-primary-500/50 text-right transition-all">
              <h3 className="font-bold">{subj.name}</h3>
              <p className="text-xs text-gray-500 mt-1">{subj.total_estimated_hours} ساعة تقديرية</p>
            </button>
          ))}
        </div>
      )}

      {selectedSubject && (
        <div className="space-y-3">
          {units.map(unit => (
            <div key={unit.id} className="card p-0 overflow-hidden">
              <button
                onClick={() => setExpandedUnit(expandedUnit === unit.id ? null : unit.id)}
                className="w-full flex items-center justify-between p-4 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-all"
              >
                <span className="font-bold">{unit.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">{unit.lessons?.length || 0} درس</span>
                  <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${expandedUnit === unit.id ? 'rotate-180' : ''}`} />
                </div>
              </button>

              {expandedUnit === unit.id && unit.lessons && (
                <div className="border-t border-gray-200 dark:border-gray-800">
                  {unit.lessons.map(lesson => (
                    <div key={lesson.id} className="border-b border-gray-100 dark:border-gray-800/50 last:border-0">
                      <button
                        onClick={() => toggleLesson(lesson.id)}
                        className="w-full flex items-center justify-between px-6 py-3 hover:bg-gray-50 dark:hover:bg-gray-800/30 text-sm transition-all"
                      >
                        <span>{lesson.name}</span>
                        <span className="text-xs text-gray-400">{lesson.estimated_hours}h</span>
                      </button>

                      {expandedLesson === lesson.id && (
                        <div className="px-8 py-3 bg-gray-50 dark:bg-gray-900/50">
                          {!resources[lesson.id] ? (
                            <div className="skeleton h-8 w-full" />
                          ) : resources[lesson.id].length === 0 ? (
                            <p className="text-xs text-gray-400">لا توجد مصادر مضافة بعد</p>
                          ) : (
                            <div className="space-y-2">
                              {resources[lesson.id].filter(r => r.type === 'video').length > 0 && (
                                <>
                                  <p className="text-xs text-gray-500 mb-2 font-medium">فيديوهات</p>
                                  {resources[lesson.id].filter(r => r.type === 'video').map(res => (
                                    <VideoCard key={res.id} resource={res} onPlay={setPlayingVideo} />
                                  ))}
                                </>
                              )}
                              {resources[lesson.id].filter(r => r.type === 'text').length > 0 && (
                                <>
                                  <p className="text-xs text-gray-500 mb-2 font-medium mt-3">ملفات</p>
                                  {resources[lesson.id].filter(r => r.type === 'text').map(res => (
                                    <div key={res.id} className="flex items-center gap-2 text-sm">
                                      <FileText className="w-4 h-4 text-blue-500 flex-shrink-0" />
                                      {res.content_url ? (
                                        <a href={res.content_url} target="_blank" rel="noreferrer"
                                          className="text-primary-500 hover:underline">{res.title}</a>
                                      ) : (
                                        <span>{res.title}</span>
                                      )}
                                    </div>
                                  ))}
                                </>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
