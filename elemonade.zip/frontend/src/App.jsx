import { useEffect, useState } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/authStore';
import { useThemeStore } from './store/themeStore';
import Layout from './components/layout/Layout';
import LoginForm from './features/auth/components/LoginForm';
import RegisterForm from './features/auth/components/RegisterForm';
import YoutubeSubscribeModal from './features/auth/components/YoutubeSubscribeModal';
import HomePage from './pages/HomePage';
import IntroPage from './pages/IntroPage';
import VideosPage from './pages/VideosPage';
import VideoCallPage from './pages/VideoCallPage';
import TodayPage from './pages/TodayPage';
import SchedulePage from './pages/SchedulePage';
import CurriculumPage from './pages/CurriculumPage';
import StudyRoomPage from './pages/StudyRoomPage';
import StudyPlannerPage from './pages/StudyPlannerPage';
import ReviewPage from './pages/ReviewPage';
import ProfilePage from './pages/ProfilePage';
import AdminLayout from './pages/admin/AdminLayout';
import AdminOverview from './pages/admin/AdminOverview';
import AdminUsers from './pages/admin/AdminUsers';
import AdminResources from './pages/admin/AdminResources';
import AdminAds from './pages/admin/AdminAds';
import AdminVideos from './pages/admin/AdminVideos';
import LoadingSpinner from './components/shared/LoadingSpinner';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuthStore();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">جاري التحميل...</p>
        </div>
      </div>
    );
  }
  if (!user) return <Navigate to="/intro" state={{ from: location }} replace />;
  return children;
}

function AdminRoute({ children }) {
  const { user, loading } = useAuthStore();
  if (loading) return <LoadingSpinner />;
  if (!user || user.role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

function AuthRoute({ children }) {
  const { user, loading } = useAuthStore();
  if (loading) return <LoadingSpinner />;
  if (user) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { init, user, loading } = useAuthStore();
  const { dark } = useThemeStore();
  const [showYtModal, setShowYtModal] = useState(false);

  useEffect(() => {
    init();
  }, [init]);

  useEffect(() => {
    if (user && !user.youtube_subscribed && !localStorage.getItem('yt_subscribed')) {
      setShowYtModal(true);
    } else {
      setShowYtModal(false);
    }
  }, [user]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={dark ? 'dark' : ''} dir="rtl">
      <Toaster
        position="bottom-center"
        toastOptions={{
          style: {
            background: dark ? '#1A1A1A' : '#fff',
            color: dark ? '#E0E0E0' : '#171717',
            borderRadius: '12px',
            border: dark ? '1px solid #333' : '1px solid #e5e7eb',
          },
        }}
      />

      {showYtModal && (
        <YoutubeSubscribeModal onClose={() => setShowYtModal(false)} />
      )}

      <Routes>
        <Route path="/intro" element={<IntroPage />} />
        <Route path="/videos" element={<VideosPage />} />
        <Route path="/login" element={<AuthRoute><LoginForm /></AuthRoute>} />
        <Route path="/register" element={<AuthRoute><RegisterForm /></AuthRoute>} />

        <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
          <Route index element={<HomePage />} />
          <Route path="today" element={<TodayPage />} />
          <Route path="my-schedule" element={<SchedulePage />} />
          <Route path="curriculum" element={<CurriculumPage />} />
          <Route path="study-room" element={<StudyRoomPage />} />
          <Route path="planner" element={<StudyPlannerPage />} />
          <Route path="review" element={<ReviewPage />} />
          <Route path="profile" element={<ProfilePage />} />

          <Route path="admin" element={<AdminRoute><AdminLayout /></AdminRoute>}>
            <Route index element={<AdminOverview />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="resources" element={<AdminResources />} />
            <Route path="ads" element={<AdminAds />} />
            <Route path="videos" element={<AdminVideos />} />
          </Route>
        </Route>

        <Route path="*" element={<Navigate to="/intro" replace />} />
      </Routes>
    </div>
  );
}
