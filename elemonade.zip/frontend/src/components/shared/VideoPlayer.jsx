import { useState, useEffect, useRef } from 'react';
import { X, Maximize2, Minimize2, Volume2, VolumeX, Play, Pause, Settings } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

function extractYouTubeId(url) {
  if (!url) return null;
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

export default function VideoPlayerModal({ video, onClose }) {
  const { user } = useAuthStore();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const iframeRef = useRef(null);
  const containerRef = useRef(null);

  const videoId = extractYouTubeId(video.content_url || video.youtube_url);
  const embedUrl = videoId
    ? `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=${isMuted ? 1 : 0}&enablejsapi=1&modestbranding=1&rel=0`
    : null;

  useEffect(() => {
    if (video && user) {
      trackView(video.id);
    }
    const handleEsc = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleEsc);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = '';
    };
  }, [video, user, onClose]);

  const trackView = async (videoId) => {
    try {
      await fetch(`${import.meta.env.VITE_API_URL || ''}/api/admin/video-views`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ video_id: videoId }),
      });
    } catch {}
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/90">
      <div className="fixed inset-0" onClick={onClose} />

      <div ref={containerRef} className="relative w-full max-w-5xl bg-black rounded-xl overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between p-3 bg-gray-900">
          <h3 className="text-white font-medium truncate flex-1">{video.title}</h3>
          <div className="flex items-center gap-2">
            <button onClick={toggleFullscreen} className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-all">
              {isFullscreen ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
            </button>
            <button onClick={onClose} className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-white/10 transition-all">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="relative aspect-video bg-black">
          {embedUrl ? (
            <iframe
              ref={iframeRef}
              src={embedUrl}
              className="w-full h-full"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              title={video.title}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-gray-500">
              <Play className="w-16 h-16 mb-4" />
              <p>رابط الفيديو غير صالح</p>
            </div>
          )}

          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 hover:opacity-100 transition-opacity">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button onClick={() => setIsMuted(!isMuted)}
                  className="p-2 text-white hover:bg-white/20 rounded-lg transition-all">
                  {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <button onClick={() => setShowSettings(!showSettings)}
                  className="p-2 text-white hover:bg-white/20 rounded-lg transition-all">
                  <Settings className="w-5 h-5" />
                </button>

                {showSettings && (
                  <div className="absolute bottom-full left-0 mb-2 bg-gray-900 rounded-lg overflow-hidden shadow-xl border border-white/10">
                    <div className="p-2 text-white text-xs border-b border-white/10">سرعة التشغيل</div>
                    {speeds.map(speed => (
                      <button key={speed} onClick={() => {
                        setPlaybackSpeed(speed);
                        setShowSettings(false);
                      }}
                        className={`block w-full px-4 py-2 text-sm text-left hover:bg-white/10 ${playbackSpeed === speed ? 'text-primary-500' : 'text-white'}`}>
                        {speed}x
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {video.content_text && (
          <div className="p-4 bg-gray-900 border-t border-white/10">
            <h4 className="text-white font-medium mb-2">الوصف</h4>
            <p className="text-gray-400 text-sm">{video.content_text}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export function VideoCard({ resource, onPlay }) {
  const videoId = extractYouTubeId(resource.content_url || '');
  const thumbnailUrl = videoId
    ? `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`
    : null;

  return (
    <button onClick={() => onPlay(resource)}
      className="w-full flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors text-right">
      <div className="relative w-24 h-14 rounded-lg overflow-hidden flex-shrink-0 bg-black">
        {thumbnailUrl ? (
          <img src={thumbnailUrl} alt={resource.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Play className="w-6 h-6 text-gray-400" />
          </div>
        )}
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <div className="w-8 h-8 bg-white/90 rounded-full flex items-center justify-center">
            <Play className="w-4 h-4 text-black mr-[-2px]" />
          </div>
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-medium text-sm truncate">{resource.title}</p>
        <p className="text-xs text-gray-500 mt-0.5">
          {new Date(resource.created_at).toLocaleDateString('ar-EG')}
        </p>
      </div>
    </button>
  );
}
