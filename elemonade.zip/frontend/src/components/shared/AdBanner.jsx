import { useState, useEffect } from 'react';
import { api } from '../../lib/apiClient';

export default function AdBanner({ slot }) {
  const [ads, setAds] = useState([]);

  useEffect(() => {
    api.get(`/admin/ads/active?slot=${slot}`).then(d => setAds(d.ads || [])).catch(() => {});
  }, [slot]);

  if (!ads.length) return null;

  return (
    <div className="mb-4">
      {ads.map((ad) => (
        <div key={ad.id} className="rounded-xl overflow-hidden">
          {ad.link_url ? (
            <a href={ad.link_url} target="_blank" rel="noopener noreferrer">
              {ad.image_url ? (
                <img src={ad.image_url} alt={ad.name} className="w-full rounded-xl" />
              ) : (
                <div dangerouslySetInnerHTML={{ __html: ad.content_html }} />
              )}
            </a>
          ) : ad.image_url ? (
            <img src={ad.image_url} alt={ad.name} className="w-full rounded-xl" />
          ) : (
            <div dangerouslySetInnerHTML={{ __html: ad.content_html }} />
          )}
        </div>
      ))}
    </div>
  );
}
