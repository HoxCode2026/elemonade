import { NavLink, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useThemeStore } from '../../store/themeStore';
import {
  Home, Calendar, CheckSquare, BookOpen, Users,
  Settings, LogOut, Shield, Moon, Sun, X, GraduationCap, Video, Target, RefreshCw
} from 'lucide-react';

const navItems = [
  { to: '/', icon: Home, label: 'الرئيسية' },
  { to: '/today', icon: CheckSquare, label: 'اليوم' },
  { to: '/my-schedule', icon: Calendar, label: 'جدولي' },
  { to: '/curriculum', icon: BookOpen, label: 'المناهج' },
  { to: '/planner', icon: Target, label: 'مخطط المذاكرة' },
  { to: '/review', icon: RefreshCw, label: 'المراجعة' },
  { to: '/study-room', icon: Users, label: 'غرفة المذاكرة' },
  { to: '/videos', icon: Video, label: 'فيديوهاتي' },
];

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useAuthStore();
  const { dark, toggle } = useThemeStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />
      )}
      <aside className={`
        fixed top-0 right-0 h-full w-72 bg-surface-light dark:bg-surface-dark
        border-l border-gray-200 dark:border-gray-800 z-50
        transform transition-transform duration-300 ease-in-out
        lg:translate-x-0 lg:static lg:w-64
        ${open ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
        flex flex-col
      `}>
        <div className="p-6 flex items-center justify-between border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-l from-primary-500 to-primary-700 bg-clip-text text-transparent">
              حسام فتحي
            </span>
          </div>
          <button onClick={onClose} className="lg:hidden p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-primary-500/10 text-primary-500 dark:text-primary-400'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </NavLink>
          ))}

          {user?.role === 'admin' && (
            <NavLink
              to="/admin"
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-primary-500/10 text-primary-500'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`
              }
            >
              <Shield className="w-5 h-5" />
              لوحة التحكم
            </NavLink>
          )}
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-800 space-y-2">
          <button
            onClick={toggle}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
          >
            {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            {dark ? 'الوضع الفاتح' : 'الوضع الداكن'}
          </button>

          {user && (
            <>
              <NavLink
                to="/profile"
                onClick={onClose}
                className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-medium text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-all"
              >
                <Settings className="w-5 h-5" />
                الملف الشخصي
              </NavLink>
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-all"
              >
                <LogOut className="w-5 h-5" />
                تسجيل الخروج
              </button>
            </>
          )}
        </div>
      </aside>
    </>
  );
}
