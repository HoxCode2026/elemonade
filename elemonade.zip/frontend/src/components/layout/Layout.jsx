import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import AdBanner from '../shared/AdBanner';
import { GraduationCap, Heart } from 'lucide-react';

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-h-screen lg:mr-0">
        <Header onMenuClick={() => setSidebarOpen(true)} />
        <main className="flex-1 p-4 lg:p-6 max-w-6xl mx-auto w-full">
          <AdBanner slot="page_top" />
          <Outlet />
        </main>
        <footer className="border-t border-gray-200 dark:border-gray-800 bg-surface-light dark:bg-surface-dark mt-auto">
          <AdBanner slot="footer" />
          <div className="max-w-6xl mx-auto px-4 py-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-sm bg-gradient-to-l from-primary-500 to-primary-700 bg-clip-text text-transparent">
                  حسام فتحي | Hossam F. Khalaf
                </span>
              </div>
              <p className="text-xs text-gray-500 flex items-center gap-1">
                صُنع بـ <Heart className="w-3 h-3 text-red-500 fill-red-500" /> لطلاب الثانوية العامة والأزهري
              </p>
              <p className="text-xs text-gray-400" dir="ltr">
                &copy; {new Date().getFullYear()} hossam-fathy.eu.cc
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
