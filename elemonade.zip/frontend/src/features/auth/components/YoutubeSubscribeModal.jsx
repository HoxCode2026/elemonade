import { useState } from 'react';
import { useAuthStore } from '../../../store/authStore';
import { Youtube, CheckCircle, ExternalLink } from 'lucide-react';
import toast from 'react-hot-toast';

const CHANNEL_URL = 'https://www.youtube.com/@Elemonade';

export default function YoutubeSubscribeModal() {
  const { user, confirmYoutube } = useAuthStore();
  const [clicked, setClicked] = useState(false);
  const [loading, setLoading] = useState(false);

  const isSubscribed = user?.youtube_subscribed || localStorage.getItem('yt_subscribed') === 'true';

  if (!user || isSubscribed) return null;

  const handleConfirm = async () => {
    if (!clicked) {
      toast.error('الرجاء الاشتراك في القناة أولاً');
      return;
    }
    setLoading(true);
    try {
      await confirmYoutube();
      toast.success('شكرًا لاشتراكك! يمكنك الآن استخدام المنصة');
    } catch {
      toast.error('حدث خطأ، حاول مجددًا');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/70 backdrop-blur-md" />
      <div className="relative bg-surface-light dark:bg-surface-dark rounded-2xl shadow-2xl w-full max-w-md border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="bg-red-600 p-8 text-center">
          <Youtube className="w-16 h-16 text-white mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2">اشترك في القناة</h2>
          <p className="text-red-100 text-sm">للاستمتاع بجميع مميزات المنصة، اشترك في قناتنا على يوتيوب</p>
        </div>

        <div className="p-6 space-y-4">
          <a
            href={CHANNEL_URL}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setClicked(true)}
            className="flex items-center justify-center gap-2 w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-6 rounded-xl transition-all"
          >
            <ExternalLink className="w-5 h-5" />
            اشترك في القناة
          </a>

          <button
            onClick={handleConfirm}
            disabled={loading}
            className={`flex items-center justify-center gap-2 w-full font-bold py-4 px-6 rounded-xl transition-all ${
              clicked
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-gray-200 dark:bg-gray-700 text-gray-400 cursor-not-allowed'
            }`}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                تم الاشتراك
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
