-- =============================================
-- SMART STUDY PLANNER SYSTEM - RLS POLICIES
-- =============================================

-- Enable RLS
ALTER TABLE subject_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_study_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_xp ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;

-- subject_configs: readable by all
CREATE POLICY "subject_configs_read" ON subject_configs FOR SELECT USING (true);

-- badges: readable by all
CREATE POLICY "badges_read" ON badges FOR SELECT USING (true);

-- user_subjects: users manage their own
CREATE POLICY "user_subjects_manage" ON user_subjects FOR ALL USING (auth.uid() = user_id);

-- user_study_settings: users manage their own
CREATE POLICY "user_study_settings_manage" ON user_study_settings FOR ALL USING (auth.uid() = user_id);

-- study_plans: users manage their own
CREATE POLICY "study_plans_manage" ON study_plans FOR ALL USING (auth.uid() = user_id);

-- daily_schedules: users manage their own (via plan)
CREATE POLICY "daily_schedules_manage" ON daily_schedules FOR ALL USING (
  auth.uid() IN (SELECT user_id FROM study_plans WHERE id = daily_schedules.plan_id)
);

-- schedule_sessions: users manage their own (via schedule -> plan)
CREATE POLICY "schedule_sessions_manage" ON schedule_sessions FOR ALL USING (
  auth.uid() IN (
    SELECT sp.user_id FROM study_plans sp
    JOIN daily_schedules ds ON ds.plan_id = sp.id
    WHERE ds.id = schedule_sessions.schedule_id
  )
);

-- study_tasks: users manage their own
CREATE POLICY "study_tasks_manage" ON study_tasks FOR ALL USING (auth.uid() = user_id);

-- user_xp: users manage their own
CREATE POLICY "user_xp_manage" ON user_xp FOR ALL USING (auth.uid() = user_id);

-- user_streaks: users manage their own
CREATE POLICY "user_streaks_manage" ON user_streaks FOR ALL USING (auth.uid() = user_id);

-- user_badges: users manage their own
CREATE POLICY "user_badges_manage" ON user_badges FOR ALL USING (auth.uid() = user_id);

-- study_sessions: users manage their own
CREATE POLICY "study_sessions_manage" ON study_sessions FOR ALL USING (auth.uid() = user_id);

-- =============================================
-- CHECK REQUIRED TABLES
-- =============================================

SELECT 
  'subject_configs' AS table_name,
  EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'subject_configs') AS exists
UNION ALL
SELECT 'badges', EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'badges')
UNION ALL
SELECT 'user_xp', EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'user_xp')
UNION ALL
SELECT 'user_streaks', EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = 'user_streaks');