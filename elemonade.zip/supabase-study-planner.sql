-- =============================================
-- SMART STUDY PLANNER SYSTEM - FIXED SCHEMA
-- =============================================

-- Check existing users table structure first
-- (Assuming users table exists from previous schema)

-- 1. Subject configurations per grade and track
CREATE TABLE IF NOT EXISTS subject_configs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  grade TEXT NOT NULL,
  track TEXT NOT NULL,
  subject_key TEXT NOT NULL,
  subject_name_ar TEXT NOT NULL,
  weight NUMERIC DEFAULT 0.25,
  difficulty NUMERIC DEFAULT 1.0,
  hours_estimate NUMERIC DEFAULT 20,
  UNIQUE(grade, track, subject_key)
);

-- 2. User subject preferences  
CREATE TABLE IF NOT EXISTS user_subjects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  subject_key TEXT NOT NULL,
  subject_name_ar TEXT NOT NULL,
  proficiency_level TEXT DEFAULT 'medium',
  is_pressed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, subject_key)
);

-- 3. User study settings
CREATE TABLE IF NOT EXISTS user_study_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  grade TEXT,
  track TEXT,
  daily_hours NUMERIC DEFAULT 6,
  exam_date DATE,
  off_days TEXT[] DEFAULT ARRAY['friday'],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Study plans
CREATE TABLE IF NOT EXISTS study_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  name TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Daily schedules
CREATE TABLE IF NOT EXISTS daily_schedules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id UUID,
  date DATE NOT NULL,
  day_order INTEGER NOT NULL,
  total_hours NUMERIC DEFAULT 0,
  completion_rate NUMERIC DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(plan_id, date)
);

-- 6. Schedule sessions
CREATE TABLE IF NOT EXISTS schedule_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  schedule_id UUID,
  subject_key TEXT NOT NULL,
  subject_name_ar TEXT NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  duration INTEGER NOT NULL,
  task_type TEXT DEFAULT 'study',
  is_completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMP WITH TIME ZONE,
  order_index INTEGER NOT NULL
);

-- 7. Tasks
CREATE TABLE IF NOT EXISTS study_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  subject_key TEXT NOT NULL,
  task_type TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  duration_minutes INTEGER DEFAULT 60,
  priority TEXT DEFAULT 'medium',
  due_date DATE,
  status TEXT DEFAULT 'pending',
  related_session_id UUID,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Gamification - XP points
CREATE TABLE IF NOT EXISTS user_xp (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  total_xp INTEGER DEFAULT 0,
  level INTEGER DEFAULT 1,
  weekly_xp INTEGER DEFAULT 0,
  last_xp_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. Streaks
CREATE TABLE IF NOT EXISTS user_streaks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  current_streak INTEGER DEFAULT 0,
  longest_streak INTEGER DEFAULT 0,
  last_study_date DATE,
  streak_start_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. Badges
CREATE TABLE IF NOT EXISTS badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT UNIQUE NOT NULL,
  name_ar TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  xp_reward INTEGER DEFAULT 0,
  requirement_type TEXT NOT NULL,
  requirement_value INTEGER DEFAULT 1
);

-- 11. User badges
CREATE TABLE IF NOT EXISTS user_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  badge_id UUID,
  earned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, badge_id)
);

-- 12. Study sessions (for tracking)
CREATE TABLE IF NOT EXISTS study_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  subject_key TEXT NOT NULL,
  duration_minutes INTEGER NOT NULL,
  xp_earned INTEGER DEFAULT 0,
  date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =============================================
-- SEED DATA: Subject configs
-- =============================================

INSERT INTO subject_configs (grade, track, subject_key, subject_name_ar, weight, difficulty, hours_estimate) VALUES
('3sec', 'science_bio', 'chemistry', 'كيمياء', 0.30, 1.2, 30),
('3sec', 'science_bio', 'biology', 'أحياء', 0.30, 1.1, 28),
('3sec', 'science_bio', 'arabic', 'عربي', 0.20, 1.0, 20),
('3sec', 'science_bio', 'french', 'فرنساوي', 0.20, 0.8, 15),

('3sec', 'science_math', 'math', 'رياضة', 0.35, 1.3, 35),
('3sec', 'science_math', 'physics', 'فيزياء', 0.25, 1.2, 25),
('3sec', 'science_math', 'arabic', 'عربي', 0.20, 1.0, 18),
('3sec', 'science_math', 'french', 'فرنساوي', 0.20, 0.8, 12),

('3sec', 'literature', 'arabic', 'عربي', 0.35, 1.1, 30),
('3sec', 'literature', 'history', 'تاريخ', 0.25, 0.9, 22),
('3sec', 'literature', 'geography', 'جغرافيا', 0.20, 0.8, 18),
('3sec', 'literature', 'french', 'فرنساوي', 0.20, 0.8, 15)
ON CONFLICT DO NOTHING;

-- =============================================
-- SEED DATA: Badges
-- =============================================

INSERT INTO badges (key, name_ar, description, icon, xp_reward, requirement_type, requirement_value) VALUES
('first_session', 'أول جلسة', 'أنهيت جلسة مذاكرة الأولى', '🎯', 50, 'sessions', 1),
('week_warrior', 'محارب الأسبوع', '7 أيام متتالية', '🔥', 200, 'streak', 7),
('month_master', 'master الشهر', '30 يوم دراسة', '👑', 1000, 'streak', 30),
('chemistry_king', 'ملك الكيمياء', 'أتممت كل مهارات كيمياء', '🧪', 300, 'subject_mastery', 10),
('biology_expert', 'خبير الأحياء', 'أتممت كل مهارات أحياء', '🧬', 300, 'subject_mastery', 10),
('early_bird', 'البكر المبكر', 'مذاكرة قبل الساعة 8 صباحاً', '🌅', 100, 'early_study', 1),
('night_owl', 'البومة الليلية', 'مذاكرة بعد الساعة 10 مساءً', '🦉', 100, 'night_study', 1),
('perfect_day', 'اليوم المثالي', 'أنجزت كل المهام', '⭐', 150, 'daily_completion', 1),
('streak_3', 'ثلاثة أيام', '3 أيام متتالية', '🔗', 75, 'streak', 3),
('streak_7', 'أسبوع كامل', '7 أيام متتالية', '🔗', 150, 'streak', 7),
('streak_14', 'أسبوعان', '14 يوم متتالية', '🔗', 300, 'streak', 14),
('xp_100', 'مئة نقطة', 'جمعت 100 نقطة', '💯', 0, 'total_xp', 100),
('xp_500', 'خمسمية نقطة', 'جمعت 500 نقطة', '💎', 0, 'total_xp', 500),
('xp_1000', 'ألف نقطة', 'جمعت 1000 نقطة', '🏆', 0, 'total_xp', 1000),
('level_5', 'المستوى الخامس', 'وصلت للمستوى 5', '🎖️', 0, 'level', 5),
('level_10', 'المستوى العاشر', 'وصلت للمستوى 10', '🏅', 0, 'level', 10)
ON CONFLICT DO NOTHING;

-- =============================================
-- INDEXES
-- =============================================

CREATE INDEX IF NOT EXISTS idx_user_subjects_user ON user_subjects(user_id);
CREATE INDEX IF NOT EXISTS idx_study_tasks_user ON study_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_study_tasks_status ON study_tasks(status);
CREATE INDEX IF NOT EXISTS idx_study_sessions_user ON study_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_daily_schedules_plan ON daily_schedules(plan_id);
CREATE INDEX IF NOT EXISTS idx_schedule_sessions_schedule ON schedule_sessions(schedule_id);
