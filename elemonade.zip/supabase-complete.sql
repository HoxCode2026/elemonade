-- =============================================
-- RUN ALL SUPABASE TABLES
-- =============================================

-- Already exists from supabase-study-planner.sql
-- subject_configs, badges, user_xp, user_streaks

-- Add RLS policies
ALTER TABLE subject_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_xp ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_streaks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_study_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;

-- Public read policies
CREATE POLICY "subject_configs_read" ON subject_configs FOR SELECT USING (true);
CREATE POLICY "badges_read" ON badges FOR SELECT USING (true);

-- User private policies (simplified - using auth.uid())
CREATE POLICY "user_subjects_all" ON user_subjects FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "user_study_settings_all" ON user_study_settings FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "study_plans_all" ON study_plans FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "daily_schedules_all" ON daily_schedules FOR ALL USING (true);
CREATE POLICY "schedule_sessions_all" ON schedule_sessions FOR ALL USING (true);
CREATE POLICY "study_tasks_all" ON study_tasks FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "user_xp_all" ON user_xp FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "user_streaks_all" ON user_streaks FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "user_badges_all" ON user_badges FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "study_sessions_all" ON study_sessions FOR ALL USING (auth.uid() = user_id);

-- Seed subject configs if empty
INSERT INTO subject_configs (grade, track, subject_key, subject_name_ar, weight, difficulty, hours_estimate) VALUES
('3sec', 'science_bio', 'chemistry', 'كيمياء', 0.30, 1.2, 30),
('3sec', 'science_bio', 'biology', 'أحياء', 0.30, 1.1, 28),
('3sec', 'science_bio', 'arabic', 'عربي', 0.20, 1.0, 20),
('3sec', 'science_bio', 'french', 'فرنساوي', 0.20, 0.8, 15),
('3sec', 'science_math', 'math', 'رياضة', 0.35, 1.3, 35),
('3sec', 'science_math', 'physics', 'فيزياء', 0.25, 1.2, 25),
('3sec', 'science_math', 'arabic', 'عربي', 0.20, 1.0, 18),
('3sec', 'science_math', 'french', 'فرنساوي', 0.20, 0.8, 12),
('3sec', 'literature', 'arabic', 'عربي', 0.35, 1.1, 30),
('3sec', 'literature', 'history', 'تاريخ', 0.25, 0.9, 22),
('3sec', 'literature', 'geography', 'جغرافيا', 0.20, 0.8, 18),
('3sec', 'literature', 'french', 'فرنساوي', 0.20, 0.8, 15)
ON CONFLICT DO NOTHING;

-- Seed badges if empty
INSERT INTO badges (key, name_ar, description, icon, xp_reward, requirement_type, requirement_value) VALUES
('first_session', 'أول جلسة', 'أنهيت جلسة مذاكرة الأولى', '🎯', 50, 'sessions', 1),
('week_warrior', 'محارب الأسبوع', '7 أيام متتالية', '🔥', 200, 'streak', 7),
('streak_3', 'ثلاثة أيام', '3 أيام متتالية', '🔗', 75, 'streak', 3),
('streak_7', 'أسبوع كامل', '7 أيام متتالية', '🔗', 150, 'streak', 7),
('xp_100', 'مئة نقطة', 'جمعت 100 نقطة', '💯', 0, 'total_xp', 100),
('xp_500', 'خمسمية نقطة', 'جمعت 500 نقطة', '💎', 0, 'total_xp', 500),
('level_5', 'المستوى الخامس', 'وصلت للمستوى 5', '🎖️', 0, 'level', 5)
ON CONFLICT DO NOTHING;

SELECT 'Database setup complete!' as result;