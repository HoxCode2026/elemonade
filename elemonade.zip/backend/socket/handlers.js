import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'elemonade-secret-key-2024';

const socketRooms = new Map();

export function setupSocketHandlers(io, supabase) {
  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (!token) return next(new Error('Authentication required'));
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      socket.user = decoded;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  setInterval(async () => {
    try {
      const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
      
      const { data: staleRooms } = await supabase
        .from('study_rooms')
        .select('id')
        .eq('status', 'active')
        .lt('created_at', twoHoursAgo);

      if (staleRooms && staleRooms.length > 0) {
        for (const r of staleRooms) {
          const { data: participants } = await supabase
            .from('room_participants')
            .select('id')
            .eq('room_id', r.id)
            .is('left_at', null);

          if (!participants || participants.length === 0) {
            await supabase
              .from('study_rooms')
              .update({ status: 'closed', closed_at: new Date().toISOString() })
              .eq('id', r.id);
          }
        }
      }
    } catch {}
  }, 5 * 60 * 1000);

  io.on('connection', (socket) => {
    socketRooms.set(socket.id, new Set());
    // Join a personal room so WebRTC signaling can target by userId
    socket.join(socket.user.id);

    socket.on('join_room', async ({ roomId }) => {
      try {
        const { data: room } = await supabase
          .from('study_rooms')
          .select('*')
          .eq('id', roomId)
          .eq('status', 'active')
          .single();

        if (!room) return socket.emit('error', { message: 'الغرفة غير موجودة' });

        const { count: activeCount } = await supabase
          .from('room_participants')
          .select('*', { count: 'exact', head: true })
          .eq('room_id', roomId)
          .is('left_at', null);

        if (activeCount >= room.max_users) return socket.emit('error', { message: 'الغرفة ممتلئة' });

        const { data: existing } = await supabase
          .from('room_participants')
          .select('*')
          .eq('room_id', roomId)
          .eq('user_id', socket.user.id)
          .single();

        if (existing) {
          await supabase
            .from('room_participants')
            .update({ left_at: null, status: 'studying', joined_at: new Date().toISOString() })
            .eq('room_id', roomId)
            .eq('user_id', socket.user.id);
        } else {
          await supabase
            .from('room_participants')
            .insert({
              room_id: roomId,
              user_id: socket.user.id,
              status: 'studying',
              focus_score: 50
            });
        }

        socket.join(roomId);
        socketRooms.get(socket.id).add(roomId);

        const { data: participants } = await supabase
          .from('room_participants')
          .select('*, user_name:users(name), user_avatar:users(avatar_url)')
          .eq('room_id', roomId)
          .is('left_at', null);

        const { data: messages } = await supabase
          .from('room_messages')
          .select('*, user_name:users(name)')
          .eq('room_id', roomId)
          .order('created_at', { ascending: true })
          .limit(50);

        socket.emit('room_state', {
          participants: participants || [],
          messages: messages || [],
          pomodoroState: null,
        });

        const { data: userData } = await supabase
          .from('users')
          .select('name')
          .eq('id', socket.user.id)
          .single();

        const userName = userData?.name || 'مجهول';

        socket.to(roomId).emit('user_joined', {
          userId: socket.user.id,
          userName,
          userCount: (participants || []).length,
        });

        await supabase
          .from('room_messages')
          .insert({
            room_id: roomId,
            user_id: socket.user.id,
            text: `${userName} انضم للغرفة`,
            type: 'system'
          });
      } catch (err) {
        socket.emit('error', { message: err.message });
      }
    });

    socket.on('leave_room', ({ roomId }) => {
      handleLeaveRoom(io, socket, roomId, supabase);
    });

    socket.on('chat_message', async ({ roomId, text }) => {
      try {
        const { data: room } = await supabase
          .from('study_rooms')
          .select('type')
          .eq('id', roomId)
          .eq('status', 'active')
          .single();

        if (!room || room.type !== 'group') return;
        if (!text || text.length > 200) return;
        if (/https?:\/\/|www\./i.test(text)) return socket.emit('error', { message: 'الروابط غير مسموحة' });

        const { data: userData } = await supabase
          .from('users')
          .select('name')
          .eq('id', socket.user.id)
          .single();

        const userName = userData?.name || 'مجهول';

        const { data: message } = await supabase
          .from('room_messages')
          .insert({
            room_id: roomId,
            user_id: socket.user.id,
            text: text.trim(),
            type: 'message'
          })
          .select('*, user_name:users(name)')
          .single();

        io.to(roomId).emit('new_message', message);
      } catch {}
    });

    socket.on('send_reaction', async ({ roomId, reaction }) => {
      if (!['thumbsup', 'fire', 'handshake'].includes(reaction)) return;
      
      const { data: userData } = await supabase
        .from('users')
        .select('name')
        .eq('id', socket.user.id)
        .single();

      const userName = userData?.name || 'مجهول';
      io.to(roomId).emit('new_reaction', { userId: socket.user.id, userName, reaction });
    });

    socket.on('update_status', async ({ roomId, status }) => {
      if (!['studying', 'break', 'inactive'].includes(status)) return;
      try {
        await supabase
          .from('room_participants')
          .update({ status })
          .eq('room_id', roomId)
          .eq('user_id', socket.user.id)
          .is('left_at', null);
        
        io.to(roomId).emit('user_status_changed', { userId: socket.user.id, status });
      } catch {}
    });

    socket.on('webrtc_offer', ({ roomId, targetUserId, sdp }) => {
      io.to(targetUserId).emit('webrtc_offer', {
        fromUserId: socket.user.id,
        fromUserName: socket.user.name || 'مجهول',
        sdp,
        roomId,
      });
    });

    socket.on('webrtc_answer', ({ roomId, targetUserId, sdp }) => {
      io.to(targetUserId).emit('webrtc_answer', {
        fromUserId: socket.user.id,
        sdp,
        roomId,
      });
    });

    socket.on('webrtc_ice_candidate', ({ roomId, targetUserId, candidate }) => {
      io.to(targetUserId).emit('webrtc_ice_candidate', {
        fromUserId: socket.user.id,
        candidate,
        roomId,
      });
    });

    socket.on('disconnect', () => {
      const rooms = socketRooms.get(socket.id);
      if (rooms) {
        for (const roomId of rooms) {
          handleLeaveRoom(io, socket, roomId, supabase);
        }
      }
      socketRooms.delete(socket.id);
    });
  });
}

async function handleLeaveRoom(io, socket, roomId, supabase) {
  try {
    await supabase
      .from('room_participants')
      .update({ left_at: new Date().toISOString() })
      .eq('room_id', roomId)
      .eq('user_id', socket.user.id)
      .is('left_at', null);

    socket.leave(roomId);
    socketRooms.get(socket.id)?.delete(roomId);

    const { data: userData } = await supabase
      .from('users')
      .select('name')
      .eq('id', socket.user.id)
      .single();

    const userName = userData?.name || 'مجهول';

    const { count: count } = await supabase
      .from('room_participants')
      .select('*', { count: 'exact', head: true })
      .eq('room_id', roomId)
      .is('left_at', null);

    io.to(roomId).emit('user_left', { 
      userId: socket.user.id, 
      userName, 
      userCount: count || 0 
    });

    await supabase
      .from('room_messages')
      .insert({
        room_id: roomId,
        user_id: socket.user.id,
        text: `${userName} غادر الغرفة`,
        type: 'system'
      });
  } catch {}
}
