import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new Database(join(__dirname, 'elemonade.db'));

export function initDB() {
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS education_systems (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE
    );

    CREATE TABLE IF NOT EXISTS tracks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      system_id INTEGER NOT NULL REFERENCES education_systems(id),
      name TEXT NOT NULL,
      code TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      track_id INTEGER NOT NULL REFERENCES tracks(id),
      name TEXT NOT NULL,
      total_estimated_hours REAL NOT NULL DEFAULT 30,
      display_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS units (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL REFERENCES subjects(id),
      name TEXT NOT NULL,
      display_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS lessons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      unit_id INTEGER NOT NULL REFERENCES units(id),
      name TEXT NOT NULL,
      estimated_hours REAL NOT NULL DEFAULT 2,
      display_order INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS learning_resources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lesson_id INTEGER NOT NULL REFERENCES lessons(id),
      admin_id INTEGER REFERENCES users(id),
      type TEXT NOT NULL CHECK(type IN ('video', 'text')),
      title TEXT NOT NULL,
      content_url TEXT,
      content_text TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT,
      google_id TEXT UNIQUE,
      name TEXT NOT NULL,
      role TEXT DEFAULT 'student' CHECK(role IN ('admin', 'student')),
      created_at TEXT DEFAULT (datetime('now')),
      youtube_subscribed INTEGER DEFAULT 0,
      bio TEXT DEFAULT '',
      avatar_url TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS user_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      system_id INTEGER NOT NULL REFERENCES education_systems(id),
      track_id INTEGER NOT NULL REFERENCES tracks(id),
      total_days INTEGER NOT NULL,
      phases_count INTEGER NOT NULL DEFAULT 3,
      start_date TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      is_active INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS schedule_blocks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      schedule_id INTEGER NOT NULL REFERENCES user_schedules(id),
      subject_id INTEGER NOT NULL REFERENCES subjects(id),
      phase INTEGER NOT NULL,
      start_day INTEGER NOT NULL,
      end_day INTEGER NOT NULL,
      allocated_days INTEGER NOT NULL,
      progress_percent INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS daily_checkins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      schedule_id INTEGER NOT NULL REFERENCES user_schedules(id),
      date TEXT NOT NULL,
      status TEXT NOT NULL CHECK(status IN ('done', 'partial', 'missed')),
      mood_rating INTEGER CHECK(mood_rating >= 1 AND mood_rating <= 5)
    );

    CREATE TABLE IF NOT EXISTS user_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      date TEXT NOT NULL,
      title TEXT NOT NULL,
      is_completed INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS user_streaks (
      user_id INTEGER PRIMARY KEY REFERENCES users(id),
      current_streak INTEGER DEFAULT 0,
      longest_streak INTEGER DEFAULT 0,
      last_checkin_date TEXT
    );

    CREATE TABLE IF NOT EXISTS ads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('banner', 'popup')),
      slot TEXT NOT NULL,
      content_html TEXT NOT NULL,
      image_url TEXT,
      link_url TEXT,
      is_active INTEGER DEFAULT 1,
      start_date TEXT,
      end_date TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS study_rooms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      host_id INTEGER NOT NULL REFERENCES users(id),
      type TEXT NOT NULL CHECK(type IN ('focus', 'group', 'silent')),
      max_users INTEGER NOT NULL DEFAULT 10,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'closed')),
      created_at TEXT DEFAULT (datetime('now')),
      closed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS room_participants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id TEXT NOT NULL REFERENCES study_rooms(id),
      user_id INTEGER NOT NULL REFERENCES users(id),
      status TEXT NOT NULL DEFAULT 'studying' CHECK(status IN ('studying', 'break', 'inactive')),
      focus_score INTEGER NOT NULL DEFAULT 50,
      joined_at TEXT DEFAULT (datetime('now')),
      left_at TEXT,
      UNIQUE(room_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS room_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id TEXT NOT NULL REFERENCES study_rooms(id),
      user_id INTEGER NOT NULL REFERENCES users(id),
      text TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'message' CHECK(type IN ('message', 'reaction', 'system')),
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      type TEXT NOT NULL CHECK(type IN ('video', 'announcement', 'streak', 'system')),
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      link TEXT,
      is_read INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);

    CREATE TABLE IF NOT EXISTS video_views (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      video_id INTEGER NOT NULL,
      user_id INTEGER REFERENCES users(id),
      watched_at TEXT DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_video_views ON video_views(video_id, watched_at);

    CREATE TABLE IF NOT EXISTS user_subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      subject_id INTEGER NOT NULL REFERENCES subjects(id),
      difficulty_level TEXT DEFAULT 'medium' CHECK(difficulty_level IN ('weak', 'medium', 'strong')),
      custom_weight INTEGER,
      is_selected INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      UNIQUE(user_id, subject_id)
    );

    CREATE TABLE IF NOT EXISTS schedule_tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      schedule_id INTEGER NOT NULL REFERENCES user_schedules(id),
      subject_id INTEGER NOT NULL REFERENCES subjects(id),
      day_number INTEGER NOT NULL,
      task_type TEXT NOT NULL CHECK(task_type IN ('study', 'practice', 'review')),
      topic_name TEXT,
      description TEXT,
      is_completed INTEGER DEFAULT 0,
      completed_at TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS review_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id),
      subject_id INTEGER NOT NULL REFERENCES subjects(id),
      topic_name TEXT NOT NULL,
      difficulty_score INTEGER DEFAULT 50,
      next_review_date TEXT,
      review_intervals TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_user_subjects ON user_subjects(user_id);
    CREATE INDEX IF NOT EXISTS idx_schedule_tasks ON schedule_tasks(schedule_id, day_number);
    CREATE INDEX IF NOT EXISTS idx_review_items ON review_items(user_id, next_review_date);
  `);
}

export default db;
