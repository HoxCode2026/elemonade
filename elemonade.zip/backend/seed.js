import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const db = new Database(join(__dirname, 'elemonade.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

console.log('Seeding database...');

// Create tables first
db.exec(`
  CREATE TABLE IF NOT EXISTS education_systems (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE
  );
  CREATE TABLE IF NOT EXISTS tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    system_id INTEGER NOT NULL REFERENCES education_systems(id),
    name TEXT NOT NULL,
    code TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    track_id INTEGER NOT NULL REFERENCES tracks(id),
    name TEXT NOT NULL,
    total_estimated_hours REAL NOT NULL DEFAULT 30,
    display_order INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    name TEXT NOT NULL,
    display_order INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    unit_id INTEGER NOT NULL REFERENCES units(id),
    name TEXT NOT NULL,
    estimated_hours REAL NOT NULL DEFAULT 2,
    display_order INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS learning_resources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lesson_id INTEGER NOT NULL REFERENCES lessons(id),
    admin_id INTEGER REFERENCES users(id),
    type TEXT NOT NULL CHECK(type IN ('video', 'text')),
    title TEXT NOT NULL,
    content_url TEXT,
    content_text TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT,
    google_id TEXT UNIQUE,
    name TEXT NOT NULL,
    role TEXT DEFAULT 'student' CHECK(role IN ('admin', 'student')),
    created_at TEXT DEFAULT (datetime('now')),
    youtube_subscribed INTEGER DEFAULT 0,
    bio TEXT DEFAULT '',
    avatar_url TEXT DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS user_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    system_id INTEGER NOT NULL REFERENCES education_systems(id),
    track_id INTEGER NOT NULL REFERENCES tracks(id),
    total_days INTEGER NOT NULL,
    phases_count INTEGER NOT NULL DEFAULT 3,
    start_date TEXT NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    is_active INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS schedule_blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id INTEGER NOT NULL REFERENCES user_schedules(id),
    subject_id INTEGER NOT NULL REFERENCES subjects(id),
    phase INTEGER NOT NULL,
    start_day INTEGER NOT NULL,
    end_day INTEGER NOT NULL,
    allocated_days INTEGER NOT NULL,
    progress_percent INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS daily_checkins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    schedule_id INTEGER NOT NULL REFERENCES user_schedules(id),
    date TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('done', 'partial', 'missed')),
    mood_rating INTEGER CHECK(mood_rating >= 1 AND mood_rating <= 5)
  );
  CREATE TABLE IF NOT EXISTS user_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id),
    date TEXT NOT NULL,
    title TEXT NOT NULL,
    is_completed INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS user_streaks (
    user_id INTEGER PRIMARY KEY REFERENCES users(id),
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    last_checkin_date TEXT
  );
  CREATE TABLE IF NOT EXISTS ads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('banner', 'popup')),
    slot TEXT NOT NULL,
    content_html TEXT NOT NULL,
    image_url TEXT,
    link_url TEXT,
    is_active INTEGER DEFAULT 1,
    start_date TEXT,
    end_date TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// Helper to insert and return id
const insertSystem = db.prepare('INSERT OR IGNORE INTO education_systems (name, code) VALUES (?, ?)');
const insertTrack = db.prepare('INSERT OR IGNORE INTO tracks (system_id, name, code) VALUES (?, ?, ?)');
const insertSubject = db.prepare('INSERT INTO subjects (track_id, name, total_estimated_hours, display_order) VALUES (?, ?, ?, ?)');
const insertUnit = db.prepare('INSERT INTO units (subject_id, name, display_order) VALUES (?, ?, ?)');
const insertLesson = db.prepare('INSERT INTO lessons (unit_id, name, estimated_hours, display_order) VALUES (?, ?, ?, ?)');

function addSubject(trackId, name, hours, order) {
  const r = insertSubject.run(trackId, name, hours, order);
  return Number(r.lastInsertRowid);
}

function addUnit(subjectId, name, order) {
  const r = insertUnit.run(subjectId, name, order);
  return Number(r.lastInsertRowid);
}

function addLesson(unitId, name, hours, order) {
  insertLesson.run(unitId, name, hours, order);
}

function addLessons(unitId, lessons) {
  lessons.forEach((name, i) => addLesson(unitId, name, 2, i + 1));
}

const seed = db.transaction(() => {
  // Clear existing data (order matters for FK constraints)
  db.exec(`
    DELETE FROM schedule_blocks;
    DELETE FROM daily_checkins;
    DELETE FROM user_schedules;
    DELETE FROM learning_resources;
    DELETE FROM lessons;
    DELETE FROM units;
    DELETE FROM subjects;
    DELETE FROM tracks;
    DELETE FROM education_systems;
  `);

  // ========== Education Systems ==========
  const genR = insertSystem.run('ثانوية عامة', 'gen');
  const azharR = insertSystem.run('أزهري', 'azhar');
  const genId = Number(genR.lastInsertRowid);
  const azharId = Number(azharR.lastInsertRowid);

  // ========== TRACKS ==========
  const sciR = insertTrack.run(genId, 'علمي علوم', 'sci');
  const mathR = insertTrack.run(genId, 'علمي رياضة', 'math');
  const litR = insertTrack.run(genId, 'أدبي', 'lit');
  const azharLitR = insertTrack.run(azharId, 'القسم الأدبي', 'azhar_lit');

  const sciId = Number(sciR.lastInsertRowid);
  const mathId = Number(mathR.lastInsertRowid);
  const litId = Number(litR.lastInsertRowid);
  const azharLitId = Number(azharLitR.lastInsertRowid);

  // ================================================================
  // SHARED DATA: Arabic (common across all gen tracks)
  // ================================================================

  function seedArabic(trackId, order) {
    const subj = addSubject(trackId, 'اللغة العربية', 90, order);

    // النحو 1
    const u1 = addUnit(subj, 'النحو (1)', 1);
    addLessons(u1, [
      'ألف الوصل والقطع', 'اللام القمرية والشمسية', 'الهمزة المتوسطة والمتطرفة',
      'أل وإل', 'أنواع الواو', 'اسم الفاعل', 'صيغ المبالغة', 'اسم المفعول',
      'اسم التفضيل', 'اسما الزمان والمكان', 'اسم الآلة', 'المصدر الصريح',
      'المصدر الميمي والصناعي', 'المصدر المؤول', 'اسم المرة واسم الهيئة',
      'الاسم المقصور', 'الاسم المنقوص', 'الاسم الممدود', 'بناء الفعل للمجهول',
      'المبتدأ والخبر', 'كان وأخواتها', 'كاد وأخواتها', 'إن وأخواتها',
      'لا النافية للجنس', 'المحل الإعرابي للضمير',
    ]);

    // النحو 2
    const u2 = addUnit(subj, 'النحو (2)', 2);
    addLessons(u2, [
      'المفعول به', 'المفعول المطلق ونائبه', 'المفعول لأجله', 'المفعول معه',
      'المفعول فيه', 'ظرفا الزمان والمكان', 'الحال', 'المستثنى', 'البدل',
      'التمييز', 'كم الاستفهامية وكم الخبرية', 'المنادى', 'الأسماء الخمسة',
      'الصحيح والمعتل', 'المجرد والمزيد', 'الفعل الجامد والمتصرف',
      'رفع الفعل المضارع', 'نصب الفعل المضارع', 'جزم الفعل المضارع وأسلوب الشرط',
      'اقتران جواب الشرط بالفاء', 'جزم المضارع في جواب الطلب', 'توكيد الفعل بالنون',
    ]);

    // النحو 3
    const u3 = addUnit(subj, 'النحو (3)', 3);
    addLessons(u3, [
      'تأنيث الفعل مع الفاعل', 'أنواع ما', 'أنواع من', 'أنواع إلا',
      'حروف الجر', 'أسلوبا المدح والذم', 'أسلوبا الإغراء والتحذير',
      'أسلوب الاختصاص', 'أسلوب التعجب', 'النعت', 'البدل', 'التوكيد',
      'العطف', 'المثنى وملحقاته', 'الجمع وملحقاته', 'أسماء الأفعال', 'الكشف في المعجم',
    ]);

    // الأدب
    const u4 = addUnit(subj, 'الأدب', 4);
    addLessons(u4, [
      'الإحياء والبعث', 'الاتجاه الوجداني', 'مدرسة الديوان', 'مدرسة أبوللو',
      'مدرسة المهجر', 'مدرسة الواقعية', 'النصوص الشعرية والنثرية',
    ]);

    // البلاغة
    const u5 = addUnit(subj, 'البلاغة', 5);
    addLessons(u5, [
      'التشبيه', 'الاستعارة', 'أنواع الصور', 'الكناية', 'المجاز المرسل',
      'المحسنات البديعية', 'الأساليب', 'الإيجاز', 'الإطناب',
      'أسلوب التوحيد', 'أسلوب القصر', 'التجربة الشعرية',
    ]);

    return subj;
  }

  function seedEnglish(trackId, order) {
    const subj = addSubject(trackId, 'اللغة الإنجليزية', 60, order);
    for (let i = 1; i <= 12; i++) {
      const u = addUnit(subj, `Unit ${i}`, i);
      addLesson(u, `كلمات | Unit ${i}`, 2, 1);
      addLesson(u, `جرامر | Unit ${i}`, 2, 2);
    }
    return subj;
  }

  function seedFrench(trackId, order) {
    const subj = addSubject(trackId, 'اللغة الفرنسية', 30, order);
    const u = addUnit(subj, 'Unité 4', 1);
    addLesson(u, 'Leçon 4', 2, 1);
    return subj;
  }

  // ================================================================
  // علمي علوم (Science Track)
  // ================================================================
  seedArabic(sciId, 1);
  seedEnglish(sciId, 2);
  seedFrench(sciId, 3);

  // الفيزياء
  const phySci = addSubject(sciId, 'الفيزياء', 80, 4);
  {
    const chapters = [
      { name: 'الفصل الأول', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الثاني', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الثالث', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الرابع', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث'] },
      { name: 'الفصل الخامس', lessons: ['الدرس الأول', 'الدرس الثاني'] },
      { name: 'الفصل السادس', lessons: ['الدرس الأول'] },
      { name: 'الفصل السابع', lessons: ['الدرس الأول'] },
      { name: 'الفصل الثامن', lessons: ['الدرس الأول', 'الدرس الثاني'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(phySci, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الكيمياء
  const chemSci = addSubject(sciId, 'الكيمياء', 85, 5);
  {
    const chapters = [
      { name: 'الباب الأول', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الباب الثاني', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث'] },
      { name: 'الباب الثالث', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الباب الرابع', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع', 'الدرس الخامس'] },
      { name: 'الباب الخامس', lessons: ['الدرس 1', 'الدرس 2', 'الدرس 3', 'الدرس 4', 'الدرس 5', 'الدرس 6', 'الدرس 7', 'الدرس 8', 'الدرس 9', 'الدرس 10', 'الدرس 11', 'الدرس 12'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(chemSci, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الأحياء
  const bioSci = addSubject(sciId, 'الأحياء', 80, 6);
  {
    const chapters = [
      { name: 'الفصل 1: الدعامة والحركة في الكائنات الحية', lessons: ['الدعامة في الكائنات الحية', 'الحركة في الكائنات الحية'] },
      { name: 'الفصل 2: التنسيق الهرموني في الكائنات الحية', lessons: ['التنسيق الهرموني في الكائنات الحية', 'تابع الغدد في الإنسان'] },
      { name: 'الفصل 3: التكاثر في الكائنات الحية', lessons: ['طرق التكاثر في الكائنات الحية', 'تابع طرق التكاثر', 'التكاثر في النباتات الزهرية', 'التكاثر في الإنسان', 'تابع التكاثر في الإنسان'] },
      { name: 'الفصل 4: المناعة في الكائنات الحية', lessons: ['المناعة في النبات', 'المناعة في الإنسان', 'آلية عمل الجهاز المناعي في الإنسان'] },
      { name: 'الفصل 5: الحمض النووي DNA والمعلومات الوراثية', lessons: ['جهود العلماء لمعرفة المادة الوراثية', 'الحمض النووي DNA والمعلومات الوراثية', 'DNA في أوليات وحقيقات النواة', 'تركيب المحتوى الجيني', 'الطفرات'] },
      { name: 'الفصل 6: الأحماض النووية وتخليق البروتين', lessons: ['RNA وتخليق البروتين', 'التكنولوجيا الجزيئية (الهندسة الوراثية)'] },
      { name: 'الفصل 7: الأحياء وعلوم الأرض', lessons: ['علم الجيولوجيا ومادة الأرض', 'التراكيب الجيولوجية لصخور القشرة الأرضية', 'المعادن', 'الخواص الفيزيائية للمعادن', 'أنواع الصخور (الصخور النارية)', 'الصخور الرسوبية والمتحولة ودورة الصخور'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(bioSci, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // ================================================================
  // علمي رياضة (Math Track) - shares Arabic, English, French, Physics, Chemistry
  // ================================================================
  seedArabic(mathId, 1);
  seedEnglish(mathId, 2);
  seedFrench(mathId, 3);

  // الفيزياء - same as sci
  const phyMath = addSubject(mathId, 'الفيزياء', 80, 4);
  {
    const chapters = [
      { name: 'الفصل الأول', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الثاني', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الثالث', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الفصل الرابع', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث'] },
      { name: 'الفصل الخامس', lessons: ['الدرس الأول', 'الدرس الثاني'] },
      { name: 'الفصل السادس', lessons: ['الدرس الأول'] },
      { name: 'الفصل السابع', lessons: ['الدرس الأول'] },
      { name: 'الفصل الثامن', lessons: ['الدرس الأول', 'الدرس الثاني'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(phyMath, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الكيمياء - same as sci
  const chemMath = addSubject(mathId, 'الكيمياء', 85, 5);
  {
    const chapters = [
      { name: 'الباب الأول', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الباب الثاني', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث'] },
      { name: 'الباب الثالث', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع'] },
      { name: 'الباب الرابع', lessons: ['الدرس الأول', 'الدرس الثاني', 'الدرس الثالث', 'الدرس الرابع', 'الدرس الخامس'] },
      { name: 'الباب الخامس', lessons: ['الدرس 1', 'الدرس 2', 'الدرس 3', 'الدرس 4', 'الدرس 5', 'الدرس 6', 'الدرس 7', 'الدرس 8', 'الدرس 9', 'الدرس 10', 'الدرس 11', 'الدرس 12'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(chemMath, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الرياضيات (الجبر والهندسة الفراغية)
  const mathSubj = addSubject(mathId, 'الرياضيات (الجبر والهندسة الفراغية)', 70, 6);
  {
    const u1 = addUnit(mathSubj, 'نظرية ذات الحدين', 1);
    addLessons(u1, [
      'نظرية ذات الحدين بأس صحيح موجب',
      'إيجاد الحد المشتمل على sᵏ في مفكوك ذات الحدين',
      'النسبة بين حدين متتاليين في مفكوك ذات الحدين',
    ]);
    const u2 = addUnit(mathSubj, 'الأعداد المركبة', 2);
    addLessons(u2, [
      'الصورة المثلثية للعدد المركب',
      'نظرية ديموافر',
      'الجذور التكعيبية للواحد الصحيح',
    ]);
  }

  // التفاضل والتكامل
  const calcSubj = addSubject(mathId, 'التفاضل والتكامل', 60, 7);
  {
    const u1 = addUnit(calcSubj, 'التكامل المحدد', 1);
    addLesson(u1, 'التكامل المحدد', 3, 1);
    const u2 = addUnit(calcSubj, 'تطبيقات التكامل', 2);
    addLesson(u2, 'تطبيقات على التكامل المحدد', 3, 1);
  }

  // الاستاتيكا والديناميكا
  const mechSubj = addSubject(mathId, 'الاستاتيكا والديناميكا', 70, 8);
  {
    const u1 = addUnit(mechSubj, 'الاستاتيكا', 1);
    addLessons(u1, [
      'عزم قوة بالنسبة لنقطة', 'محصلة القوى المتوازية المستوية',
      'اتزان مجموعة من القوى المستوية', 'الازدواجات', 'ازواج المحصل',
    ]);
    const u2 = addUnit(mechSubj, 'الديناميكا', 2);
    addLessons(u2, [
      'تفاضل وتكامل الدوال المتجهة', 'حركة الأجسام متغيرة الكتلة أو العجلة',
      'حركة الأجسام المتصلة', 'الدفع', 'الشغل', 'الطاقة', 'القدرة',
    ]);
  }

  // ================================================================
  // أدبي (Literary Track)
  // ================================================================
  seedArabic(litId, 1);
  seedEnglish(litId, 2);
  seedFrench(litId, 3);

  // التاريخ
  const histLit = addSubject(litId, 'التاريخ', 70, 4);
  {
    const chapters = [
      { name: 'الفصل الأول: الحملة الفرنسية على مصر والشام', lessons: ['الظروف التي سبقت الحملة الفرنسية', 'الحملة الفرنسية في مصر', 'أثر الوجود الفرنسي في مصر'] },
      { name: 'الفصل الثاني: بناء الدولة الحديثة في مصر', lessons: ['أحوال مصر بعد خروج الحملة الفرنسية', 'توطيد سلطة محمد علي', 'مظاهر بناء الدولة الحديثة', 'سياسة مصر الخارجية في عهد محمد علي', 'أحوال مصر في عصر خلفاء محمد علي', 'إسماعيل ومشروع استقلال مصر'] },
      { name: 'الفصل الثالث: مصر منذ الثورة العرابية حتى الحرب العالمية الأولى', lessons: ['الأوضاع المالية والسياسية والتدخل الأجنبي', 'الحركة الوطنية والثورة العرابية', 'أحوال مصر تحت الاحتلال البريطاني', 'الحركة الوطنية في عهد الاحتلال البريطاني'] },
      { name: 'الفصل الرابع: مصر بعد الحرب العالمية الأولى', lessons: ['ثورة مصر القومية 1919', 'مراحل المفاوضات المصرية البريطانية', 'ثورة 23 يوليو 1952'] },
      { name: 'الفصل الخامس: التوسع الاستعماري قبل الحرب العالمية الأولى', lessons: ['فرض إنجلترا سيطرتها على الخليج', 'استعمار فرنسا للجزائر', 'استعمار فرنسا لتونس', 'الحماية الفرنسية على المغرب', 'استعمار إيطاليا لليبيا'] },
      { name: 'الفصل السادس: التوسع الاستعماري بعد الحرب العالمية الأولى', lessons: ['قيام الحرب العالمية الأولى ومصير الدولة العثمانية', 'سوريا ولبنان من الانتداب إلى الاستقلال', 'العراق من الانتداب إلى الاستقلال'] },
      { name: 'الفصل السابع: مصر وقضايا العالم العربي المعاصر', lessons: ['حركة القومية العربية', 'القضية الفلسطينية وتطورها', 'الحروب العربية الإسرائيلية'] },
      { name: 'الفصل الثامن: ثورتا 25 يناير 2011 و30 يونيو 2013', lessons: ['ثورة 25 يناير 2011', 'ثورة 30 يونيو 2013'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(histLit, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الجغرافيا السياسية
  const geoLit = addSubject(litId, 'الجغرافيا السياسية', 50, 5);
  {
    const u0 = addUnit(geoLit, 'الدرس التمهيدي: مدخل لدراسة الجغرافيا السياسية', 0);
    addLesson(u0, 'مدخل لدراسة الجغرافيا السياسية', 2, 1);

    const u1 = addUnit(geoLit, 'الوحدة الأولى: الدولة في الجغرافيا السياسية', 1);
    addLessons(u1, ['الدولة (تعريفها وأنواعها)', 'المقومات الطبيعية لقوة الدولة', 'المقومات البشرية لقوة الدولة', 'النظام السياسي والانتخاب بالدولة']);

    const u2 = addUnit(geoLit, 'الوحدة الثانية: المشكلات السياسية', 2);
    addLessons(u2, ['الحدود السياسية (مفهومها وأهميتها)', 'أنواع الحدود السياسية', 'تطور خريطة العالم السياسية', 'مشكلات اقتصادية ذات بعد سياسي', 'مشكلات اجتماعية ذات بعد سياسي']);

    const u3 = addUnit(geoLit, 'الوحدة الثالثة: التكتلات الاقتصادية والأحلاف العسكرية', 3);
    addLessons(u3, ['التكتلات الاقتصادية', 'الأحلاف العسكرية']);

    const u4 = addUnit(geoLit, 'الوحدة الرابعة: العلاقات الدولية والنظام العالمي الجديد', 4);
    addLessons(u4, ['ماهية العلاقات الدولية', 'النظام العالمي الجديد']);
  }

  // ================================================================
  // أزهري - القسم الأدبي
  // ================================================================

  // المطالعة والنصوص
  const azReadSubj = addSubject(azharLitId, 'المطالعة والنصوص', 40, 1);
  {
    const u = addUnit(azReadSubj, 'نصوص متنوعة', 1);
    addLessons(u, [
      'مصر قلب العالم العربي', 'الحفاظ على مقدرات الوطن',
      'مصر رائدة الحضارة الإنسانية', 'أثر الثقافة العربية في أوروبا',
      'آفات المناظرة', 'الشائعات الكاذبة وأضرارها',
      'الرياضة البدنية من منظور إسلامي', 'وثيقة الأزهر للحريات',
      'وثيقة الأزهر لنبذ العنف',
    ]);
  }

  // اللغة الإنجليزية
  seedEnglish(azharLitId, 2);

  // التاريخ (same structure as lit)
  const histAzhar = addSubject(azharLitId, 'التاريخ', 70, 3);
  {
    const chapters = [
      { name: 'الفصل الأول: الحملة الفرنسية على مصر والشام', lessons: ['الظروف التي سبقت الحملة الفرنسية', 'الحملة الفرنسية في مصر', 'أثر الوجود الفرنسي في مصر'] },
      { name: 'الفصل الثاني: بناء الدولة الحديثة في مصر', lessons: ['أحوال مصر بعد خروج الحملة الفرنسية', 'توطيد سلطة محمد علي', 'مظاهر بناء الدولة الحديثة', 'سياسة مصر الخارجية في عهد محمد علي', 'أحوال مصر في عصر خلفاء محمد علي', 'إسماعيل ومشروع استقلال مصر'] },
      { name: 'الفصل الثالث: مصر منذ الثورة العرابية حتى الحرب العالمية الأولى', lessons: ['الأوضاع المالية والسياسية والتدخل الأجنبي', 'الحركة الوطنية والثورة العرابية', 'أحوال مصر تحت الاحتلال البريطاني', 'الحركة الوطنية في عهد الاحتلال البريطاني'] },
      { name: 'الفصل الرابع: مصر بعد الحرب العالمية الأولى', lessons: ['ثورة مصر القومية 1919', 'مراحل المفاوضات المصرية البريطانية', 'ثورة 23 يوليو 1952'] },
      { name: 'الفصل الخامس: التوسع الاستعماري قبل الحرب العالمية الأولى', lessons: ['فرض إنجلترا سيطرتها على الخليج', 'استعمار فرنسا للجزائر', 'استعمار فرنسا لتونس', 'الحماية الفرنسية على المغرب', 'استعمار إيطاليا لليبيا'] },
      { name: 'الفصل السادس: التوسع الاستعماري بعد الحرب العالمية الأولى', lessons: ['قيام الحرب العالمية الأولى ومصير الدولة العثمانية', 'سوريا ولبنان من الانتداب إلى الاستقلال', 'العراق من الانتداب إلى الاستقلال'] },
      { name: 'الفصل السابع: مصر وقضايا العالم العربي المعاصر', lessons: ['حركة القومية العربية', 'القضية الفلسطينية وتطورها', 'الحروب العربية الإسرائيلية'] },
      { name: 'الفصل الثامن: ثورتا 25 يناير 2011 و30 يونيو 2013', lessons: ['ثورة 25 يناير 2011', 'ثورة 30 يونيو 2013'] },
    ];
    chapters.forEach((ch, ci) => {
      const u = addUnit(histAzhar, ch.name, ci + 1);
      addLessons(u, ch.lessons);
    });
  }

  // الجغرافيا السياسية (same as lit)
  const geoAzhar = addSubject(azharLitId, 'الجغرافيا السياسية', 50, 4);
  {
    const u0 = addUnit(geoAzhar, 'الدرس التمهيدي', 0);
    addLesson(u0, 'مدخل لدراسة الجغرافيا السياسية', 2, 1);
    const u1 = addUnit(geoAzhar, 'الوحدة الأولى: الدولة في الجغرافيا السياسية', 1);
    addLessons(u1, ['الدولة (تعريفها وأنواعها)', 'المقومات الطبيعية لقوة الدولة', 'المقومات البشرية لقوة الدولة', 'النظام السياسي والانتخاب بالدولة']);
    const u2 = addUnit(geoAzhar, 'الوحدة الثانية: المشكلات السياسية', 2);
    addLessons(u2, ['الحدود السياسية', 'أنواع الحدود السياسية', 'تطور خريطة العالم السياسية', 'مشكلات اقتصادية ذات بعد سياسي', 'مشكلات اجتماعية ذات بعد سياسي']);
    const u3 = addUnit(geoAzhar, 'الوحدة الثالثة: التكتلات الاقتصادية والأحلاف العسكرية', 3);
    addLessons(u3, ['التكتلات الاقتصادية', 'الأحلاف العسكرية']);
    const u4 = addUnit(geoAzhar, 'الوحدة الرابعة: العلاقات الدولية', 4);
    addLessons(u4, ['ماهية العلاقات الدولية', 'النظام العالمي الجديد']);
  }

  // الصرف
  const sarfSubj = addSubject(azharLitId, 'الصرف', 50, 5);
  {
    const u1 = addUnit(sarfSubj, 'همزتا الوصل والقطع', 1);
    addLessons(u1, ['همزة الوصل', 'همزة القطع']);
    const u2 = addUnit(sarfSubj, 'الإبدال', 2);
    addLessons(u2, [
      'إبدال حرف العلة همزة (الموضع الأول)', 'إبدال حرف العلة همزة (الموضع الثاني)',
      'إبدال حرف العلة همزة (الموضع الثالث)', 'إبدال حرف العلة همزة (الموضع الرابع)',
      'إبدال حرف العلة همزة (الموضع الخامس)', 'قلب همزة مفاعل العارضة',
      'الهمزتان الملتقيتان في كلمة واحدة', 'الهمزتان الملتقيتان في كلمتين',
      'إبدال الألف واواً أو ياءً', 'إبدال الواو ياءً', 'إبدال الياء واواً',
      'إبدال الواو أو الياء ألفاً', 'إبدال الواو أو الياء تاءً',
      'إبدال التاء طاءً', 'إبدال التاء دالاً', 'إبدال النون والواو ميماً',
      'إبدال تاء التأنيث هاءً',
    ]);
    const u3 = addUnit(sarfSubj, 'الإعلال', 3);
    addLessons(u3, ['الإعلال بالنقل', 'حذف همزة أفعل', 'حذف فاء الفعل المثال الواوي', 'حذف عين الفعل المضعف']);
    const u4 = addUnit(sarfSubj, 'الإدغام', 4);
    addLesson(u4, 'الإدغام', 2, 1);
  }

  // البلاغة (متقدمة)
  const azBalaghSubj = addSubject(azharLitId, 'البلاغة', 45, 6);
  {
    const u1 = addUnit(azBalaghSubj, 'المجاز اللغوي', 1);
    addLessons(u1, ['الحقيقة والمجاز اللغويان', 'المجاز المرسل', 'الاستعارة التصريحية', 'الاستعارة المكنية', 'الاستعارة المرشحة والمجردة والمطلقة', 'الاستعارة المفردة والمثيلية']);
    const u2 = addUnit(azBalaghSubj, 'الكناية', 2);
    addLesson(u2, 'الكناية', 2, 1);
    const u3 = addUnit(azBalaghSubj, 'علم البديع - المحسنات المعنوية', 3);
    addLessons(u3, ['الطباق', 'المقابلة', 'مراعاة النظير', 'التورية', 'المبالغة', 'حسن التعليل', 'تأكيد المدح بما يشبه الذم']);
    const u4 = addUnit(azBalaghSubj, 'المحسنات اللفظية', 4);
    addLessons(u4, ['الجناس', 'السجع']);
  }

  // النحو (متقدم)
  const azNahwSubj = addSubject(azharLitId, 'النحو', 60, 7);
  {
    const u1 = addUnit(azNahwSubj, 'التوابع', 1);
    addLessons(u1, ['النعت', 'التوكيد', 'العطف', 'البدل']);
    const u2 = addUnit(azNahwSubj, 'النداء وأساليبه', 2);
    addLessons(u2, ['النداء', 'الاستغاثة', 'الندبة', 'الترحم']);
    const u3 = addUnit(azNahwSubj, 'أساليب نحوية', 3);
    addLessons(u3, ['الاختصاص', 'التحذير والإغراء', 'أسماء الأفعال والأصوات']);
    const u4 = addUnit(azNahwSubj, 'ما لا ينصرف', 4);
    addLesson(u4, 'ما لا ينصرف', 2, 1);
    const u5 = addUnit(azNahwSubj, 'إعراب الفعل', 5);
    addLessons(u5, ['عوامل الجزم', 'أدوات شرطية (لو، لولا، لوما)']);
    const u6 = addUnit(azNahwSubj, 'الإخبار والعدد', 6);
    addLessons(u6, ['الإخبار بالذي واللام', 'العدد', 'كنايات العدد (كم، كأين، كذا)']);
  }

  // الأدب والنصوص
  const azAdabSubj = addSubject(azharLitId, 'الأدب والنصوص', 50, 8);
  {
    const u1 = addUnit(azAdabSubj, 'النهضة الأدبية في العصر الحديث', 1);
    addLessons(u1, ['عوامل النهضة الأدبية الحديثة', 'الطباعة والصحافة', 'البعثات والترجمة', 'اتساع نطاق التعليم', 'رواد النهضة من الأزهر']);
    const u2 = addUnit(azAdabSubj, 'مدارس الشعر في العصر الحديث', 2);
    addLessons(u2, ['مدرسة الإحياء والبعث', 'مدرسة المحافظين', 'الاتجاه الوجداني الرومانسي', 'مدرسة الديوان', 'مدرسة شعراء المهجر', 'جماعة أبوللو']);
    const u3 = addUnit(azAdabSubj, 'نصوص شعرية', 3);
    addLessons(u3, ['طيف سمرية', 'رحلة عابسة لأحمد محرم', 'نهج البردة لأحمد شوقي', 'كليوباترا']);
    const u4 = addUnit(azAdabSubj, 'فنون النثر في العصر الحديث', 4);
    addLessons(u4, ['المقالة', 'القصة القصيرة', 'المسرحية', 'الخطابة']);
  }

  // التوحيد
  const tawhidSubj = addSubject(azharLitId, 'التوحيد', 50, 9);
  {
    const u1 = addUnit(tawhidSubj, 'الغيبيات', 1);
    addLessons(u1, ['الملائكة والجن', 'الموت وأجل المقتول', 'الروح']);
    const u2 = addUnit(tawhidSubj, 'عالم القبر والآخرة', 2);
    addLessons(u2, ['عالم القبر وسؤال الملكين', 'النفخ في الصور', 'البعث والحساب', 'اليوم الآخر']);
    const u3 = addUnit(tawhidSubj, 'الشفاعة والحساب', 3);
    addLessons(u3, ['الشفاعة', 'الحسنات والسيئات', 'التوبة', 'كبائر الذنوب وصغائرها']);
    const u4 = addUnit(tawhidSubj, 'القيامة', 4);
    addLessons(u4, ['صحائف الأعمال', 'الوزن والميزان', 'الصراط', 'الحوض']);
    const u5 = addUnit(tawhidSubj, 'الغيبيات الكونية', 5);
    addLessons(u5, ['الإيمان بالعرش والكرسي والقلم واللوح المحفوظ', 'الجنة والنار']);
    const u6 = addUnit(tawhidSubj, 'الأصول والمبادئ', 6);
    addLessons(u6, ['الكليات الخمس', 'المعلومات من الدين بالضرورة', 'الإمامة', 'الأمر بالمعروف والنهي عن المنكر']);
  }

  // الحديث الشريف
  const hadithSubj = addSubject(azharLitId, 'الحديث الشريف', 45, 10);
  {
    const u1 = addUnit(hadithSubj, 'حقوق المسلمين والدماء', 1);
    addLessons(u1, ['فضل إطعام الطعام', 'حرمة المسلم', 'حرمة تقاتل المسلمين', 'تحريم قتال المسلمين والتشديد فيه', 'فضل الشهادتين', 'حرمة الدماء']);
    const u2 = addUnit(hadithSubj, 'الطاعة والخلق والجنة', 2);
    addLessons(u2, ['وجوب طاعة النبي ﷺ', 'لن يدخل أحد الجنة إلا برحمة الله', 'صفة الجنة ونعيمها', 'حسن خلق النبي ﷺ']);
    const u3 = addUnit(hadithSubj, 'البر والرحمة والقرآن', 3);
    addLessons(u3, ['بر الوالدين', 'البر بالآباء ولو كانوا مشركين', 'فضل تلاوة القرآن وتعاهده', 'الزهد في الدنيا', 'من جوامع دعاء النبي ﷺ']);
    const u4 = addUnit(hadithSubj, 'الرضا والرحمة', 4);
    addLessons(u4, ['الرضا بنعم الله', 'مراعاة شعور الغير', 'سعة رحمة الله', 'الرحمة بالصبيان', 'حسن الظن بالله', 'محبة لقاء الله']);
    const u5 = addUnit(hadithSubj, 'الأخلاق والعبادات', 5);
    addLessons(u5, ['حب الإنسان المال', 'بيان رحمة الله بعباده', 'ذم المفتخر بما ليس عنده', 'السكينة في الصلاة', 'من وصايا الرسول ﷺ']);
    const u6 = addUnit(hadithSubj, 'الصوم والدعاء', 6);
    addLessons(u6, ['ثواب من صام يوماً في سبيل الله', 'فضل الصوم', 'دعاء تفريج الكرب', 'أحب الكلام إلى الرحمن']);
  }

  // التفسير (تفسير النسفي)
  const tafsirSubj = addSubject(azharLitId, 'التفسير', 50, 11);
  {
    const u1 = addUnit(tafsirSubj, 'سورة الذاريات', 1);
    addLessons(u1, ['البعث', 'وعيد المكذبين', 'جزاء المتقين', 'الآيات الكونية', 'قصص السابقين', 'خلق الإنسان للعبادة']);
    const u2 = addUnit(tafsirSubj, 'سورة الطور', 2);
    addLessons(u2, ['صور من عذاب الكفار', 'نعيم المتقين', 'تفنيد مزاعم المشركين', 'حفظ الله لنبيه']);
    const u3 = addUnit(tafsirSubj, 'سورة النجم', 3);
    addLessons(u3, ['صدق الوحي', 'عدم فائدة الأصنام', 'جزاء المسيئين والمحسنين', 'مظاهر العدل الإلهي', 'التعامل بالقرآن']);
    const u4 = addUnit(tafsirSubj, 'سورة القمر', 4);
    addLessons(u4, ['قرب الساعة', 'التعظي بهلاك المكذبين', 'قصة لوط', 'توبيخ مشركي مكة']);
    const u5 = addUnit(tafsirSubj, 'سورة الرحمن', 5);
    addLessons(u5, ['نعم الله على خلقه', 'دلائل قدرته', 'أهوال يوم القيامة', 'فضل الخائفين من الله وجزاؤهم']);
  }

  // الفقه الشافعي
  const fiqhShafSubj = addSubject(azharLitId, 'الفقه الشافعي', 55, 12);
  {
    const u1 = addUnit(fiqhShafSubj, 'كتاب الطلاق والخلع والإيلاء والظهار', 1);
    addLessons(u1, ['أقسام الطلاق', 'الرجعة', 'الإيلاء', 'الظهار وكفارته']);
    const u2 = addUnit(fiqhShafSubj, 'كتاب العدة والرضاع والحضانة', 2);
    addLessons(u2, ['العدة', 'الرضاع', 'الحضانة']);
    const u3 = addUnit(fiqhShafSubj, 'كتاب الجنايات والدية', 3);
    addLessons(u3, ['الجنايات', 'الدية']);
    const u4 = addUnit(fiqhShafSubj, 'كتاب الحدود', 4);
    addLessons(u4, ['حد القذف', 'حد شارب الخمر', 'حد السرقة', 'حد قطاع الطريق']);
    const u5 = addUnit(fiqhShafSubj, 'كتاب الجهاد', 5);
    addLesson(u5, 'كتاب الجهاد', 2, 1);
    const u6 = addUnit(fiqhShafSubj, 'كتاب الصيد والذبائح والأضحية والعقيقة', 6);
    addLesson(u6, 'الصيد والذبائح والأضحية والعقيقة', 2, 1);
    const u7 = addUnit(fiqhShafSubj, 'كتاب الأيمان والنذور', 7);
    addLesson(u7, 'الأيمان والنذور', 2, 1);
    const u8 = addUnit(fiqhShafSubj, 'كتاب الأقضية والشهادات', 8);
    addLesson(u8, 'الأقضية والشهادات والدعوى والبينات', 2, 1);
  }

  // الفقه الحنفي
  const fiqhHanSubj = addSubject(azharLitId, 'الفقه الحنفي', 55, 13);
  {
    const u1 = addUnit(fiqhHanSubj, 'كتاب النكاح', 1);
    addLessons(u1, ['محرمات النكاح', 'نكاح المتعة والمؤقت', 'عبارة النساء المعتبرة', 'ترتيب الأولياء', 'الكفاءة', 'المهر', 'القسم بين الزوجات']);
    const u2 = addUnit(fiqhHanSubj, 'كتاب الرضاع', 2);
    addLesson(u2, 'الرضاع', 2, 1);
    const u3 = addUnit(fiqhHanSubj, 'كتاب الطلاق', 3);
    addLessons(u3, ['صريح الطلاق', 'كنايات الطلاق', 'الرجعة', 'الخلع', 'الظهار وكفارته']);
    const u4 = addUnit(fiqhHanSubj, 'كتاب العدة', 4);
    addLessons(u4, ['الأقراء', 'خطبة المعتدة', 'الحمل وثبوت النسب']);
    const u5 = addUnit(fiqhHanSubj, 'كتاب النفقة', 5);
    addLessons(u5, ['نفقة الزوجة', 'نفقة المعتدة', 'الإعسار بالنفقة', 'الإنفاق على الأقارب']);
    const u6 = addUnit(fiqhHanSubj, 'الحضانة والأيمان', 6);
    addLessons(u6, ['الحضانة', 'كتاب الأيمان', 'حروف القسم', 'النذر']);
    const u7 = addUnit(fiqhHanSubj, 'كتاب الحدود', 7);
    addLessons(u7, ['تعريف الزنا وحده', 'التعزير', 'حد القذف', 'حد الشرب']);
    const u8 = addUnit(fiqhHanSubj, 'كتاب السرقة', 8);
    addLessons(u8, ['حد السرقة', 'فيما لا قطع فيه', 'حد قطع الطريق']);
    const u9 = addUnit(fiqhHanSubj, 'كتاب السير والوصايا', 9);
    addLessons(u9, ['الجهاد وأقسامه', 'الوصايا']);
  }

  // الفقه المالكي
  const fiqhMalSubj = addSubject(azharLitId, 'الفقه المالكي', 55, 14);
  {
    const u1 = addUnit(fiqhMalSubj, 'باب في النكاح', 1);
    addLessons(u1, ['أركان النكاح وشروطه', 'مندوبات النكاح والخطبة', 'المحرمات من النساء', 'أحكام الصداق', 'نكاح الشغار والتفويض']);
    const u2 = addUnit(fiqhMalSubj, 'الطلاق والخلع', 2);
    addLessons(u2, ['أحكام الطلاق وأقسامه', 'ألفاظ الطلاق', 'الخلع']);
    const u3 = addUnit(fiqhMalSubj, 'الرجعة والإيلاء', 3);
    addLessons(u3, ['الرجعة وأحكامها', 'المتعة', 'الظهار']);
    const u4 = addUnit(fiqhMalSubj, 'الميراث (علم الفرائض)', 4);
    addLessons(u4, [
      'تعريف علم الفرائض وحكمته', 'شروط الإرث وأسبابه وموانعه',
      'الفروض المقدرة', 'أحوال أصحاب الفروض من الذكور',
      'أحوال الوراث من النساء', 'العصبات', 'الحجب', 'العول',
      'الرد', 'التخارج', 'مقاصة الجد', 'ميراث الحمل', 'الوصية الواجبة',
    ]);
  }

  // ========== Create default admin user ==========
  const adminPasswordHash = bcrypt.hashSync('admin123', 10);
  db.prepare(`
    INSERT OR IGNORE INTO users (email, password_hash, name, role, youtube_subscribed, bio)
    VALUES ('admin@hossamfathy.com', ?, 'حسام فتحي', 'admin', 1, 'مؤسس منصة حسام فتحي التعليمية. أساعد طلاب الثانوية العامة والأزهر الشريف في تنظيم مذاكرتهم وتحقيق أهدافهم الدراسية.')
  `).run(adminPasswordHash);

  console.log('Seed completed successfully!');
  console.log('Admin account: admin@hossamfathy.com / admin123');
});

seed();
db.close();
