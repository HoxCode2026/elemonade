import { Router } from 'express';
import { authenticate } from '../middleware/auth.js';

const router = Router();
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const AI_MODEL = 'google/gemini-flash-1.5';

async function callOpenRouter(messages, maxTokens = 1024) {
  const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'https://hossam-fathy.eu.cc',
      'X-Title': 'Hossam F. Khalaf Platform',
    },
    body: JSON.stringify({
      model: AI_MODEL,
      messages,
      max_tokens: maxTokens,
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`OpenRouter API error: ${res.status} - ${err}`);
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || 'لا يوجد رد من الذكاء الاصطناعي';
}

router.use(authenticate);

// POST /ai/chat - General AI chat
router.post('/chat', async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!OPENROUTER_API_KEY) {
      return res.status(503).json({ error: 'AI service not configured' });
    }

    const response = await callOpenRouter([
      {
        role: 'system',
        content: 'أنت مساعد تعليمي ذكي في منصة حسام فتحي التعليمية. تساعد طلاب الثانوية العامة والأزهر في مصر. أجب بالعربية بشكل واضح ومختصر. ركز على الشرح التعليمي والتشجيع.',
      },
      { role: 'user', content: message },
    ]);

    res.json({ response, model: AI_MODEL });
  } catch (err) {
    res.status(500).json({ error: 'AI request failed', details: err.message });
  }
});

// POST /ai/summarize - Summarize lesson content
router.post('/summarize', async (req, res) => {
  try {
    const { content, lesson_name } = req.body;

    if (!content) {
      return res.status(400).json({ error: 'Content is required' });
    }

    if (!OPENROUTER_API_KEY) {
      return res.status(503).json({ error: 'AI service not configured' });
    }

    const response = await callOpenRouter([
      {
        role: 'system',
        content: 'أنت مساعد تعليمي. لخص المحتوى التعليمي التالي بشكل واضح ومنظم مع النقاط الرئيسية.',
      },
      {
        role: 'user',
        content: `لخص هذا الدرس${lesson_name ? ` (${lesson_name})` : ''}:\n\n${content}`,
      },
    ]);

    res.json({ summary: response });
  } catch (err) {
    res.status(500).json({ error: 'Summarization failed', details: err.message });
  }
});

// POST /ai/motivate - Get motivational message
router.post('/motivate', async (req, res) => {
  try {
    const { streak = 0, mood = 3 } = req.body;

    if (!OPENROUTER_API_KEY) {
      return res.status(503).json({ error: 'AI service not configured' });
    }

    const response = await callOpenRouter([
      {
        role: 'system',
        content: 'أنت مشجع تعليمي. اكتب رسالة تحفيزية قصيرة (جملتين أو ثلاثة) لطالب ثانوية عامة.',
      },
      {
        role: 'user',
        content: `الطالب لديه سلسلة ${streak} يوم متتالي من المذاكرة ومزاجه اليوم ${mood}/5. شجعه!`,
      },
    ], 256);

    res.json({ message: response });
  } catch (err) {
    res.status(500).json({ error: 'Motivation failed', details: err.message });
  }
});

// POST /ai/suggest-reschedule - AI-powered reschedule suggestion
router.post('/suggest-reschedule', async (req, res) => {
  try {
    const { subject_name, progress_percent, allocated_days, remaining_days } = req.body;

    if (!OPENROUTER_API_KEY) {
      return res.status(503).json({ error: 'AI service not configured' });
    }

    const response = await callOpenRouter([
      {
        role: 'system',
        content: 'أنت مستشار تعليمي. بناءً على تقدم الطالب، اقترح عدد الأيام الإضافية المطلوبة واستراتيجية للحاق. أجب بـ JSON فقط: {"extra_days": number, "advice": "string"}',
      },
      {
        role: 'user',
        content: `المادة: ${subject_name}، نسبة الإنجاز: ${progress_percent}%، الأيام المخصصة: ${allocated_days}، الأيام المتبقية في الجدول: ${remaining_days}`,
      },
    ], 512);

    try {
      const parsed = JSON.parse(response);
      res.json(parsed);
    } catch {
      res.json({ extra_days: Math.ceil(allocated_days * 0.2), advice: response });
    }
  } catch (err) {
    res.status(500).json({ error: 'AI suggestion failed', details: err.message });
  }
});

export default router;
