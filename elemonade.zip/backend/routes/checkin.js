import { Router } from 'express';
import db from '../db.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

router.use(authenticate);

/**
 * Compute the difference in days between two YYYY-MM-DD date strings.
 * Returns (dateA - dateB) in whole days.
 */
function daysDifference(dateA, dateB) {
  const a = new Date(dateA + 'T00:00:00Z');
  const b = new Date(dateB + 'T00:00:00Z');
  return Math.round((a - b) / (1000 * 60 * 60 * 24));
}

// POST /checkin
router.post('/', (req, res) => {
  try {
    const { schedule_id, date, status, mood_rating } = req.body;

    if (!schedule_id || !date || !status) {
      return res.status(400).json({ error: 'schedule_id, date, and status are required' });
    }

    if (!['done', 'partial', 'missed'].includes(status)) {
      return res.status(400).json({ error: 'Status must be done, partial, or missed' });
    }

    // Verify the schedule belongs to the user
    const schedule = db.prepare(
      'SELECT * FROM user_schedules WHERE id = ? AND user_id = ?'
    ).get(schedule_id, req.user.id);

    if (!schedule) {
      return res.status(404).json({ error: 'Schedule not found' });
    }

    const transaction = db.transaction(() => {
      // Create the checkin
      const result = db.prepare(
        `INSERT INTO daily_checkins (user_id, schedule_id, date, status, mood_rating)
         VALUES (?, ?, ?, ?, ?)`
      ).run(req.user.id, schedule_id, date, status, mood_rating || null);

      const checkin = db.prepare('SELECT * FROM daily_checkins WHERE id = ?').get(result.lastInsertRowid);

      // Update streaks
      if (status === 'done') {
        let streak = db.prepare('SELECT * FROM user_streaks WHERE user_id = ?').get(req.user.id);

        if (!streak) {
          db.prepare(
            'INSERT INTO user_streaks (user_id, current_streak, longest_streak, last_checkin_date) VALUES (?, 1, 1, ?)'
          ).run(req.user.id, date);
          streak = db.prepare('SELECT * FROM user_streaks WHERE user_id = ?').get(req.user.id);
        } else {
          const diff = streak.last_checkin_date ? daysDifference(date, streak.last_checkin_date) : null;

          if (diff === 0) {
            // Same day, no change
          } else if (diff === 1) {
            // Consecutive day, increment streak
            const newStreak = streak.current_streak + 1;
            const longestStreak = Math.max(newStreak, streak.longest_streak);
            db.prepare(
              'UPDATE user_streaks SET current_streak = ?, longest_streak = ?, last_checkin_date = ? WHERE user_id = ?'
            ).run(newStreak, longestStreak, date, req.user.id);
          } else {
            // Gap > 1 day or first checkin, reset to 1
            const longestStreak = Math.max(1, streak.longest_streak);
            db.prepare(
              'UPDATE user_streaks SET current_streak = 1, longest_streak = ?, last_checkin_date = ? WHERE user_id = ?'
            ).run(longestStreak, date, req.user.id);
          }
        }
      }

      return checkin;
    });

    const checkin = transaction();
    res.status(201).json({ checkin });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create checkin', details: err.message });
  }
});

// GET /checkin
router.get('/', (req, res) => {
  try {
    const { schedule_id, date } = req.query;

    let sql = 'SELECT * FROM daily_checkins WHERE user_id = ?';
    const params = [req.user.id];

    if (schedule_id) {
      sql += ' AND schedule_id = ?';
      params.push(schedule_id);
    }

    if (date) {
      sql += ' AND date = ?';
      params.push(date);
    }

    sql += ' ORDER BY date DESC';

    const checkins = db.prepare(sql).all(...params);
    res.json({ checkins });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch checkins', details: err.message });
  }
});

// GET /checkin/streak
router.get('/streak', (req, res) => {
  try {
    const streak = db.prepare('SELECT * FROM user_streaks WHERE user_id = ?').get(req.user.id);

    res.json({
      streak: streak || { user_id: req.user.id, current_streak: 0, longest_streak: 0, last_checkin_date: null },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch streak', details: err.message });
  }
});

// GET /checkin/today
router.get('/today', (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const checkin = db.prepare(
      'SELECT * FROM daily_checkins WHERE user_id = ? AND date = ? ORDER BY id DESC LIMIT 1'
    ).get(req.user.id, today);

    res.json({ checkin: checkin || null });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch today checkin', details: err.message });
  }
});

export default router;
