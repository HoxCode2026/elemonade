import { Router } from 'express';
import supabase from '../lib/supabase.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

// Spaced repetition intervals in days
const INTERVALS = [1, 3, 7, 14, 30, 60];

// GET /api/review/due - Get items due for review today
router.get('/due', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Get schedule sessions due for review
    const { data: dueSessions } = await supabase
      .from('schedule_sessions')
      .select(`
        id,
        subject_key,
        subject_name_ar,
        is_completed,
        completed_at,
        schedule_id:daily_schedules(
          date,
          plan_id:study_plans(user_id)
        )
      `)
      .eq('is_completed', true)
      .lte('completed_at', today)
      .order('completed_at', { ascending: true })
      .limit(20);

    // Also get tasks due for review
    const { data: dueTasks } = await supabase
      .from('study_tasks')
      .select('*')
      .eq('user_id', req.user.id)
      .eq('status', 'pending')
      .lte('due_date', today)
      .order('due_date', { ascending: true })
      .limit(10);

    res.json({
      sessions: dueSessions || [],
      tasks: dueTasks || []
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch due items', details: err.message });
  }
});

// GET /api/review/upcoming - Get upcoming review items
router.get('/upcoming', async (req, res) => {
  try {
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    const today = new Date().toISOString().split('T')[0];

    // Get completed sessions that will be due next week
    const { data: upcomingSessions } = await supabase
      .from('schedule_sessions')
      .select(`
        id,
        subject_key,
        subject_name_ar,
        is_completed,
        completed_at
      `)
      .eq('is_completed', true)
      .gt('completed_at', today)
      .lt('completed_at', nextWeek)
      .limit(30);

    res.json({ sessions: upcomingSessions || [] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch upcoming', details: err.message });
  }
});

// POST /api/review/:id/complete - Mark item as reviewed
router.post('/:id/complete', async (req, res) => {
  try {
    const { id } = req.params;
    const { difficulty } = req.body; // easy, medium, hard

    // Calculate next review date based on difficulty
    let intervalDays = INTERVALS[1]; // default 3 days
    if (difficulty === 'easy') intervalDays = INTERVALS[2]; // 7 days
    else if (difficulty === 'hard') intervalDays = INTERVALS[0]; // 1 day

    const nextDate = new Date(Date.now() + intervalDays * 24 * 60 * 60 * 1000)
      .toISOString().split('T')[0];

    // Update the session/task
    const { error } = await supabase
      .from('study_tasks')
      .update({ 
        due_date: nextDate,
        status: 'pending'
      })
      .eq('id', id);

    if (error) throw error;

    // Award XP for reviewing
    const xpReward = difficulty === 'easy' ? 20 : difficulty === 'medium' ? 15 : 10;
    
    // Update user XP
    const { data: existingXP } = await supabase
      .from('user_xp')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    if (existingXP) {
      await supabase
        .from('user_xp')
        .update({ 
          total_xp: existingXP.total_xp + xpReward,
          weekly_xp: existingXP.weekly_xp + xpReward,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', req.user.id);
    } else {
      await supabase
        .from('user_xp')
        .insert({
          user_id: req.user.id,
          total_xp: xpReward,
          level: 1,
          weekly_xp: xpReward
        });
    }

    res.json({ 
      message: 'تم مراجعة العنصر',
      next_review: nextDate,
      xp_earned: xpReward 
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark reviewed', details: err.message });
  }
});

// GET /api/review/stats - Get review statistics
router.get('/stats', async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Total reviewed today
    const { count: reviewedToday } = await supabase
      .from('study_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', req.user.id)
      .eq('status', 'completed')
      .eq('updated_at', today);

    // Total due
    const { count: dueNow } = await supabase
      .from('study_tasks')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', req.user.id)
      .eq('status', 'pending')
      .lte('due_date', today);

    // Get streak
    const { data: streak } = await supabase
      .from('user_streaks')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    res.json({
      reviewed_today: reviewedToday || 0,
      due_now: dueNow || 0,
      current_streak: streak?.current_streak || 0,
      longest_streak: streak?.longest_streak || 0
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', details: err.message });
  }
});

export default router;