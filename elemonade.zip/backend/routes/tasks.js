import { Router } from 'express';
import db from '../db.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

router.use(authenticate);

// GET /tasks
router.get('/', (req, res) => {
  try {
    const { date } = req.query;

    let sql = 'SELECT * FROM user_tasks WHERE user_id = ?';
    const params = [req.user.id];

    if (date) {
      sql += ' AND date = ?';
      params.push(date);
    }

    sql += ' ORDER BY date DESC, id DESC';

    const tasks = db.prepare(sql).all(...params);
    res.json({ tasks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tasks', details: err.message });
  }
});

// POST /tasks
router.post('/', (req, res) => {
  try {
    const { date, title } = req.body;

    if (!date || !title) {
      return res.status(400).json({ error: 'Date and title are required' });
    }

    const result = db.prepare(
      'INSERT INTO user_tasks (user_id, date, title) VALUES (?, ?, ?)'
    ).run(req.user.id, date, title);

    const task = db.prepare('SELECT * FROM user_tasks WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ task });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create task', details: err.message });
  }
});

// PUT /tasks/:id
router.put('/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { title, is_completed } = req.body;

    // Verify ownership
    const existing = db.prepare(
      'SELECT * FROM user_tasks WHERE id = ? AND user_id = ?'
    ).get(id, req.user.id);

    if (!existing) {
      return res.status(404).json({ error: 'Task not found' });
    }

    const updates = [];
    const values = [];

    if (title !== undefined) {
      updates.push('title = ?');
      values.push(title);
    }

    if (is_completed !== undefined) {
      updates.push('is_completed = ?');
      values.push(is_completed ? 1 : 0);
    }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(id);
    db.prepare(`UPDATE user_tasks SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    const task = db.prepare('SELECT * FROM user_tasks WHERE id = ?').get(id);
    res.json({ task });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update task', details: err.message });
  }
});

// DELETE /tasks/:id
router.delete('/:id', (req, res) => {
  try {
    const { id } = req.params;

    // Verify ownership
    const existing = db.prepare(
      'SELECT * FROM user_tasks WHERE id = ? AND user_id = ?'
    ).get(id, req.user.id);

    if (!existing) {
      return res.status(404).json({ error: 'Task not found' });
    }

    db.prepare('DELETE FROM user_tasks WHERE id = ?').run(id);
    res.json({ message: 'Task deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete task', details: err.message });
  }
});

export default router;
