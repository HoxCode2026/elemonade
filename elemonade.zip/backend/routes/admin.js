import { Router } from 'express';
import db from '../db.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();

// --- Public route: active ads ---
// GET /admin/ads/active?slot=
router.get('/ads/active', (req, res) => {
  try {
    const { slot } = req.query;
    const today = new Date().toISOString().split('T')[0];

    let sql = `
      SELECT * FROM ads
      WHERE is_active = 1
        AND (start_date IS NULL OR start_date <= ?)
        AND (end_date IS NULL OR end_date >= ?)
    `;
    const params = [today, today];

    if (slot) {
      sql += ' AND slot = ?';
      params.push(slot);
    }

    sql += ' ORDER BY created_at DESC';

    const ads = db.prepare(sql).all(...params);
    res.json({ ads });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch active ads', details: err.message });
  }
});

// All routes below require admin
router.use(authenticate, authorize('admin'));

// GET /admin/stats
router.get('/stats', (_req, res) => {
  try {
    const userCount = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;
    const activeSchedules = db.prepare('SELECT COUNT(*) AS count FROM user_schedules WHERE is_active = 1').get().count;
    const totalCheckins = db.prepare('SELECT COUNT(*) AS count FROM daily_checkins').get().count;
    const avgStreak = db.prepare('SELECT AVG(current_streak) AS avg FROM user_streaks').get().avg || 0;

    res.json({
      stats: {
        users: userCount,
        active_schedules: activeSchedules,
        total_checkins: totalCheckins,
        average_streak: Math.round(avgStreak * 100) / 100,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', details: err.message });
  }
});

// GET /admin/users
router.get('/users', (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
    const offset = (page - 1) * limit;

    const users = db.prepare(
      'SELECT id, email, name, role, created_at, youtube_subscribed FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?'
    ).all(limit, offset);

    const total = db.prepare('SELECT COUNT(*) AS count FROM users').get().count;

    res.json({
      users,
      pagination: {
        page,
        limit,
        total,
        total_pages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch users', details: err.message });
  }
});

// PUT /admin/users/:id/role
router.put('/users/:id/role', (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;

    if (!role || !['admin', 'student'].includes(role)) {
      return res.status(400).json({ error: 'Role must be admin or student' });
    }

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);

    const updated = db.prepare(
      'SELECT id, email, name, role, created_at, youtube_subscribed FROM users WHERE id = ?'
    ).get(id);

    res.json({ user: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update user role', details: err.message });
  }
});

// POST /admin/resources
router.post('/resources', (req, res) => {
  try {
    const { lesson_id, type, title, content_url, content_text } = req.body;

    if (!lesson_id || !type || !title) {
      return res.status(400).json({ error: 'lesson_id, type, and title are required' });
    }

    if (!['video', 'text'].includes(type)) {
      return res.status(400).json({ error: 'Type must be video or text' });
    }

    const result = db.prepare(
      `INSERT INTO learning_resources (lesson_id, admin_id, type, title, content_url, content_text)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(lesson_id, req.user.id, type, title, content_url || null, content_text || null);

    const resource = db.prepare('SELECT * FROM learning_resources WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ resource });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create resource', details: err.message });
  }
});

// PUT /admin/resources/:id
router.put('/resources/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { lesson_id, type, title, content_url, content_text } = req.body;

    const existing = db.prepare('SELECT * FROM learning_resources WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ error: 'Resource not found' });
    }

    const updates = [];
    const values = [];

    if (lesson_id !== undefined) { updates.push('lesson_id = ?'); values.push(lesson_id); }
    if (type !== undefined) { updates.push('type = ?'); values.push(type); }
    if (title !== undefined) { updates.push('title = ?'); values.push(title); }
    if (content_url !== undefined) { updates.push('content_url = ?'); values.push(content_url); }
    if (content_text !== undefined) { updates.push('content_text = ?'); values.push(content_text); }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(id);
    db.prepare(`UPDATE learning_resources SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    const resource = db.prepare('SELECT * FROM learning_resources WHERE id = ?').get(id);
    res.json({ resource });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update resource', details: err.message });
  }
});

// DELETE /admin/resources/:id
router.delete('/resources/:id', (req, res) => {
  try {
    const { id } = req.params;

    const existing = db.prepare('SELECT * FROM learning_resources WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ error: 'Resource not found' });
    }

    db.prepare('DELETE FROM learning_resources WHERE id = ?').run(id);
    res.json({ message: 'Resource deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete resource', details: err.message });
  }
});

// GET /admin/resources
router.get('/resources', (_req, res) => {
  try {
    const resources = db.prepare(`
      SELECT lr.*,
             l.name AS lesson_name,
             u.name AS unit_name,
             s.name AS subject_name
      FROM learning_resources lr
      LEFT JOIN lessons l ON lr.lesson_id = l.id
      LEFT JOIN units u ON l.unit_id = u.id
      LEFT JOIN subjects s ON u.subject_id = s.id
      ORDER BY lr.created_at DESC
    `).all();

    res.json({ resources });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch resources', details: err.message });
  }
});

// POST /admin/ads
router.post('/ads', (req, res) => {
  try {
    const { name, type, slot, content_html, image_url, link_url, start_date, end_date } = req.body;

    if (!name || !type || !slot || !content_html) {
      return res.status(400).json({ error: 'name, type, slot, and content_html are required' });
    }

    if (!['banner', 'popup'].includes(type)) {
      return res.status(400).json({ error: 'Type must be banner or popup' });
    }

    const result = db.prepare(
      `INSERT INTO ads (name, type, slot, content_html, image_url, link_url, start_date, end_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(name, type, slot, content_html, image_url || null, link_url || null, start_date || null, end_date || null);

    const ad = db.prepare('SELECT * FROM ads WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ ad });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create ad', details: err.message });
  }
});

// PUT /admin/ads/:id
router.put('/ads/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, type, slot, content_html, image_url, link_url, is_active, start_date, end_date } = req.body;

    const existing = db.prepare('SELECT * FROM ads WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ error: 'Ad not found' });
    }

    const updates = [];
    const values = [];

    if (name !== undefined) { updates.push('name = ?'); values.push(name); }
    if (type !== undefined) { updates.push('type = ?'); values.push(type); }
    if (slot !== undefined) { updates.push('slot = ?'); values.push(slot); }
    if (content_html !== undefined) { updates.push('content_html = ?'); values.push(content_html); }
    if (image_url !== undefined) { updates.push('image_url = ?'); values.push(image_url); }
    if (link_url !== undefined) { updates.push('link_url = ?'); values.push(link_url); }
    if (is_active !== undefined) { updates.push('is_active = ?'); values.push(is_active ? 1 : 0); }
    if (start_date !== undefined) { updates.push('start_date = ?'); values.push(start_date); }
    if (end_date !== undefined) { updates.push('end_date = ?'); values.push(end_date); }

    if (updates.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    values.push(id);
    db.prepare(`UPDATE ads SET ${updates.join(', ')} WHERE id = ?`).run(...values);

    const ad = db.prepare('SELECT * FROM ads WHERE id = ?').get(id);
    res.json({ ad });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update ad', details: err.message });
  }
});

// DELETE /admin/ads/:id
router.delete('/ads/:id', (req, res) => {
  try {
    const { id } = req.params;

    const existing = db.prepare('SELECT * FROM ads WHERE id = ?').get(id);
    if (!existing) {
      return res.status(404).json({ error: 'Ad not found' });
    }

    db.prepare('DELETE FROM ads WHERE id = ?').run(id);
    res.json({ message: 'Ad deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete ad', details: err.message });
  }
});

// GET /admin/ads
router.get('/ads', (_req, res) => {
  try {
    const ads = db.prepare('SELECT * FROM ads ORDER BY created_at DESC').all();
    res.json({ ads });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch ads', details: err.message });
  }
});

// POST /admin/notifications - Create notification for all users
router.post('/notifications', (req, res) => {
  try {
    const { type, title, message, link } = req.body;

    if (!type || !title || !message) {
      return res.status(400).json({ error: 'type, title, and message are required' });
    }

    const users = db.prepare('SELECT id FROM users').all();
    const insert = db.prepare(
      'INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)'
    );

    const insertMany = db.transaction((userList) => {
      for (const user of userList) {
        insert.run(user.id, type, title, message, link || null);
      }
    });

    insertMany(users);
    res.status(201).json({ message: `Notification sent to ${users.length} users` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create notification', details: err.message });
  }
});

// POST /admin/video-views - Track video view
router.post('/video-views', authenticate, (req, res) => {
  try {
    const { video_id } = req.body;
    if (!video_id) return res.status(400).json({ error: 'video_id required' });

    db.prepare('INSERT INTO video_views (video_id, user_id) VALUES (?, ?)').run(video_id, req.user.id);
    res.json({ message: 'View tracked' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to track view', details: err.message });
  }
});

// GET /admin/video-stats - Get video statistics
router.get('/video-stats', (req, res) => {
  try {
    const stats = db.prepare(`
      SELECT lr.id, lr.title, lr.lesson_id, l.name as lesson_name,
             COUNT(vv.id) as view_count
      FROM learning_resources lr
      LEFT JOIN lessons l ON lr.lesson_id = l.id
      LEFT JOIN video_views vv ON vv.video_id = lr.id
      WHERE lr.type = 'video'
      GROUP BY lr.id
      ORDER BY view_count DESC
    `).all();

    res.json({ stats });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', details: err.message });
  }
});

export default router;
