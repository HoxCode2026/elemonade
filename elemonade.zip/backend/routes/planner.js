import { Router } from 'express';
import supabase from '../lib/supabase.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

// GET /api/planner/config - Get subject configs for a grade/track
router.get('/config', async (req, res) => {
  try {
    const { grade, track } = req.query;
    
    const { data: configs, error } = await supabase
      .from('subject_configs')
      .select('*')
      .eq('grade', grade || '3sec')
      .eq('track', track || 'science_bio')
      .order('weight', { ascending: false });

    if (error) throw error;
    res.json({ subjects: configs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch config', details: err.message });
  }
});

// GET /api/planner/settings - Get user study settings
router.get('/settings', async (req, res) => {
  try {
    const { data: settings, error } = await supabase
      .from('user_study_settings')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    res.json({ settings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch settings', details: err.message });
  }
});

// POST /api/planner/settings - Create/update study settings
router.post('/settings', async (req, res) => {
  try {
    const { grade, track, daily_hours, exam_date, off_days, subjects } = req.body;

    const { data: existing } = await supabase
      .from('user_study_settings')
      .select('id')
      .eq('user_id', req.user.id)
      .single();

    const settingsData = {
      user_id: req.user.id,
      grade: grade || '3sec',
      track: track || 'science_bio',
      daily_hours: daily_hours || 6,
      exam_date,
      off_days: off_days || ['friday'],
      updated_at: new Date().toISOString()
    };

    let settings;
    if (existing) {
      const { data, error } = await supabase
        .from('user_study_settings')
        .update(settingsData)
        .eq('user_id', req.user.id)
        .select()
        .single();
      if (error) throw error;
      settings = data;
    } else {
      const { data, error } = await supabase
        .from('user_study_settings')
        .insert(settingsData)
        .select()
        .single();
      if (error) throw error;
      settings = data;
    }

    // Update subjects
    if (subjects && subjects.length > 0) {
      await supabase
        .from('user_subjects')
        .delete()
        .eq('user_id', req.user.id);

      const subjectsData = subjects.map(s => ({
        user_id: req.user.id,
        subject_key: s.key,
        subject_name_ar: s.name,
        proficiency_level: s.level || 'medium',
        is_pressed: s.pressed || false
      }));

      await supabase
        .from('user_subjects')
        .insert(subjectsData);
    }

    res.json({ settings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save settings', details: err.message });
  }
});

// POST /api/planner/generate - Generate study plan
router.post('/generate', async (req, res) => {
  try {
    const { start_date, end_date, name } = req.body;

    // Get user settings
    const { data: settings } = await supabase
      .from('user_study_settings')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    if (!settings) {
      return res.status(400).json({ error: 'Please set up study settings first' });
    }

    // Get subject configs
    const { data: configs } = await supabase
      .from('subject_configs')
      .select('*')
      .eq('grade', settings.grade)
      .eq('track', settings.track)
      .order('weight', { ascending: false });

    // Get user subjects (custom preferences)
    const { data: userSubjects } = await supabase
      .from('user_subjects')
      .select('*')
      .eq('user_id', req.user.id);

    // Calculate dates
    const start = new Date(start_date || settings.exam_date || Date.now());
    const end = new Date(end_date || settings.exam_date || Date.now() + 30 * 24 * 60 * 60 * 1000);
    
    const daysDiff = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    const offDays = settings.off_days || ['friday'];
    const workingDays = daysDiff - offDays.length;

    const totalHours = workingDays * settings.daily_hours;

    // Create plan
    const { data: plan, error: planError } = await supabase
      .from('study_plans')
      .insert({
        user_id: req.user.id,
        name: name || 'خطة مذاكرة',
        start_date: start.toISOString().split('T')[0],
        end_date: end.toISOString().split('T')[0],
        status: 'active'
      })
      .select()
      .single();

    if (planError) throw planError;

    // Generate daily schedules
    let currentDate = new Date(start);
    let dayOrder = 1;
    let sessionOrder = 1;

    const schedules = [];
    const sessions = [];

    while (currentDate <= end) {
      const dayName = currentDate.toLocaleDateString('ar-EG', { weekday: 'long' });
      
      if (!offDays.includes(dayName.toLowerCase())) {
        const dayConfigs = calculateDaySchedule(configs, userSubjects, settings.daily_hours);
        
        const { data: schedule, error: scheduleError } = await supabase
          .from('daily_schedules')
          .insert({
            plan_id: plan.id,
            date: currentDate.toISOString().split('T')[0],
            day_order: dayOrder,
            total_hours: dayConfigs.totalHours
          })
          .select()
          .single();

        if (scheduleError) throw scheduleError;
        schedules.push(schedule);

        // Create sessions for this day
        let sessionTime = 8; // Start at 8 AM
        
        for (const session of dayConfigs.sessions) {
          const startTime = `${String(sessionTime).padStart(2, '0')}:00`;
          sessionTime += Math.ceil(session.duration / 60);
          const endTime = `${String(sessionTime).padStart(2, '0')}:00`;

          sessions.push({
            schedule_id: schedule.id,
            subject_key: session.subjectKey,
            subject_name_ar: session.subjectName,
            start_time: startTime,
            end_time: endTime,
            duration: session.duration,
            task_type: session.taskType,
            order_index: sessionOrder++
          });
        }
      }
      
      currentDate.setDate(currentDate.getDate() + 1);
      dayOrder++;
    }

    // Insert all sessions
    if (sessions.length > 0) {
      const { error: sessionsError } = await supabase
        .from('schedule_sessions')
        .insert(sessions);

      if (sessionsError) throw sessionsError;
    }

    res.json({ 
      plan, 
      schedules: schedules.length,
      sessions: sessions.length,
      message: 'تم إنشاء الخطة بنجاح'
    });
  } catch (err) {
    console.error('Generate error:', err);
    res.status(500).json({ error: 'Failed to generate plan', details: err.message });
  }
});

// GET /api/planner/plan - Get current plan
router.get('/plan', async (req, res) => {
  try {
    const { data: plan } = await supabase
      .from('study_plans')
      .select('*')
      .eq('user_id', req.user.id)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (!plan) {
      return res.json({ plan: null, schedules: [], sessions: [] });
    }

    const { data: schedules } = await supabase
      .from('daily_schedules')
      .select('*')
      .eq('plan_id', plan.id)
      .order('date', { ascending: true });

    const { data: sessions } = await supabase
      .from('schedule_sessions')
      .select('*')
      .in('schedule_id', schedules?.map(s => s.id) || [])
      .order('order_index', { ascending: true });

    res.json({ plan, schedules: schedules || [], sessions: sessions || [] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch plan', details: err.message });
  }
});

// POST /api/planner/session/:id/complete - Mark session complete
router.post('/session/:id/complete', async (req, res) => {
  try {
    const { id } = req.params;

    const { error } = await supabase
      .from('schedule_sessions')
      .update({ 
        is_completed: true, 
        completed_at: new Date().toISOString() 
      })
      .eq('id', id);

    if (error) throw error;

    // Award XP
    await awardXP(req.user.id, 25);

    // Check and award badges
    await checkBadges(req.user.id);

    res.json({ message: 'تم完成 الجلسة', xp_earned: 25 });
  } catch (err) {
    res.status(500).json({ error: 'Failed to complete session', details: err.message });
  }
});

// GET /api/planner/tasks - Get tasks
router.get('/tasks', async (req, res) => {
  try {
    const { status, date } = req.query;
    
    let query = supabase
      .from('study_tasks')
      .select('*')
      .eq('user_id', req.user.id)
      .order('due_date', { ascending: true });

    if (status) query = query.eq('status', status);
    if (date) query = query.eq('due_date', date);

    const { data: tasks, error } = await query;
    if (error) throw error;

    res.json({ tasks: tasks || [] });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tasks', details: err.message });
  }
});

// POST /api/planner/tasks - Create task
router.post('/tasks', async (req, res) => {
  try {
    const { subject_key, task_type, title, description, duration_minutes, priority, due_date } = req.body;

    const { data: task, error } = await supabase
      .from('study_tasks')
      .insert({
        user_id: req.user.id,
        subject_key,
        task_type,
        title,
        description,
        duration_minutes: duration_minutes || 60,
        priority: priority || 'medium',
        due_date,
        status: 'pending'
      })
      .select()
      .single();

    if (error) throw error;
    res.status(201).json({ task });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create task', details: err.message });
  }
});

// PATCH /api/planner/tasks/:id - Update task
router.patch('/tasks/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, title, description } = req.body;

    const updates = { updated_at: new Date().toISOString() };
    if (status) updates.status = status;
    if (title) updates.title = title;
    if (description) updates.description = description;

    const { data: task, error } = await supabase
      .from('study_tasks')
      .update(updates)
      .eq('id', id)
      .eq('user_id', req.user.id)
      .select()
      .single();

    if (error) throw error;

    // Award XP for completing task
    if (status === 'completed') {
      await awardXP(req.user.id, 15);
    }

    res.json({ task });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update task', details: err.message });
  }
});

// GET /api/planner/stats - Get user stats (XP, streak, badges)
router.get('/stats', async (req, res) => {
  try {
    // Get XP
    const { data: xp } = await supabase
      .from('user_xp')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    // Get streak
    const { data: streak } = await supabase
      .from('user_streaks')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    // Get badges
    const { data: badges } = await supabase
      .from('user_badges')
      .select('*, badge:badges(*)')
      .eq('user_id', req.user.id);

    // Get recent sessions
    const { data: recentSessions } = await supabase
      .from('study_sessions')
      .select('*')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false })
      .limit(10);

    res.json({ 
      xp: xp || { total_xp: 0, level: 1, weekly_xp: 0 },
      streak: streak || { current_streak: 0, longest_streak: 0 },
      badges: badges || [],
      recent_sessions: recentSessions || []
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', details: err.message });
  }
});

// POST /api/planner/study-session - Log a study session
router.post('/study-session', async (req, res) => {
  try {
    const { subject_key, duration_minutes } = req.body;

    const xp = Math.floor(duration_minutes / 10) * 10 + 10;

    const { data: session, error } = await supabase
      .from('study_sessions')
      .insert({
        user_id: req.user.id,
        subject_key,
        duration_minutes,
        xp_earned: xp,
        date: new Date().toISOString().split('T')[0]
      })
      .select()
      .single();

    if (error) throw error;

    // Award XP and update streak
    await awardXP(req.user.id, xp);
    await updateStreak(req.user.id);

    // Check badges
    await checkBadges(req.user.id);

    res.json({ session, xp_earned: xp });
  } catch (err) {
    res.status(500).json({ error: 'Failed to log session', details: err.message });
  }
});

// =============================================
// HELPER FUNCTIONS
// =============================================

function calculateDaySchedule(configs, userSubjects, dailyHours) {
  const sessions = [];
  let remainingHours = dailyHours;

  // Adjust weights by user proficiency
  const adjustedConfigs = configs.map(c => {
    const userSub = userSubjects?.find(us => us.subject_key === c.subject_key);
    let weight = c.weight;
    
    if (userSub) {
      if (userSub.proficiency_level === 'weak') weight *= 1.3;
      else if (userSub.proficiency_level === 'strong') weight *= 0.8;
      if (userSub.is_pressed) weight *= 1.2;
    }
    
    return { ...c, adjustedWeight: weight };
  });

  // Normalize weights
  const totalWeight = adjustedConfigs.reduce((sum, c) => sum + c.adjustedWeight, 0);
  const normalizedConfigs = adjustedConfigs.map(c => ({
    ...c,
    normalizedWeight: c.adjustedWeight / totalWeight
  }));

  // Create sessions
  const taskTypes = ['study', 'practice', 'review'];
  let taskIndex = 0;

  for (const config of normalizedConfigs) {
    if (remainingHours <= 0) break;
    
    const hours = Math.min(remainingHours * config.normalizedWeight, 2);
    const duration = Math.round(hours * 60);
    
    if (duration >= 30) {
      sessions.push({
        subjectKey: config.subject_key,
        subjectName: config.subject_name_ar,
        duration,
        taskType: taskTypes[taskIndex % 3]
      });
      remainingHours -= hours;
    }
    taskIndex++;
  }

  return {
    totalHours: dailyHours - remainingHours,
    sessions
  };
}

async function awardXP(userId, xp) {
  const { data: existing } = await supabase
    .from('user_xp')
    .select('*')
    .eq('user_id', userId)
    .single();

  const today = new Date().toISOString().split('T')[0];
  let weeklyXP = existing?.weekly_xp || 0;
  
  if (existing?.last_xp_date !== today) {
    weeklyXP = xp;
  } else {
    weeklyXP += xp;
  }

  const newTotal = (existing?.total_xp || 0) + xp;
  const newLevel = Math.floor(newTotal / 500) + 1;

  if (existing) {
    await supabase
      .from('user_xp')
      .update({
        total_xp: newTotal,
        level: newLevel,
        weekly_xp: weeklyXP,
        last_xp_date: today,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId);
  } else {
    await supabase
      .from('user_xp')
      .insert({
        user_id: userId,
        total_xp: newTotal,
        level: newLevel,
        weekly_xp: weeklyXP,
        last_xp_date: today
      });
  }
}

async function updateStreak(userId) {
  const today = new Date().toISOString().split('T')[0];
  
  const { data: streak } = await supabase
    .from('user_streaks')
    .select('*')
    .eq('user_id', userId)
    .single();

  let newStreak = 1;
  let startDate = today;

  if (streak) {
    const lastDate = streak.last_study_date;
    const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    if (lastDate === today) {
      // Already studied today
      return;
    } else if (lastDate === yesterday) {
      newStreak = streak.current_streak + 1;
      startDate = streak.streak_start_date || today;
    }
    
    const longest = Math.max(streak.longest_streak, newStreak);
    
    await supabase
      .from('user_streaks')
      .update({
        current_streak: newStreak,
        longest_streak: longest,
        last_study_date: today,
        streak_start_date: startDate,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId);
  } else {
    await supabase
      .from('user_streaks')
      .insert({
        user_id: userId,
        current_streak: 1,
        longest_streak: 1,
        last_study_date: today,
        streak_start_date: today
      });
  }
}

async function checkBadges(userId) {
  // Get current stats
  const { data: xp } = await supabase
    .from('user_xp')
    .select('*')
    .eq('user_id', userId)
    .single();

  const { data: streak } = await supabase
    .from('user_streaks')
    .select('*')
    .eq('user_id', userId)
    .single();

  const { data: sessions } = await supabase
    .from('study_sessions')
    .select('id')
    .eq('user_id', userId);

  const { data: allBadges } = await supabase
    .from('badges')
    .select('*');

  const { data: earnedBadges } = await supabase
    .from('user_badges')
    .select('badge_id')
    .eq('user_id', userId);

  const earnedIds = earnedBadges?.map(b => b.badge_id) || [];

  // Check each badge
  for (const badge of allBadges || []) {
    if (earnedIds.includes(badge.id)) continue;

    let shouldAward = false;

    switch (badge.requirement_type) {
      case 'sessions':
        shouldAward = (sessions?.length || 0) >= badge.requirement_value;
        break;
      case 'streak':
        shouldAward = (streak?.current_streak || 0) >= badge.requirement_value;
        break;
      case 'total_xp':
        shouldAward = (xp?.total_xp || 0) >= badge.requirement_value;
        break;
      case 'level':
        shouldAward = (xp?.level || 0) >= badge.requirement_value;
        break;
    }

    if (shouldAward) {
      await supabase
        .from('user_badges')
        .insert({
          user_id: userId,
          badge_id: badge.id
        });

      if (badge.xp_reward > 0) {
        await awardXP(userId, badge.xp_reward);
      }
    }
  }
}

export default router;
