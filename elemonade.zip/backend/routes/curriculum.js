import { Router } from 'express';
import db from '../db.js';

const router = Router();

// GET /curriculum/systems
router.get('/systems', (_req, res) => {
  try {
    const systems = db.prepare('SELECT * FROM education_systems ORDER BY name').all();
    res.json({ systems });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch education systems', details: err.message });
  }
});

// GET /curriculum/systems/:systemId/tracks
router.get('/systems/:systemId/tracks', (req, res) => {
  try {
    const { systemId } = req.params;
    const tracks = db.prepare(
      'SELECT * FROM tracks WHERE system_id = ? ORDER BY name'
    ).all(systemId);
    res.json({ tracks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tracks', details: err.message });
  }
});

// GET /curriculum/tracks/:trackId/subjects
router.get('/tracks/:trackId/subjects', (req, res) => {
  try {
    const { trackId } = req.params;
    const subjects = db.prepare(
      'SELECT * FROM subjects WHERE track_id = ? ORDER BY display_order, name'
    ).all(trackId);
    res.json({ subjects });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subjects', details: err.message });
  }
});

// GET /curriculum/subjects/:subjectId/units
router.get('/subjects/:subjectId/units', (req, res) => {
  try {
    const { subjectId } = req.params;
    const units = db.prepare(
      'SELECT * FROM units WHERE subject_id = ? ORDER BY display_order, name'
    ).all(subjectId);

    const unitsWithLessons = units.map((unit) => {
      const lessons = db.prepare(
        'SELECT * FROM lessons WHERE unit_id = ? ORDER BY display_order, name'
      ).all(unit.id);
      return { ...unit, lessons };
    });

    res.json({ units: unitsWithLessons });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch units', details: err.message });
  }
});

// GET /curriculum/lessons/:lessonId/resources
router.get('/lessons/:lessonId/resources', (req, res) => {
  try {
    const { lessonId } = req.params;
    const resources = db.prepare(
      'SELECT * FROM learning_resources WHERE lesson_id = ? ORDER BY created_at DESC'
    ).all(lessonId);
    res.json({ resources });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch resources', details: err.message });
  }
});

export default router;
