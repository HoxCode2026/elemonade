import { Router } from 'express';
import supabase from '../lib/supabase.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

// GET /api/rooms - List active rooms
router.get('/', async (req, res) => {
  try {
    const { data: rooms, error } = await supabase
      .from('study_rooms')
      .select(`
        *,
        host_name:users!study_rooms_host_id_fkey(name),
        user_count:room_participants(count)
      `)
      .eq('status', 'active')
      .order('created_at', { ascending: false });

    if (error) throw error;

    const formattedRooms = rooms.map(room => ({
      id: room.id,
      name: room.name,
      type: room.type,
      host_id: room.host_id,
      host_name: room.host_name,
      max_users: room.max_users,
      status: room.status,
      created_at: room.created_at,
      user_count: room.user_count?.[0]?.count || 0
    }));

    res.json({ rooms: formattedRooms });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch rooms', details: err.message });
  }
});

// POST /api/rooms - Create a room
router.post('/', async (req, res) => {
  try {
    const { name, type, max_users } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ error: 'اسم الغرفة مطلوب' });
    }

    const roomType = ['focus', 'group', 'silent'].includes(type) ? type : 'group';
    const maxUsers = Math.min(Math.max(parseInt(max_users) || 10, 2), 20);

    const { data: userData } = await supabase
      .from('users')
      .select('name')
      .eq('id', req.user.id)
      .single();

    const hostName = userData?.name || 'مضيف';

    const { data: room, error } = await supabase
      .from('study_rooms')
      .insert({
        name: name.trim(),
        host_id: req.user.id,
        host_name: hostName,
        type: roomType,
        max_users: maxUsers,
        status: 'active'
      })
      .select()
      .single();

    if (error) throw error;

    await supabase
      .from('room_participants')
      .insert({
        room_id: room.id,
        user_id: req.user.id,
        status: 'studying',
        focus_score: 50
      });

    res.status(201).json({ room });
  } catch (err) {
    res.status(500).json({ error: 'فشل إنشاء الغرفة', details: err.message });
  }
});

// GET /api/rooms/:id - Get room details
router.get('/:id', async (req, res) => {
  try {
    const { data: room, error: roomError } = await supabase
      .from('study_rooms')
      .select('*, host_name:users!study_rooms_host_id_fkey(name)')
      .eq('id', req.params.id)
      .single();

    if (roomError || !room || room.status === 'closed') {
      return res.status(404).json({ error: 'الغرفة غير موجودة أو مغلقة' });
    }

    const { data: participants } = await supabase
      .from('room_participants')
      .select('*, user_name:users!room_participants_user_id_fkey(name, avatar_url)')
      .eq('room_id', req.params.id)
      .is('left_at', null);

    const { data: messages } = await supabase
      .from('room_messages')
      .select('*, user_name:users!room_messages_user_id_fkey(name)')
      .eq('room_id', req.params.id)
      .order('created_at', { ascending: true })
      .limit(50);

    res.json({ 
      room, 
      participants: participants || [], 
      messages: messages || [] 
    });
  } catch (err) {
    res.status(500).json({ error: 'فشل جلب بيانات الغرفة', details: err.message });
  }
});

// POST /api/rooms/:id/close - Close a room (host only)
router.post('/:id/close', async (req, res) => {
  try {
    const { data: room, error: roomError } = await supabase
      .from('study_rooms')
      .select('host_id')
      .eq('id', req.params.id)
      .single();

    if (roomError || !room) {
      return res.status(404).json({ error: 'الغرفة غير موجودة' });
    }

    if (room.host_id !== req.user.id) {
      return res.status(403).json({ error: 'فقط المضيف يمكنه إغلاق الغرفة' });
    }

    await supabase
      .from('study_rooms')
      .update({ status: 'closed', closed_at: new Date().toISOString() })
      .eq('id', req.params.id);

    await supabase
      .from('room_participants')
      .update({ left_at: new Date().toISOString() })
      .eq('room_id', req.params.id)
      .is('left_at', null);

    res.json({ message: 'تم إغلاق الغرفة' });
  } catch (err) {
    res.status(500).json({ error: 'فشل إغلاق الغرفة', details: err.message });
  }
});

export default router;
