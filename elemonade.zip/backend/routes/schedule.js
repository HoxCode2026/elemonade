import { Router } from 'express';
import db from '../db.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();
router.use(authenticate);

const DIFFICULTY_FACTORS = { weak: 1.35, medium: 1.0, strong: 0.75 };
const PHASE_RATIOS_BY_TYPE = {
  language: { study: 0.4, practice: 0.4, review: 0.2 },
  science: { study: 0.5, practice: 0.3, review: 0.2 },
  math: { study: 0.3, practice: 0.5, review: 0.2 },
  default: { study: 0.5, practice: 0.3, review: 0.2 }
};
const MAX_SUBJECTS_PER_DAY = 2;
const REVIEW_INTERVALS = [1, 3, 7, 14, 30];
const DEFAULT_DAILY_HOURS = 8;
const MAX_DAILY_HOURS = 8;
const MIN_DAILY_HOURS = 4;

router.post('/subjects', (req, res) => {
  try {
    const { subjects } = req.body;
    if (!subjects || !Array.isArray(subjects)) {
      return res.status(400).json({ error: 'subjects array is required' });
    }

    const transaction = db.transaction(() => {
      db.prepare('DELETE FROM user_subjects WHERE user_id = ?').run(req.user.id);

      const insert = db.prepare(
        'INSERT INTO user_subjects (user_id, subject_id, difficulty_level, custom_weight) VALUES (?, ?, ?, ?)'
      );

      for (const s of subjects) {
        if (s.is_selected) {
          insert.run(req.user.id, s.subject_id, s.difficulty_level || 'medium', s.custom_weight || null);
        }
      }
    });

    transaction();
    res.json({ message: 'Subjects saved' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to save subjects', details: err.message });
  }
});

router.get('/subjects', (req, res) => {
  try {
    const trackId = req.query.track_id;

    const subjects = db.prepare(`
      SELECT s.*, 
             us.difficulty_level,
             us.custom_weight,
             CASE WHEN us.id IS NOT NULL THEN 1 ELSE 0 END as is_selected
      FROM subjects s
      LEFT JOIN user_subjects us ON us.subject_id = s.id AND us.user_id = ?
      WHERE s.track_id = ?
      ORDER BY s.display_order
    `).all(req.user.id, trackId);

    res.json({ subjects });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch subjects', details: err.message });
  }
});

router.post('/generate', (req, res) => {
  try {
    const { 
      system_id, track_id, total_days, start_date, phases_count = 3,
      daily_hours = DEFAULT_DAILY_HOURS,
      distribution_mode = 'balanced',
      max_subjects_per_day = MAX_SUBJECTS_PER_DAY,
      review_mode = 'smart',
      weekly_rest_days = 1
    } = req.body;

    if (!system_id || !track_id || !total_days || !start_date) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const userSubjects = db.prepare(`
      SELECT us.*, s.name as subject_name, s.total_estimated_hours, s.id as subject_id
      FROM user_subjects us
      JOIN subjects s ON s.id = us.subject_id
      WHERE us.user_id = ? AND us.is_selected = 1
    `).all(req.user.id);

    if (userSubjects.length === 0) {
      return res.status(400).json({ error: 'Please select at least one subject' });
    }

    const transaction = db.transaction(() => {
      db.prepare('UPDATE user_schedules SET is_active = 0 WHERE user_id = ? AND is_active = 1').run(req.user.id);

      db.prepare('DELETE FROM schedule_tasks WHERE schedule_id IN (SELECT id FROM user_schedules WHERE user_id = ?)').run(req.user.id);

      const scheduleResult = db.prepare(
        `INSERT INTO user_schedules (user_id, system_id, track_id, total_days, phases_count, start_date)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(req.user.id, system_id, track_id, total_days, phases_count, start_date);

      const scheduleId = scheduleResult.lastInsertRowid;

      const adjustedSubjects = userSubjects.map(s => {
        const baseWeight = s.custom_weight || s.total_estimated_hours;
        const factor = DIFFICULTY_FACTORS[s.difficulty_level] || 1.0;
        return {
          ...s,
          baseWeight,
          difficultyLevel: s.difficulty_level,
          adjustedWeight: baseWeight * factor
        };
      });

      const totalAdjustedWeight = adjustedSubjects.reduce((sum, s) => sum + s.adjustedWeight, 0);

      const distribution = adjustedSubjects.map(subject => {
        let days;
        if (distribution_mode === 'intensive') {
          days = Math.round((subject.adjustedWeight / totalAdjustedWeight) * total_days * 1.3);
        } else if (distribution_mode === 'relaxed') {
          days = Math.round((subject.adjustedWeight / totalAdjustedWeight) * total_days * 0.7);
        } else {
          days = Math.round((subject.adjustedWeight / totalAdjustedWeight) * total_days);
        }
        days = Math.max(5, days);
        return { ...subject, totalDays: days };
      });

      const remainingDays = total_days - distribution.reduce((sum, s) => sum + s.totalDays, 0);
      if (distribution.length > 0 && remainingDays > 0) {
        distribution[distribution.length - 1].totalDays += remainingDays;
      }

      const subjectSchedules = distribution.map(subject => {
        const type = determineSubjectType(subject.subject_name);
        const phaseRatios = PHASE_RATIOS_BY_TYPE[type] || PHASE_RATIOS_BY_TYPE.default;
        
        const phaseDays = {
          study: Math.max(1, Math.round(subject.totalDays * phaseRatios.study)),
          practice: Math.max(1, Math.round(subject.totalDays * phaseRatios.practice)),
          review: Math.max(1, Math.round(subject.totalDays * phaseRatios.review))
        };

        const totalAllocated = phaseDays.study + phaseDays.practice + phaseDays.review;
        phaseDays.review += subject.totalDays - totalAllocated;

        return {
          subject,
          phaseDays,
          type
        };
      });

      const dailySchedule = {};
      let currentDay = 1;

      for (let day = 1; day <= total_days; day++) {
        const dayOfWeek = new Date(start_date).getDay() + ((day - 1) % 7);
        if (weekly_rest_days > 0 && dayOfWeek === 5) {
          dailySchedule[day] = [];
          continue;
        }

        const dayBlocks = [];
        let subjectsForDay = [];

        if (currentDay <= total_days) {
          for (const subjectSchedule of subjectSchedules) {
            const { subject, phaseDays } = subjectSchedule;
            
            let phase = null;
            let phaseType = null;
            
            const studyEnd = phaseDays.study;
            const practiceEnd = phaseDays.study + phaseDays.practice;
            
            if (currentDay <= studyEnd) {
              phase = 1;
              phaseType = 'study';
            } else if (currentDay <= practiceEnd) {
              phase = 2;
              phaseType = 'practice';
            } else {
              phase = 3;
              phaseType = 'review';
            }

            if (phase) {
              dayBlocks.push({
                subject_id: subject.subject_id,
                subject_name: subject.subject_name,
                phase,
                phaseType,
                difficultyLevel: subject.difficultyLevel
              });
              subjectsForDay.push(subject);
            }
          }
        }

        if (dayBlocks.length > max_subjects_per_day) {
          dayBlocks.splice(max_subjects_per_day);
        }

        const totalHours = dayBlocks.length > 0 ? 
          Math.min(daily_hours, Math.max(MIN_DAILY_HOURS, Math.round(daily_hours / dayBlocks.length))) : 0;
        
        dailySchedule[day] = dayBlocks.map(block => ({
          ...block,
          estimatedHours: totalHours / Math.max(1, dayBlocks.length)
        }));

        currentDay++;
      }

      if (review_mode === 'smart') {
        for (const [day, blocks] of Object.entries(dailySchedule)) {
          if (blocks.length === 0) continue;
          
          for (const interval of REVIEW_INTERVALS) {
            const reviewDay = parseInt(day) + interval;
            if (reviewDay > total_days) continue;
            
            for (const block of blocks) {
              if (block.phaseType === 'study') {
                const reviewBlock = {
                  ...block,
                  phaseType: 'review',
                  isReview: true,
                  reviewInterval: interval
                };
                if (!dailySchedule[reviewDay]) dailySchedule[reviewDay] = [];
                dailySchedule[reviewDay].push(reviewBlock);
              }
            }
          }
        }
      }

      const blocks = [];
      let currentBlockDay = 1;

      for (const subjectSchedule of subjectSchedules) {
        const { subject, phaseDays } = subjectSchedule;
        
        for (const [phaseType, days] of Object.entries(phaseDays)) {
          if (days <= 0) continue;
          
          const startDay = currentBlockDay;
          const endDay = currentBlockDay + days - 1;
          
          const blockId = db.prepare(
            `INSERT INTO schedule_blocks (schedule_id, subject_id, phase, start_day, end_day, allocated_days)
             VALUES (?, ?, ?, ?, ?, ?)`
          ).run(scheduleId, subject.subject_id, 
            phaseType === 'study' ? 1 : phaseType === 'practice' ? 2 : 3,
            startDay, endDay, days
          ).lastInsertRowid;

          blocks.push({
            id: blockId,
            schedule_id: scheduleId,
            subject_id: subject.subject_id,
            subject_name: subject.subject_name,
            phase: phaseType === 'study' ? 1 : phaseType === 'practice' ? 2 : 3,
            start_day: startDay,
            end_day: endDay,
            allocated_days: days,
            progress_percent: 0,
            difficulty_level: subject.difficultyLevel
          });

          for (let day = startDay; day <= endDay; day++) {
            const dayBlocks = dailySchedule[day] || [];
            const matchingBlock = dayBlocks.find(b => b.subject_id === subject.subject_id);
            const taskType = matchingBlock?.phaseType || phaseType;
            
            db.prepare(
              `INSERT INTO schedule_tasks (schedule_id, subject_id, day_number, task_type, topic_name, description)
               VALUES (?, ?, ?, ?, ?, ?)`
            ).run(scheduleId, subject.subject_id, day, taskType, null, 
              matchingBlock?.isReview ? `مراجعة بعد ${matchingBlock.reviewInterval} يوم` : null
            );
          }

          currentBlockDay = endDay + 1;
        }
      }

      const schedule = db.prepare('SELECT * FROM user_schedules WHERE id = ?').get(scheduleId);

      return { schedule, blocks };
    });

    const result = transaction();
    res.status(201).json(result);
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate schedule', details: err.message });
  }
});

function determineSubjectType(subjectName) {
  const name = subjectName.toLowerCase();
  if (name.includes('رياضة') || name.includes('math') || name.includes('جبر') || name.includes('تفاضل')) return 'math';
  if (name.includes('لغة') && !name.includes('انجليزية')) return 'language';
  if (name.includes('فيزياء') || name.includes('كيمياء') || name.includes('أحياء')) return 'science';
  return 'default';
}

router.get('/active', (req, res) => {
  try {
    const schedule = db.prepare(
      'SELECT * FROM user_schedules WHERE user_id = ? AND is_active = 1'
    ).get(req.user.id);

    if (!schedule) {
      return res.status(404).json({ error: 'No active schedule found' });
    }

    const blocks = db.prepare(`
      SELECT sb.*, s.name AS subject_name, s.total_estimated_hours, us.difficulty_level
      FROM schedule_blocks sb
      JOIN subjects s ON sb.subject_id = s.id
      LEFT JOIN user_subjects us ON us.subject_id = s.id AND us.user_id = ?
      WHERE sb.schedule_id = ?
      ORDER BY sb.start_day
    `).all(req.user.id, schedule.id);

    const tasks = db.prepare(`
      SELECT st.*, s.name AS subject_name
      FROM schedule_tasks st
      JOIN subjects s ON st.subject_id = s.id
      WHERE st.schedule_id = ?
      ORDER BY st.day_number
    `).all(schedule.id);

    res.json({ schedule, blocks, tasks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch schedule', details: err.message });
  }
});

router.get('/:id/tasks', (req, res) => {
  try {
    const tasks = db.prepare(`
      SELECT st.*, s.name AS subject_name
      FROM schedule_tasks st
      JOIN subjects s ON st.subject_id = s.id
      WHERE st.schedule_id = ? AND st.day_number = ?
      ORDER BY st.task_type
    `).all(req.params.id, req.query.day);

    res.json({ tasks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tasks', details: err.message });
  }
});

router.put('/tasks/:taskId/complete', (req, res) => {
  try {
    const { taskId } = req.params;
    const { completed } = req.body;

    const task = db.prepare(
      `SELECT st.* FROM schedule_tasks st
       JOIN user_schedules us ON st.schedule_id = us.id
       WHERE st.id = ? AND us.user_id = ?`
    ).get(taskId, req.user.id);

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    db.prepare(
      'UPDATE schedule_tasks SET is_completed = ?, completed_at = ? WHERE id = ?'
    ).run(completed ? 1 : 0, completed ? new Date().toISOString() : null, taskId);

    if (completed) {
      for (const interval of REVIEW_INTERVALS) {
        const reviewDay = task.day_number + interval;
        const existingReview = db.prepare(
          `SELECT id FROM schedule_tasks 
           WHERE schedule_id = ? AND subject_id = ? AND day_number = ? AND task_type = 'review'`
        ).get(task.schedule_id, task.subject_id, reviewDay);

        if (!existingReview) {
          db.prepare(
            `INSERT INTO schedule_tasks (schedule_id, subject_id, day_number, task_type, topic_name)
             VALUES (?, ?, ?, 'review', ?)`
          ).run(task.schedule_id, task.subject_id, reviewDay, task.topic_name || 'مراجعة');
        }
      }
    }

    const updated = db.prepare('SELECT * FROM schedule_tasks WHERE id = ?').get(taskId);
    res.json({ task: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update task', details: err.message });
  }
});

router.put('/blocks/:blockId/progress', (req, res) => {
  try {
    const { blockId } = req.params;
    const { progress_percent } = req.body;

    if (progress_percent === undefined || progress_percent < 0 || progress_percent > 100) {
      return res.status(400).json({ error: 'progress_percent must be between 0 and 100' });
    }

    const block = db.prepare(`
      SELECT sb.* FROM schedule_blocks sb
      JOIN user_schedules us ON sb.schedule_id = us.id
      WHERE sb.id = ? AND us.user_id = ?
    `).get(blockId, req.user.id);

    if (!block) {
      return res.status(404).json({ error: 'Block not found' });
    }

    db.prepare('UPDATE schedule_blocks SET progress_percent = ? WHERE id = ?').run(progress_percent, blockId);

    const updated = db.prepare('SELECT * FROM schedule_blocks WHERE id = ?').get(blockId);
    res.json({ block: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update progress', details: err.message });
  }
});

router.post('/reschedule', (req, res) => {
  try {
    const { block_id, extra_days } = req.body;

    if (!block_id || !extra_days) {
      return res.status(400).json({ error: 'block_id and extra_days are required' });
    }

    const block = db.prepare(`
      SELECT sb.* FROM schedule_blocks sb
      JOIN user_schedules us ON sb.schedule_id = us.id
      WHERE sb.id = ? AND us.user_id = ?
    `).get(block_id, req.user.id);

    if (!block) {
      return res.status(404).json({ error: 'Block not found' });
    }

    const transaction = db.transaction(() => {
      db.prepare(
        `UPDATE schedule_blocks
         SET end_day = end_day + ?, allocated_days = allocated_days + ?
         WHERE id = ?`
      ).run(extra_days, extra_days, block_id);

      db.prepare(
        `UPDATE schedule_blocks
         SET start_day = start_day + ?, end_day = end_day + ?
         WHERE schedule_id = ? AND start_day > ?`
      ).run(extra_days, extra_days, block.schedule_id, block.end_day);

      db.prepare(
        'UPDATE schedule_tasks SET day_number = day_number + ? WHERE schedule_id = ? AND day_number > ?'
      ).run(extra_days, block.schedule_id, block.end_day);

      db.prepare(
        'UPDATE user_schedules SET total_days = total_days + ? WHERE id = ?'
      ).run(extra_days, block.schedule_id);
    });

    transaction();

    const blocks = db.prepare(`
      SELECT sb.*, s.name AS subject_name
      FROM schedule_blocks sb
      JOIN subjects s ON sb.subject_id = s.id
      WHERE sb.schedule_id = ?
      ORDER BY sb.start_day
    `).all(block.schedule_id);

    const schedule = db.prepare('SELECT * FROM user_schedules WHERE id = ?').get(block.schedule_id);

    res.json({ schedule, blocks });
  } catch (err) {
    res.status(500).json({ error: 'Failed to reschedule', details: err.message });
  }
});

router.get('/stats', (req, res) => {
  try {
    const schedule = db.prepare(
      'SELECT * FROM user_schedules WHERE user_id = ? AND is_active = 1'
    ).get(req.user.id);

    if (!schedule) {
      return res.json({ stats: null });
    }

    const completedTasks = db.prepare(
      'SELECT COUNT(*) as count FROM schedule_tasks WHERE schedule_id = ? AND is_completed = 1'
    ).get(schedule.id).count;

    const totalTasks = db.prepare(
      'SELECT COUNT(*) as count FROM schedule_tasks WHERE schedule_id = ?'
    ).get(schedule.id).count;

    const todayTasks = db.prepare(
      `SELECT st.*, s.name as subject_name FROM schedule_tasks st
       JOIN subjects s ON st.subject_id = s.id
       WHERE st.schedule_id = ? AND st.day_number = ?`
    ).all(schedule.id, req.query.day || 1);

    const reviewTasks = db.prepare(
      `SELECT st.*, s.name as subject_name FROM schedule_tasks st
       JOIN subjects s ON st.subject_id = s.id
       WHERE st.schedule_id = ? AND st.task_type = 'review'`
    ).all(schedule.id);

    res.json({
      stats: {
        completed_tasks: completedTasks,
        total_tasks: totalTasks,
        completion_percent: totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0,
        review_count: reviewTasks.length,
      },
      today_tasks: todayTasks,
      review_tasks: reviewTasks.slice(0, 5),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats', details: err.message });
  }
});

export default router;
